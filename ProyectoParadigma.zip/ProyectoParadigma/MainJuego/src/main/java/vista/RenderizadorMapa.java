package vista;

import java.awt.Color;
import java.awt.Graphics2D;
import modelo.Mapa;
import modelo.ObjetoMapa;
import modelo.ObjetoSuelo;
import modelo.Escoba;
import modelo.Puerta;

final class RenderizadorMapa {
    private RenderizadorMapa() {
    }

    static void dibujar(Graphics2D g, Mapa mapa) {
        for (int fila = 0; fila < Mapa.FILAS; fila++) {
            for (int columna = 0; columna < Mapa.COLUMNAS; columna++) {
                int x = columna * Mapa.TILE_SIZE;
                int y = fila * Mapa.TILE_SIZE;
                if (mapa.esPared(columna, fila)) {
                    boolean mueble = mapa.esMueble(columna, fila);
                    g.setColor(mueble ? new Color(104, 70, 46) : new Color(49, 48, 57));
                    g.fillRect(x, y, Mapa.TILE_SIZE, Mapa.TILE_SIZE);
                    g.setColor(mueble ? new Color(143, 101, 63) : new Color(67, 65, 75));
                    g.drawLine(x, y, x + Mapa.TILE_SIZE, y);
                    if (mueble) {
                        g.drawRect(x + 3, y + 3, Mapa.TILE_SIZE - 7, Mapa.TILE_SIZE - 7);
                    }
                } else {
                    g.setColor(colorSuelo(mapa.getNombreZona(columna, fila), fila + columna));
                    g.fillRect(x, y, Mapa.TILE_SIZE, Mapa.TILE_SIZE);
                }
            }
        }
        dibujarPuertas(g, mapa);
        dibujarEtiquetas(g);
        for (ObjetoMapa objeto : mapa.getObjetos()) {
            dibujarObjeto(g, objeto);
        }
        for (ObjetoSuelo objeto : mapa.getObjetosSuelo()) {
            dibujarObjetoSuelo(g, objeto);
        }
    }

    private static Color colorSuelo(String zona, int patron) {
        boolean alternar = (patron & 1) == 0;
        return switch (zona) {
            case "Baños" -> alternar
                    ? new Color(63, 76, 80) : new Color(67, 80, 84);
            case "Tienda" -> alternar
                    ? new Color(76, 62, 47) : new Color(81, 66, 49);
            case "Laboratorio 1", "Laboratorio 2", "Laboratorio 3" -> alternar
                    ? new Color(48, 66, 67) : new Color(52, 70, 71);
            case "Patio" -> alternar
                    ? new Color(43, 69, 49) : new Color(47, 74, 52);
            case "Cuarto cerrado" -> alternar
                    ? new Color(48, 44, 49) : new Color(52, 48, 53);
            default -> alternar
                    ? new Color(34, 39, 43) : new Color(37, 42, 46);
        };
    }

    private static void dibujarEtiquetas(Graphics2D g) {
        dibujarEtiqueta(g, "LAB 1", 12, 3);
        dibujarEtiqueta(g, "LAB 2", 18, 3);
        dibujarEtiqueta(g, "BAÑOS", 2, 9);
        dibujarEtiqueta(g, "TIENDA", 1, 16);
        dibujarEtiqueta(g, "PASILLO", 11, 8);
        dibujarEtiqueta(g, "LAB 3", 12, 11);
        dibujarEtiqueta(g, "PATIO", 23, 16);
    }

    private static void dibujarEtiqueta(Graphics2D g, String texto, int columna, int fila) {
        int x = columna * Mapa.TILE_SIZE;
        int y = fila * Mapa.TILE_SIZE;
        g.setColor(new Color(10, 12, 14, 175));
        g.fillRoundRect(x, y, texto.length() * 8 + 12, 22, 7, 7);
        g.setColor(new Color(230, 224, 204));
        g.setFont(new java.awt.Font(java.awt.Font.SANS_SERIF, java.awt.Font.BOLD, 11));
        g.drawString(texto, x + 6, y + 15);
    }

    private static void dibujarPuertas(Graphics2D g, Mapa mapa) {
        for (Puerta puerta : mapa.getPuertas()) {
            int x = puerta.getTileX() * Mapa.TILE_SIZE;
            int y = puerta.getTileY() * Mapa.TILE_SIZE;
            boolean paredHorizontal = mapa.esPared(puerta.getTileX() - 1, puerta.getTileY())
                    && mapa.esPared(puerta.getTileX() + 1, puerta.getTileY());
            g.setColor(puerta.isBloqueada() ? Color.BLACK : new Color(55, 205, 105));
            if (paredHorizontal) {
                g.fillRoundRect(x + 4, y + Mapa.TILE_SIZE / 2 - 3,
                        Mapa.TILE_SIZE - 8, 6, 4, 4);
            } else {
                g.fillRoundRect(x + Mapa.TILE_SIZE / 2 - 3, y + 4,
                        6, Mapa.TILE_SIZE - 8, 4, 4);
            }
            if (puerta.isBloqueada()) {
                g.setColor(new Color(95, 95, 95));
                g.drawLine(x + 12, y + 10, x + 20, y + 22);
                g.drawLine(x + 20, y + 10, x + 12, y + 22);
            }
        }
    }

    private static void dibujarObjetoSuelo(Graphics2D g, ObjetoSuelo objeto) {
        int x = (int) objeto.getX();
        int y = (int) objeto.getY();
        g.setColor(new Color(222, 181, 112));
        if (objeto.getItem() instanceof Escoba) {
            g.setStroke(new java.awt.BasicStroke(3));
            g.drawLine(x - 7, y + 6, x + 7, y - 6);
            g.setStroke(new java.awt.BasicStroke(1));
            g.drawLine(x - 9, y + 7, x - 5, y + 10);
            g.drawLine(x - 7, y + 5, x - 3, y + 8);
        } else {
            g.fillRoundRect(x - 6, y - 6, 12, 12, 4, 4);
            g.setColor(Color.WHITE);
            g.drawString(objeto.getItem().getNombre().substring(0, 1),
                    x - 3, y + 4);
        }
    }

    private static void dibujarObjeto(Graphics2D g, ObjetoMapa objeto) {
        int x = objeto.getColumna() * Mapa.TILE_SIZE;
        int y = objeto.getFila() * Mapa.TILE_SIZE;
        switch (objeto.getTipo()) {
            case BATERIA -> {
                g.setColor(new Color(75, 190, 110));
                g.fillRoundRect(x + 9, y + 6, 14, 21, 4, 4);
                g.setColor(Color.WHITE);
                g.drawString("+", x + 13, y + 22);
            }
            case ESCOBA -> {
                g.setColor(new Color(185, 143, 88));
                g.drawLine(x + 10, y + 24, x + 23, y + 8);
                g.setColor(new Color(221, 193, 128));
                g.drawLine(x + 7, y + 26, x + 14, y + 27);
                g.drawLine(x + 9, y + 23, x + 16, y + 25);
            }
            case PIEZA -> {
                g.setColor(new Color(238, 190, 87));
                g.fillOval(x + 7, y + 7, 18, 18);
                g.setColor(new Color(93, 66, 37));
                g.drawOval(x + 11, y + 11, 10, 10);
            }
            case LIBRO -> {
                g.setColor(new Color(127, 57, 55));
                g.fillRoundRect(x + 6, y + 7, 20, 19, 3, 3);
                g.setColor(new Color(231, 207, 151));
                g.drawLine(x + 16, y + 8, x + 16, y + 25);
            }
            case CAJA_FUERTE -> {
                g.setColor(new Color(126, 132, 140));
                g.fillRoundRect(x + 3, y + 4, 26, 25, 4, 4);
                g.setColor(new Color(48, 51, 57));
                g.drawOval(x + 11, y + 11, 10, 10);
            }
            case SALIDA -> {
                g.setColor(new Color(135, 49, 51));
                g.fillRect(x + 7, y + 3, 18, 27);
                g.setColor(new Color(231, 199, 115));
                g.fillOval(x + 19, y + 15, 3, 3);
            }
            case BOTIQUIN -> {
                g.setColor(new Color(225, 228, 222));
                g.fillRoundRect(x + 6, y + 9, 20, 15, 3, 3);
                g.setColor(new Color(178, 57, 57));
                g.fillRect(x + 14, y + 11, 4, 11);
                g.fillRect(x + 10, y + 15, 12, 4);
            }
        }
    }
}
