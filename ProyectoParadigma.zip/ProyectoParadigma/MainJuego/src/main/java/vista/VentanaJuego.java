package vista;

import controlador.ControladorJuego;
import javax.swing.JFrame;

public class VentanaJuego extends JFrame {
    private static final long serialVersionUID = 1L;

    public VentanaJuego() {
        super("Escapando de la FACE");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    public void configurar(ControladorJuego controlador) {
        controlador.configurarVentana(this);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
