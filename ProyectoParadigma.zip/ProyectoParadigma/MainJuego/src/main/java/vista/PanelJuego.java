package vista;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import javax.swing.JPanel;
import modelo.Entity;
import modelo.EstadoJuego;
import modelo.Inventory;
import modelo.Item;
import modelo.Mapa;
import modelo.Player;

public class PanelJuego extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final Color FONDO_HUD = new Color(12, 14, 17, 225);
    private static final int ANCHO_BOTON_MUERTE = 220;
    private static final int ALTO_BOTON_MUERTE = 48;
    private transient EstadoJuego estadoJuego;
    private boolean pausado;

    public enum AccionMuerte {
        NINGUNA, REINTENTAR, MENU_PRINCIPAL
    }

    public enum AccionPausa {
        NINGUNA, REANUDAR, GUARDAR_PARTIDA, MENU_PRINCIPAL
    }

    public enum AccionFinal {
        NINGUNA, VOLVER_A_JUGAR, MENU_PRINCIPAL
    }

    public PanelJuego(EstadoJuego estadoJuego) {
        this.estadoJuego = estadoJuego;
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(Mapa.ANCHO, Mapa.ALTO);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        RenderizadorMapa.dibujar(g2, estadoJuego.getMapaActual());
        dibujarEntidad(g2, estadoJuego.getEntidad());
        dibujarJugador(g2, estadoJuego.getJugador());
        dibujarOscuridad(g2);
        dibujarHud(g2);
        if (estadoJuego.isGano()) {
            dibujarPantallaFinal(g2);
        } else if (!estadoJuego.isJugadorVivo()) {
            dibujarPantallaMuerte(g2);
        } else if (pausado) {
            dibujarPantallaPausa(g2);
        }
        g2.dispose();
    }

    public void setPausado(boolean pausado) {
        this.pausado = pausado;
        repaint();
    }

    public AccionMuerte obtenerAccionMuerte(int x, int y) {
        int centroX = getWidth() / 2;
        int centroY = getHeight() / 2;
        int botonX = centroX - ANCHO_BOTON_MUERTE / 2;
        if (x < botonX || x >= botonX + ANCHO_BOTON_MUERTE) {
            return AccionMuerte.NINGUNA;
        }
        if (y >= centroY + 28 && y < centroY + 28 + ALTO_BOTON_MUERTE) {
            return AccionMuerte.REINTENTAR;
        }
        if (y >= centroY + 88 && y < centroY + 88 + ALTO_BOTON_MUERTE) {
            return AccionMuerte.MENU_PRINCIPAL;
        }
        return AccionMuerte.NINGUNA;
    }

    public AccionPausa obtenerAccionPausa(int x, int y) {
        int centroX = getWidth() / 2;
        int centroY = getHeight() / 2;
        int botonX = centroX - ANCHO_BOTON_MUERTE / 2;
        if (x < botonX || x >= botonX + ANCHO_BOTON_MUERTE) {
            return AccionPausa.NINGUNA;
        }
        if (y >= centroY + 28 && y < centroY + 28 + ALTO_BOTON_MUERTE) {
            return AccionPausa.REANUDAR;
        }
        if (y >= centroY + 88 && y < centroY + 88 + ALTO_BOTON_MUERTE) {
            return AccionPausa.GUARDAR_PARTIDA;
        }
        if (y >= centroY + 148 && y < centroY + 148 + ALTO_BOTON_MUERTE) {
            return AccionPausa.MENU_PRINCIPAL;
        }
        return AccionPausa.NINGUNA;
    }

    public AccionFinal obtenerAccionFinal(int x, int y) {
        int centroX = getWidth() / 2;
        int centroY = getHeight() / 2;
        int botonX = centroX - ANCHO_BOTON_MUERTE / 2;
        if (x < botonX || x >= botonX + ANCHO_BOTON_MUERTE) {
            return AccionFinal.NINGUNA;
        }
        if (y >= centroY + 82 && y < centroY + 82 + ALTO_BOTON_MUERTE) {
            return AccionFinal.VOLVER_A_JUGAR;
        }
        if (y >= centroY + 142 && y < centroY + 142 + ALTO_BOTON_MUERTE) {
            return AccionFinal.MENU_PRINCIPAL;
        }
        return AccionFinal.NINGUNA;
    }

    private void dibujarJugador(Graphics2D g, Player jugador) {
        int x = (int) jugador.getX();
        int y = (int) jugador.getY();
        g.setColor(new Color(60, 170, 220));
        g.fillRoundRect(x, y, jugador.getAncho(), jugador.getAlto(), 9, 9);
        g.setColor(new Color(228, 242, 255));
        g.fillOval(x + 6, y + 5, 5, 5);
        g.fillOval(x + 15, y + 5, 5, 5);
        g.setColor(new Color(236, 223, 190));
        int centroX = x + jugador.getAncho() / 2;
        int centroY = y + jugador.getAlto() / 2;
        g.drawLine(centroX, centroY, centroX
                + (int) (Math.cos(jugador.getAnguloApuntado()) * 20), centroY
                + (int) (Math.sin(jugador.getAnguloApuntado()) * 20));
    }

    private void dibujarEntidad(Graphics2D g, Entity entidad) {
        int x = (int) entidad.getX();
        int y = (int) entidad.getY();
        g.setColor(entidad.isEstaParalizado()
                ? new Color(86, 190, 235) : new Color(160, 37, 49));
        g.fillOval(x, y, entidad.getAncho(), entidad.getAlto());
        g.setColor(entidad.isEsModoFuria()
                ? new Color(255, 104, 55) : new Color(239, 177, 175));
        g.fillOval(x + 6, y + 8, 4, 4);
        g.fillOval(x + 17, y + 8, 4, 4);
    }

    private void dibujarOscuridad(Graphics2D g) {
        Player jugador = estadoJuego.getJugador();
        double radio = jugador.getLinterna().obtenerRadioLuz();
        if (radio <= 0) {
            g.setColor(new Color(0, 0, 0, 248));
            g.fillRect(0, 0, Mapa.ANCHO, Mapa.ALTO);
            return;
        }
        float radioGradiente = (float) Math.max(70, radio * 1.65);
        Point2D centro = new Point2D.Double(jugador.getX() + jugador.getAncho() / 2.0,
                jugador.getY() + jugador.getAlto() / 2.0);
        RadialGradientPaint sombra = new RadialGradientPaint(centro, radioGradiente,
                new float[]{0.0f, 0.45f, 0.78f, 1.0f},
                new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 20),
                    new Color(0, 0, 0, 205), new Color(0, 0, 0, 248)});
        g.setPaint(sombra);
        g.fillRect(0, 0, Mapa.ANCHO, Mapa.ALTO);
    }

    private void dibujarHud(Graphics2D g) {
        Player jugador = estadoJuego.getJugador();
        Inventory inventario = jugador.getInventario();
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        g.setColor(FONDO_HUD);
        g.fillRoundRect(12, 12, 288, 112, 12, 12);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        g.setColor(new Color(238, 224, 188));
        String nombreHud = estadoJuego.getNombreJugador();
        if (nombreHud.length() > 13) {
            nombreHud = nombreHud.substring(0, 12) + "…";
        }
        g.drawString(nombreHud + "  "
                + formatearTiempo(estadoJuego.getTiempoTranscurridoMs()),
                Mapa.ANCHO - 190, 55);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        g.setColor(Color.WHITE);
        g.drawString("SALUD", 24, 34);
        dibujarBarra(g, 84, 23, 195, 13, jugador.getSaludActual(),
                jugador.getSaludMax(), new Color(203, 61, 70));
        g.drawString("STAMINA", 24, 58);
        dibujarBarra(g, 84, 47, 195, 13, jugador.getStaminaActual(),
                jugador.getStaminaMax(), new Color(222, 179, 68));
        g.drawString("LINTERNA", 24, 82);
        dibujarBarra(g, 84, 71, 195, 13, jugador.getLinterna().getNivelBateria(),
                jugador.getLinterna().getBateriaMax(), new Color(220, 218, 150));
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.drawString("Piezas: " + estadoJuego.getNumeroPiezas() + "/"
                + estadoJuego.getCantidadPiezas(), 24, 108);
        g.drawString("Taser: " + (jugador.getTaser().estaListo() ? "listo"
                : String.format("%.1f s", jugador.getTaser().getTiempoRestanteCooldown())),
                164, 108);

        int anchoCasilla = 100;
        int inicioX = (Mapa.ANCHO - anchoCasilla * Inventory.CAPACIDAD_MAXIMA) / 2;
        int y = Mapa.ALTO - 59;
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        for (int i = 0; i < Inventory.CAPACIDAD_MAXIMA; i++) {
            int x = inicioX + i * anchoCasilla;
            boolean seleccionado = inventario.getSlotSeleccionado() == i;
            g.setColor(seleccionado ? new Color(204, 167, 80, 235) : FONDO_HUD);
            g.fillRoundRect(x, y, anchoCasilla - 5, 47, 8, 8);
            g.setColor(seleccionado ? Color.WHITE : new Color(145, 151, 158));
            g.setStroke(new BasicStroke(seleccionado ? 2 : 1));
            g.drawRoundRect(x, y, anchoCasilla - 5, 47, 8, 8);
            Item item = inventario.getItemEnSlot(i);
            g.drawString(Integer.toString(i + 1), x + 5, y + 13);
            if (item != null) {
                g.setColor(Color.WHITE);
                String nombre = item.getNombre();
                if (nombre.length() > 13) {
                    nombre = nombre.substring(0, 12) + "…";
                }
                g.drawString(nombre, x + 5, y + 31);
            }
        }

        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.setColor(new Color(238, 238, 230));
        g.drawString("WASD mover   Shift correr   E interactuar   Espacio usar   Q botar   F linterna",
                20, Mapa.ALTO - 70);
        g.drawString("ESC: pausa   Clic: taser   B: libro   1-9: inventario",
                Mapa.ANCHO - 360, 28);
    }

    private void dibujarBarra(Graphics2D g, int x, int y, int ancho, int alto,
            float valor, float maximo, Color color) {
        g.setColor(new Color(55, 58, 62));
        g.fillRoundRect(x, y, ancho, alto, 6, 6);
        int anchoValor = Math.round(ancho * Math.max(0, Math.min(1, valor / maximo)));
        g.setColor(color);
        g.fillRoundRect(x, y, anchoValor, alto, 6, 6);
    }

    private void dibujarPantallaFinal(Graphics2D g) {
        g.setComposite(AlphaComposite.SrcOver.derive(0.82f));
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setComposite(AlphaComposite.SrcOver);
        g.setColor(new Color(234, 213, 163));
        g.setFont(new Font(Font.SERIF, Font.BOLD, 36));
        String titulo = "¡LOGRASTE ESCAPAR!";
        int ancho = g.getFontMetrics().stringWidth(titulo);
        g.drawString(titulo, (getWidth() - ancho) / 2, getHeight() / 2);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        String resultado = estadoJuego.getNombreJugador() + " - "
                + formatearTiempo(estadoJuego.getTiempoTranscurridoMs());
        g.drawString(resultado,
                (getWidth() - g.getFontMetrics().stringWidth(resultado)) / 2,
                getHeight() / 2 + 42);
        dibujarBotonMuerte(g, getWidth() / 2, getHeight() / 2 + 82,
                "Volver a jugar", true);
        dibujarBotonMuerte(g, getWidth() / 2, getHeight() / 2 + 142,
                "Menú principal", false);
    }

    private void dibujarPantallaMuerte(Graphics2D g) {
        g.setComposite(AlphaComposite.SrcOver.derive(0.82f));
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setComposite(AlphaComposite.SrcOver);

        int centroX = getWidth() / 2;
        int centroY = getHeight() / 2;
        String titulo = "¡MORISTE!";
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 42));
        g.setColor(new Color(225, 75, 78));
        g.drawString(titulo, centroX - g.getFontMetrics().stringWidth(titulo) / 2,
                centroY - 24);
        dibujarBotonMuerte(g, centroX, centroY + 28, "Reintentar", true);
        dibujarBotonMuerte(g, centroX, centroY + 88, "Menú principal", false);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        g.setColor(new Color(210, 210, 210));
        String indicacion = "Haz clic en una opción para continuar";
        g.drawString(indicacion,
                centroX - g.getFontMetrics().stringWidth(indicacion) / 2,
                centroY + 165);
    }

    private void dibujarBotonMuerte(Graphics2D g, int centroX, int y,
            String texto, boolean principal) {
        int x = centroX - ANCHO_BOTON_MUERTE / 2;
        g.setColor(principal ? new Color(153, 45, 54) : new Color(48, 52, 59));
        g.fillRoundRect(x, y, ANCHO_BOTON_MUERTE, ALTO_BOTON_MUERTE, 12, 12);
        g.setColor(new Color(235, 225, 212));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(x, y, ANCHO_BOTON_MUERTE, ALTO_BOTON_MUERTE, 12, 12);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 17));
        g.setColor(Color.WHITE);
        g.drawString(texto, centroX - g.getFontMetrics().stringWidth(texto) / 2,
                y + 30);
    }

    private void dibujarPantallaPausa(Graphics2D g) {
        g.setComposite(AlphaComposite.SrcOver.derive(0.82f));
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setComposite(AlphaComposite.SrcOver);

        int centroX = getWidth() / 2;
        int centroY = getHeight() / 2;
        String titulo = "PAUSA";
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 42));
        g.setColor(new Color(234, 213, 163));
        g.drawString(titulo, centroX - g.getFontMetrics().stringWidth(titulo) / 2,
                centroY - 24);
        dibujarBotonMuerte(g, centroX, centroY + 28, "Reanudar", true);
        dibujarBotonMuerte(g, centroX, centroY + 88, "Guardar partida", false);
        dibujarBotonMuerte(g, centroX, centroY + 148, "Menú principal", false);
    }

    private String formatearTiempo(long tiempoMs) {
        long segundos = tiempoMs / 1000;
        long horas = segundos / 3600;
        long minutos = (segundos % 3600) / 60;
        long restoSegundos = segundos % 60;
        return horas > 0
                ? String.format("%02d:%02d:%02d", horas, minutos, restoSegundos)
                : String.format("%02d:%02d", minutos, restoSegundos);
    }
}
