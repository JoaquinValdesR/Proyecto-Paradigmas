package persistencia;

import java.util.List;

public record ListadoPartidas(List<ResumenPartida> partidas,
        boolean guardadoAnteriorNoCompatible) {
    public ListadoPartidas {
        partidas = List.copyOf(partidas);
    }
}
