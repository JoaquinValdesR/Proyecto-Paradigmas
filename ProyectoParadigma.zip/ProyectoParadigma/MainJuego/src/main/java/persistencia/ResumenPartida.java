package persistencia;

public record ResumenPartida(String id, String nombreJugador,
        long tiempoTranscurridoMs, long guardadoEnMs) {
}
