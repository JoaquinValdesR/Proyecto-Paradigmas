package persistencia;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import modelo.RegistroPuntaje;

public class RepositorioRanking {
    public static final int CANTIDAD_MAXIMA = 10;
    private static final String VERSION = "2";
    private static final String VERSION_ANTERIOR = "1";
    private final Path archivo;

    public RepositorioRanking() {
        this(Path.of(System.getProperty("user.home", "."),
                ".mainjuego", "ranking.properties"));
    }

    public RepositorioRanking(Path archivo) {
        this.archivo = archivo.toAbsolutePath().normalize();
    }

    public List<RegistroPuntaje> listar() throws IOException {
        if (!Files.isRegularFile(archivo)) {
            return List.of();
        }
        Properties propiedades = new Properties();
        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }
        try {
            String version = propiedades.getProperty("version");
            if (!VERSION.equals(version) && !VERSION_ANTERIOR.equals(version)) {
                throw new IllegalArgumentException("La versión del ranking no es válida.");
            }
            int cantidad = Integer.parseInt(requerir(propiedades, "cantidad"));
            if (cantidad < 0 || cantidad > CANTIDAD_MAXIMA) {
                throw new IllegalArgumentException("La cantidad de registros no es válida.");
            }
            List<RegistroPuntaje> registros = new ArrayList<>(cantidad);
            long fechaAnteriorMs = Files.getLastModifiedTime(archivo).toMillis();
            for (int i = 0; i < cantidad; i++) {
                String prefijo = "registro." + i + ".";
                String fechaGuardada = propiedades.getProperty(prefijo + "fecha.ms");
                long fechaMs = fechaGuardada == null
                        ? fechaAnteriorMs : Long.parseLong(fechaGuardada.trim());
                registros.add(new RegistroPuntaje(
                        requerir(propiedades, prefijo + "nombre"),
                        Long.parseLong(requerir(propiedades, prefijo + "tiempo.ms")),
                        fechaMs));
            }
            registros.sort(Comparator.comparingLong(RegistroPuntaje::tiempoMs));
            return List.copyOf(registros);
        } catch (IllegalArgumentException ex) {
            throw new IOException("El archivo del ranking está dañado.", ex);
        }
    }

    public List<RegistroPuntaje> registrar(RegistroPuntaje registro) throws IOException {
        if (registro == null) {
            throw new IllegalArgumentException("El registro del ranking no puede ser nulo.");
        }
        List<RegistroPuntaje> registros = new ArrayList<>(listar());
        registros.add(registro);
        registros.sort(Comparator.comparingLong(RegistroPuntaje::tiempoMs));
        if (registros.size() > CANTIDAD_MAXIMA) {
            registros = new ArrayList<>(registros.subList(0, CANTIDAD_MAXIMA));
        }
        guardar(registros);
        return List.copyOf(registros);
    }

    private void guardar(List<RegistroPuntaje> registros) throws IOException {
        Properties propiedades = new Properties();
        propiedades.setProperty("version", VERSION);
        propiedades.setProperty("cantidad", Integer.toString(registros.size()));
        for (int i = 0; i < registros.size(); i++) {
            RegistroPuntaje registro = registros.get(i);
            String prefijo = "registro." + i + ".";
            propiedades.setProperty(prefijo + "nombre", registro.nombreJugador());
            propiedades.setProperty(prefijo + "tiempo.ms", Long.toString(registro.tiempoMs()));
            propiedades.setProperty(prefijo + "fecha.ms", Long.toString(registro.fechaMs()));
        }
        Path directorio = archivo.getParent();
        Files.createDirectories(directorio);
        Path temporal = Files.createTempFile(directorio, "ranking-", ".tmp");
        try {
            try (Writer escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                propiedades.store(escritor, "Ranking de Escapando de la FACE");
            }
            try {
                Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporal);
        }
    }

    private static String requerir(Properties propiedades, String clave) {
        String valor = propiedades.getProperty(clave);
        if (valor == null) {
            throw new IllegalArgumentException("Falta el dato " + clave + ".");
        }
        return valor.trim();
    }
}
