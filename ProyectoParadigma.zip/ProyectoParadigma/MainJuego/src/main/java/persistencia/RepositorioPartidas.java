package persistencia;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import modelo.DatosPartida;
import modelo.DatosObjetoSuelo;
import modelo.DatosMapa;
import modelo.Inventory;

public class RepositorioPartidas {
    private static final String VERSION = "3";
    private final Path archivo;

    public RepositorioPartidas() {
        this(Path.of(System.getProperty("user.home", "."),
                ".mainjuego", "partida.properties"));
    }

    public RepositorioPartidas(Path archivo) {
        this.archivo = archivo.toAbsolutePath().normalize();
    }

    public void guardar(DatosPartida datos) throws IOException {
        Properties propiedades = serializar(datos);
        Path directorio = archivo.getParent();
        Files.createDirectories(directorio);
        Path temporal = Files.createTempFile(directorio, "partida-", ".tmp");
        try {
            try (Writer escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                propiedades.store(escritor, "Partida guardada de La casa sin salida");
            }
            try {
                Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporal);
        }
    }

    public DatosPartida cargar() throws IOException {
        if (!Files.isRegularFile(archivo)) {
            throw new IOException("No existe una partida guardada.");
        }

        Properties propiedades = new Properties();
        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }
        if (!VERSION.equals(propiedades.getProperty("version"))) {
            throw new IOException("La partida guardada tiene una versión desconocida.");
        }

        try {
            List<String> inventario = new ArrayList<>(Inventory.CAPACIDAD_MAXIMA);
            for (int i = 0; i < Inventory.CAPACIDAD_MAXIMA; i++) {
                inventario.add(obtener(propiedades, "inventario." + i));
            }
            return new DatosPartida(
                    decimal(propiedades, "jugador.x"),
                    decimal(propiedades, "jugador.y"),
                    decimal(propiedades, "reaparicion.x"),
                    decimal(propiedades, "reaparicion.y"),
                    entero(propiedades, "jugador.salud"),
                    flotante(propiedades, "jugador.stamina"),
                    flotante(propiedades, "linterna.bateria"),
                    booleano(propiedades, "linterna.encendida"),
                    decimal(propiedades, "entidad.x"),
                    decimal(propiedades, "entidad.y"),
                    largo(propiedades, "entidad.paralisis"),
                    largo(propiedades, "taser.cooldown"),
                    entero(propiedades, "piezas"),
                    booleano(propiedades, "puzzle.resuelto"),
                    booleano(propiedades, "partida.ganada"),
                    entero(propiedades, "inventario.seleccion"),
                    inventario,
                    obtener(propiedades, "mapa.actual"),
                    leerMapas(propiedades));
        } catch (IllegalArgumentException ex) {
            throw new IOException("La partida guardada está dañada o contiene datos inválidos.",
                    ex);
        }
    }

    public boolean eliminar() throws IOException {
        return Files.deleteIfExists(archivo);
    }

    public boolean existe() {
        return Files.isRegularFile(archivo);
    }

    public Path getArchivo() {
        return archivo;
    }

    private Properties serializar(DatosPartida datos) {
        if (datos == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }
        Properties propiedades = new Properties();
        propiedades.setProperty("version", VERSION);
        propiedades.setProperty("jugador.x", Double.toString(datos.jugadorX()));
        propiedades.setProperty("jugador.y", Double.toString(datos.jugadorY()));
        propiedades.setProperty("reaparicion.x", Double.toString(datos.puntoReaparicionX()));
        propiedades.setProperty("reaparicion.y", Double.toString(datos.puntoReaparicionY()));
        propiedades.setProperty("jugador.salud", Integer.toString(datos.salud()));
        propiedades.setProperty("jugador.stamina", Float.toString(datos.stamina()));
        propiedades.setProperty("linterna.bateria", Float.toString(datos.bateria()));
        propiedades.setProperty("linterna.encendida",
                Boolean.toString(datos.linternaEncendida()));
        propiedades.setProperty("entidad.x", Double.toString(datos.entidadX()));
        propiedades.setProperty("entidad.y", Double.toString(datos.entidadY()));
        propiedades.setProperty("entidad.paralisis",
                Long.toString(datos.paralisisRestanteMs()));
        propiedades.setProperty("taser.cooldown",
                Long.toString(datos.taserCooldownRestanteMs()));
        propiedades.setProperty("piezas", Integer.toString(datos.piezas()));
        propiedades.setProperty("puzzle.resuelto", Boolean.toString(datos.puzzleResuelto()));
        propiedades.setProperty("partida.ganada", Boolean.toString(datos.gano()));
        propiedades.setProperty("inventario.seleccion",
                Integer.toString(datos.slotSeleccionado()));
        if (datos.inventario().size() != Inventory.CAPACIDAD_MAXIMA) {
            throw new IllegalArgumentException("El inventario guardado tiene un tamaño inválido.");
        }
        for (int i = 0; i < datos.inventario().size(); i++) {
            propiedades.setProperty("inventario." + i, datos.inventario().get(i));
        }
        propiedades.setProperty("mapa.actual", datos.mapaActualId());
        propiedades.setProperty("mapas.cantidad", Integer.toString(datos.mapas().size()));
        for (int i = 0; i < datos.mapas().size(); i++) {
            DatosMapa mapa = datos.mapas().get(i);
            String prefijo = "mapa." + i + ".";
            propiedades.setProperty(prefijo + "id", mapa.id());
            propiedades.setProperty(prefijo + "objetos",
                    String.join(",", mapa.objetosPresentes()));
            propiedades.setProperty(prefijo + "suelo.cantidad",
                    Integer.toString(mapa.objetosSuelo().size()));
            for (int j = 0; j < mapa.objetosSuelo().size(); j++) {
                DatosObjetoSuelo objeto = mapa.objetosSuelo().get(j);
                propiedades.setProperty(prefijo + "suelo." + j,
                        objeto.id() + "|" + objeto.x() + "|" + objeto.y());
            }
        }
        return propiedades;
    }

    private static List<DatosMapa> leerMapas(Properties propiedades) {
        int cantidad = entero(propiedades, "mapas.cantidad");
        if (cantidad < 1 || cantidad > 100) {
            throw new IllegalArgumentException("La cantidad de mapas guardados no es válida.");
        }
        List<DatosMapa> mapas = new ArrayList<>(cantidad);
        for (int i = 0; i < cantidad; i++) {
            String prefijo = "mapa." + i + ".";
            List<DatosObjetoSuelo> objetosSuelo = leerObjetosSuelo(
                    propiedades, prefijo + "suelo.");
            mapas.add(new DatosMapa(obtener(propiedades, prefijo + "id"),
                    lista(obtener(propiedades, prefijo + "objetos")), objetosSuelo));
        }
        return mapas;
    }

    private static List<DatosObjetoSuelo> leerObjetosSuelo(Properties propiedades,
            String prefijo) {
        String cantidadTexto = propiedades.getProperty(prefijo + "cantidad", "0").trim();
        int cantidad = Integer.parseInt(cantidadTexto);
        if (cantidad < 0 || cantidad > 1000) {
            throw new IllegalArgumentException("La cantidad de objetos del suelo no es válida.");
        }
        List<DatosObjetoSuelo> objetos = new ArrayList<>(cantidad);
        for (int i = 0; i < cantidad; i++) {
            String[] campos = obtener(propiedades, prefijo + i).split("\\|", -1);
            if (campos.length != 3 || campos[0].isBlank()) {
                throw new IllegalArgumentException("Un objeto del suelo está dañado.");
            }
            objetos.add(new DatosObjetoSuelo(campos[0],
                    Double.parseDouble(campos[1]), Double.parseDouble(campos[2])));
        }
        return objetos;
    }

    private static String obtener(Properties propiedades, String clave) {
        String valor = propiedades.getProperty(clave);
        if (valor == null) {
            throw new IllegalArgumentException("Falta el dato " + clave + ".");
        }
        return valor.trim();
    }

    private static double decimal(Properties propiedades, String clave) {
        return Double.parseDouble(obtener(propiedades, clave));
    }

    private static float flotante(Properties propiedades, String clave) {
        return Float.parseFloat(obtener(propiedades, clave));
    }

    private static int entero(Properties propiedades, String clave) {
        return Integer.parseInt(obtener(propiedades, clave));
    }

    private static long largo(Properties propiedades, String clave) {
        return Long.parseLong(obtener(propiedades, clave));
    }

    private static boolean booleano(Properties propiedades, String clave) {
        String valor = obtener(propiedades, clave);
        if (!"true".equalsIgnoreCase(valor) && !"false".equalsIgnoreCase(valor)) {
            throw new IllegalArgumentException("El dato " + clave + " debe ser true o false.");
        }
        return Boolean.parseBoolean(valor);
    }

    private static List<String> lista(String valor) {
        if (valor.isBlank()) {
            return List.of();
        }
        return List.of(valor.split(",", -1));
    }
}
