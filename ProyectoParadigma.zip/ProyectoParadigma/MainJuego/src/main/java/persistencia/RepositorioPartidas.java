package persistencia;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import modelo.DatosPartida;
import modelo.DatosObjetoSuelo;
import modelo.DatosMapa;
import modelo.Inventario;

public class RepositorioPartidas {
    private static final String VERSION = "5";
    private static final String VERSION_ANTERIOR = "4";
    private static final String VERSION_ANTERIOR_2 = "3";
    private static final String ID_GUARDADO_ANTERIOR = "guardado-anterior";
    private final Path archivo;
    private final Path directorioPartidas;

    public RepositorioPartidas() {
        this(Path.of(System.getProperty("user.home", "."),
                ".mainjuego", "partida.properties"));
    }

    public RepositorioPartidas(Path archivo) {
        this.archivo = archivo.toAbsolutePath().normalize();
        this.directorioPartidas = this.archivo.resolveSibling("partidas");
    }

    public void guardar(DatosPartida datos) throws IOException {
        Properties propiedades = serializar(datos);
        guardarArchivo(archivo, propiedades);
    }

    public ResumenPartida guardarNueva(DatosPartida datos) throws IOException {
        Properties propiedades = serializar(datos);
        Files.createDirectories(directorioPartidas);
        String id = UUID.randomUUID().toString();
        Path destino = directorioPartidas.resolve(id + ".properties");
        guardarArchivo(destino, propiedades);
        return new ResumenPartida(id, datos.nombreJugador(),
                datos.tiempoTranscurridoMs(), System.currentTimeMillis());
    }

    private void guardarArchivo(Path destino, Properties propiedades) throws IOException {
        Path directorio = destino.getParent();
        Files.createDirectories(directorio);
        Path temporal = Files.createTempFile(directorio, "partida-", ".tmp");
        try {
            try (Writer escritor = Files.newBufferedWriter(temporal, StandardCharsets.UTF_8)) {
                propiedades.store(escritor, "Partida guardada de Escapando de la FACE");
            }
            try {
                Files.move(temporal, destino, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporal, destino, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporal);
        }
    }

    public DatosPartida cargar() throws IOException {
        return cargarArchivo(archivo);
    }

    public DatosPartida cargar(String id) throws IOException {
        if (id == null) {
            throw new IllegalArgumentException("El identificador de partida no es válido.");
        }
        if (ID_GUARDADO_ANTERIOR.equals(id)) {
            return cargar();
        }
        final String nombreArchivo;
        try {
            nombreArchivo = UUID.fromString(id).toString() + ".properties";
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("El identificador de partida no es válido.", ex);
        }
        return cargarArchivo(directorioPartidas.resolve(nombreArchivo));
    }

    public ListadoPartidas listarPartidas() throws IOException {
        List<ResumenPartida> partidas = new ArrayList<>();
        boolean guardadoAnteriorNoCompatible = false;
        if (Files.isRegularFile(archivo)) {
            String version = leerVersion(archivo);
            if (esVersionCompatible(version)) {
                agregarResumen(partidas, ID_GUARDADO_ANTERIOR, archivo);
            } else {
                guardadoAnteriorNoCompatible = true;
            }
        }
        if (Files.isDirectory(directorioPartidas)) {
            try (var archivos = Files.newDirectoryStream(directorioPartidas, "*.properties")) {
                for (Path ruta : archivos) {
                    String nombre = ruta.getFileName().toString();
                    String id = nombre.substring(0, nombre.length() - ".properties".length());
                    try {
                        id = UUID.fromString(id).toString();
                    } catch (IllegalArgumentException ex) {
                        continue;
                    }
                    agregarResumen(partidas, id, ruta);
                }
            }
        }
        partidas.sort(Comparator.comparingLong(ResumenPartida::guardadoEnMs).reversed());
        return new ListadoPartidas(partidas, guardadoAnteriorNoCompatible);
    }

    private String leerVersion(Path ruta) throws IOException {
        Properties propiedades = new Properties();
        try (Reader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }
        return propiedades.getProperty("version");
    }

    private void agregarResumen(List<ResumenPartida> partidas, String id, Path ruta)
            throws IOException {
        DatosPartida datos = cargarArchivo(ruta);
        partidas.add(new ResumenPartida(id, datos.nombreJugador(),
                datos.tiempoTranscurridoMs(), Files.getLastModifiedTime(ruta).toMillis()));
    }

    private DatosPartida cargarArchivo(Path ruta) throws IOException {
        if (!Files.isRegularFile(ruta)) {
            throw new IOException("No existe una partida guardada.");
        }

        Properties propiedades = new Properties();
        try (Reader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }
        String version = propiedades.getProperty("version");
        if (!esVersionCompatible(version)) {
            throw new IOException("La partida guardada tiene una versión desconocida.");
        }

        try {
            List<String> inventario = new ArrayList<>(Inventario.CAPACIDAD_MAXIMA);
            for (int i = 0; i < Inventario.CAPACIDAD_MAXIMA; i++) {
                inventario.add(obtener(propiedades, "inventario." + i));
            }
            return new DatosPartida(
                    decimal(propiedades, "jugador.x"),
                    decimal(propiedades, "jugador.y"),
                    decimal(propiedades, "reaparicion.x"),
                    decimal(propiedades, "reaparicion.y"),
                    entero(propiedades, "jugador.salud"),
                    flotante(propiedades, "jugador.stamina"),
                    flotante(propiedades, "linterna.bateria"),
                    booleano(propiedades, "linterna.encendida"),
                    decimal(propiedades, "entidad.x"),
                    decimal(propiedades, "entidad.y"),
                    largo(propiedades, "entidad.paralisis"),
                    largo(propiedades, "taser.cooldown"),
                    entero(propiedades, "piezas"),
                    booleano(propiedades, "puzzle.resuelto"),
                    booleano(propiedades, "partida.ganada"),
                    entero(propiedades, "inventario.seleccion"),
                    inventario,
                    obtener(propiedades, "mapa.actual"),
                    leerMapas(propiedades),
                    !VERSION_ANTERIOR_2.equals(version)
                            ? obtener(propiedades, "jugador.nombre") : "Jugador",
                    !VERSION_ANTERIOR_2.equals(version)
                            ? largo(propiedades, "partida.tiempo.ms") : 0,
                    VERSION.equals(version) ? entero(propiedades, "acertijo.id") : 0);
        } catch (IllegalArgumentException ex) {
            throw new IOException("La partida guardada está dañada o contiene datos inválidos.",
                    ex);
        }
    }

    private boolean esVersionCompatible(String version) {
        return VERSION.equals(version) || VERSION_ANTERIOR.equals(version)
                || VERSION_ANTERIOR_2.equals(version);
    }

    public boolean eliminar() throws IOException {
        return Files.deleteIfExists(archivo);
    }

    public boolean eliminar(String id) throws IOException {
        if (ID_GUARDADO_ANTERIOR.equals(id)) {
            return eliminar();
        }
        if (id == null) {
            throw new IllegalArgumentException("El identificador de partida no es válido.");
        }
        final String nombreArchivo;
        try {
            nombreArchivo = UUID.fromString(id).toString() + ".properties";
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("El identificador de partida no es válido.", ex);
        }
        return Files.deleteIfExists(directorioPartidas.resolve(nombreArchivo));
    }

    public boolean existe() {
        return Files.isRegularFile(archivo);
    }

    public Path getArchivo() {
        return archivo;
    }

    private Properties serializar(DatosPartida datos) {
        if (datos == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }
        Properties propiedades = new Properties();
        propiedades.setProperty("version", VERSION);
        propiedades.setProperty("jugador.x", Double.toString(datos.jugadorX()));
        propiedades.setProperty("jugador.y", Double.toString(datos.jugadorY()));
        propiedades.setProperty("reaparicion.x", Double.toString(datos.puntoReaparicionX()));
        propiedades.setProperty("reaparicion.y", Double.toString(datos.puntoReaparicionY()));
        propiedades.setProperty("jugador.salud", Integer.toString(datos.salud()));
        propiedades.setProperty("jugador.stamina", Float.toString(datos.stamina()));
        propiedades.setProperty("linterna.bateria", Float.toString(datos.bateria()));
        propiedades.setProperty("linterna.encendida",
                Boolean.toString(datos.linternaEncendida()));
        propiedades.setProperty("entidad.x", Double.toString(datos.entidadX()));
        propiedades.setProperty("entidad.y", Double.toString(datos.entidadY()));
        propiedades.setProperty("entidad.paralisis",
                Long.toString(datos.paralisisRestanteMs()));
        propiedades.setProperty("taser.cooldown",
                Long.toString(datos.taserCooldownRestanteMs()));
        propiedades.setProperty("piezas", Integer.toString(datos.piezas()));
        propiedades.setProperty("puzzle.resuelto", Boolean.toString(datos.puzzleResuelto()));
        propiedades.setProperty("partida.ganada", Boolean.toString(datos.gano()));
        propiedades.setProperty("jugador.nombre", datos.nombreJugador());
        propiedades.setProperty("partida.tiempo.ms",
                Long.toString(datos.tiempoTranscurridoMs()));
        propiedades.setProperty("acertijo.id", Integer.toString(datos.acertijoId()));
        propiedades.setProperty("inventario.seleccion",
                Integer.toString(datos.slotSeleccionado()));
        if (datos.inventario().size() != Inventario.CAPACIDAD_MAXIMA) {
            throw new IllegalArgumentException("El inventario guardado tiene un tamaño inválido.");
        }
        for (int i = 0; i < datos.inventario().size(); i++) {
            propiedades.setProperty("inventario." + i, datos.inventario().get(i));
        }
        propiedades.setProperty("mapa.actual", datos.mapaActualId());
        propiedades.setProperty("mapas.cantidad", Integer.toString(datos.mapas().size()));
        for (int i = 0; i < datos.mapas().size(); i++) {
            DatosMapa mapa = datos.mapas().get(i);
            String prefijo = "mapa." + i + ".";
            propiedades.setProperty(prefijo + "id", mapa.id());
            propiedades.setProperty(prefijo + "objetos",
                    String.join(",", mapa.objetosPresentes()));
            propiedades.setProperty(prefijo + "suelo.cantidad",
                    Integer.toString(mapa.objetosSuelo().size()));
            for (int j = 0; j < mapa.objetosSuelo().size(); j++) {
                DatosObjetoSuelo objeto = mapa.objetosSuelo().get(j);
                propiedades.setProperty(prefijo + "suelo." + j,
                        objeto.id() + "|" + objeto.x() + "|" + objeto.y());
            }
        }
        return propiedades;
    }

    private static List<DatosMapa> leerMapas(Properties propiedades) {
        int cantidad = entero(propiedades, "mapas.cantidad");
        if (cantidad < 1 || cantidad > 100) {
            throw new IllegalArgumentException("La cantidad de mapas guardados no es válida.");
        }
        List<DatosMapa> mapas = new ArrayList<>(cantidad);
        for (int i = 0; i < cantidad; i++) {
            String prefijo = "mapa." + i + ".";
            List<DatosObjetoSuelo> objetosSuelo = leerObjetosSuelo(
                    propiedades, prefijo + "suelo.");
            mapas.add(new DatosMapa(obtener(propiedades, prefijo + "id"),
                    lista(obtener(propiedades, prefijo + "objetos")), objetosSuelo));
        }
        return mapas;
    }

    private static List<DatosObjetoSuelo> leerObjetosSuelo(Properties propiedades,
            String prefijo) {
        String cantidadTexto = propiedades.getProperty(prefijo + "cantidad", "0").trim();
        int cantidad = Integer.parseInt(cantidadTexto);
        if (cantidad < 0 || cantidad > 1000) {
            throw new IllegalArgumentException("La cantidad de objetos del suelo no es válida.");
        }
        List<DatosObjetoSuelo> objetos = new ArrayList<>(cantidad);
        for (int i = 0; i < cantidad; i++) {
            String[] campos = obtener(propiedades, prefijo + i).split("\\|", -1);
            if (campos.length != 3 || campos[0].isBlank()) {
                throw new IllegalArgumentException("Un objeto del suelo está dañado.");
            }
            objetos.add(new DatosObjetoSuelo(campos[0],
                    Double.parseDouble(campos[1]), Double.parseDouble(campos[2])));
        }
        return objetos;
    }

    private static String obtener(Properties propiedades, String clave) {
        String valor = propiedades.getProperty(clave);
        if (valor == null) {
            throw new IllegalArgumentException("Falta el dato " + clave + ".");
        }
        return valor.trim();
    }

    private static double decimal(Properties propiedades, String clave) {
        return Double.parseDouble(obtener(propiedades, clave));
    }

    private static float flotante(Properties propiedades, String clave) {
        return Float.parseFloat(obtener(propiedades, clave));
    }

    private static int entero(Properties propiedades, String clave) {
        return Integer.parseInt(obtener(propiedades, clave));
    }

    private static long largo(Properties propiedades, String clave) {
        return Long.parseLong(obtener(propiedades, clave));
    }

    private static boolean booleano(Properties propiedades, String clave) {
        String valor = obtener(propiedades, clave);
        if (!"true".equalsIgnoreCase(valor) && !"false".equalsIgnoreCase(valor)) {
            throw new IllegalArgumentException("El dato " + clave + " debe ser true o false.");
        }
        return Boolean.parseBoolean(valor);
    }

    private static List<String> lista(String valor) {
        if (valor.isBlank()) {
            return List.of();
        }
        return List.of(valor.split(",", -1));
    }
}
