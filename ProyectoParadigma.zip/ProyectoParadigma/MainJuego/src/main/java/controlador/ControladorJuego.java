package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import modelo.EstadoJuego;
import modelo.Mapa;
import modelo.Player;
import persistencia.RepositorioPartidas;
import vista.PanelJuego;

public class ControladorJuego {
    private final EstadoJuego estado;
    private final PanelJuego vista;
    private final RepositorioPartidas repositorio;
    private final Map<String, Boolean> teclasPresionadas = new HashMap<>();
    private final Timer temporizador;
    private long ultimoFrameNs;

    public ControladorJuego(EstadoJuego estado, PanelJuego vista) {
        this(estado, vista, new RepositorioPartidas());
    }

    public ControladorJuego(EstadoJuego estado, PanelJuego vista,
            RepositorioPartidas repositorio) {
        this.estado = estado;
        this.vista = vista;
        this.repositorio = repositorio;
        instalarControles();
        temporizador = new Timer(16, event -> actualizarJuego());
        temporizador.setCoalesce(true);
    }

    public JMenuBar crearBarraMenu() {
        JMenuBar barra = new JMenuBar();
        JMenu menuPartida = new JMenu("Partida");
        agregarOpcion(menuPartida, "Guardar partida", KeyEvent.VK_S,
                this::guardarPartida);
        agregarOpcion(menuPartida, "Cargar partida", KeyEvent.VK_O,
                this::cargarPartida);
        agregarOpcion(menuPartida, "Eliminar partida guardada", KeyEvent.VK_DELETE,
                this::eliminarPartida);
        barra.add(menuPartida);
        return barra;
    }

    private void agregarOpcion(JMenu menu, String texto, int tecla, Runnable accion) {
        JMenuItem opcion = new JMenuItem(texto);
        opcion.setAccelerator(KeyStroke.getKeyStroke(tecla, InputEvent.CTRL_DOWN_MASK));
        opcion.addActionListener(evento -> accion.run());
        menu.add(opcion);
    }

    private void guardarPartida() {
        try {
            repositorio.guardar(estado.crearDatosPartida());
            JOptionPane.showMessageDialog(vista,
                    "Partida guardada correctamente.\n" + repositorio.getArchivo(),
                    "Guardar partida", JOptionPane.INFORMATION_MESSAGE);
        } catch (java.io.IOException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(),
                    "No se pudo guardar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarPartida() {
        int respuesta = JOptionPane.showConfirmDialog(vista,
                "Al cargar se reemplazará el progreso actual no guardado. ¿Continuar?",
                "Cargar partida", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            estado.restaurarPartida(repositorio.cargar());
            teclasPresionadas.clear();
            ultimoFrameNs = System.nanoTime();
            vista.repaint();
        } catch (java.io.IOException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(),
                    "No se pudo cargar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarPartida() {
        int respuesta = JOptionPane.showConfirmDialog(vista,
                "¿Quieres eliminar la partida guardada?",
                "Eliminar partida", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (repositorio.eliminar()) {
                JOptionPane.showMessageDialog(vista, "Partida guardada eliminada.",
                        "Eliminar partida", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "No hay una partida guardada.",
                        "Eliminar partida", JOptionPane.WARNING_MESSAGE);
            }
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(),
                    "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void iniciar() {
        ultimoFrameNs = System.nanoTime();
        temporizador.start();
        vista.requestFocusInWindow();
    }

    private void actualizarJuego() {
        long ahora = System.nanoTime();
        double deltaTiempo = Math.min((ahora - ultimoFrameNs) / 1_000_000_000.0, 0.05);
        ultimoFrameNs = ahora;

        double x = (estaPresionada("D") || estaPresionada("RIGHT") ? 1 : 0)
                - (estaPresionada("A") || estaPresionada("LEFT") ? 1 : 0);
        double y = (estaPresionada("S") || estaPresionada("DOWN") ? 1 : 0)
                - (estaPresionada("W") || estaPresionada("UP") ? 1 : 0);
        boolean correr = estaPresionada("SHIFT");

        estado.actualizar(deltaTiempo, x, y, correr);
        vista.repaint();
    }

    private boolean estaPresionada(String tecla) {
        return Boolean.TRUE.equals(teclasPresionadas.get(tecla));
    }

    private void instalarControles() {
        InputMap entrada = vista.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap acciones = vista.getActionMap();

        vincularMovimiento(entrada, acciones, "W", "W");
        vincularMovimiento(entrada, acciones, "A", "A");
        vincularMovimiento(entrada, acciones, "S", "S");
        vincularMovimiento(entrada, acciones, "D", "D");
        vincularMovimiento(entrada, acciones, "UP", "UP");
        vincularMovimiento(entrada, acciones, "LEFT", "LEFT");
        vincularMovimiento(entrada, acciones, "DOWN", "DOWN");
        vincularMovimiento(entrada, acciones, "RIGHT", "RIGHT");
        vincularMovimiento(entrada, acciones, "SHIFT", "SHIFT");

        vincularAccion(entrada, acciones, "pressed E", "interactuar", estado::interactuar);
        vincularAccion(entrada, acciones, "pressed SPACE", "usar",
                this::usarObjetoSeleccionado);
        vincularAccion(entrada, acciones, "pressed B", "libro", this::abrirLibro);
        vincularAccion(entrada, acciones, "pressed F", "linterna", estado::alternarLinterna);
        vincularAccion(entrada, acciones, "pressed Q", "botar",
                estado::soltarObjetoSeleccionado);
        for (int numero = 1; numero <= 9; numero++) {
            final int slot = numero - 1;
            vincularAccion(entrada, acciones, "pressed " + numero, "slot" + numero,
                    () -> estado.seleccionarSlot(slot));
        }

        vista.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evento) {
                vista.requestFocusInWindow();
                if (SwingUtilities.isLeftMouseButton(evento)) {
                    actualizarApuntado(evento);
                    estado.dispararTaser();
                }
            }
        });
        vista.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent evento) {
                actualizarApuntado(evento);
            }

            @Override
            public void mouseDragged(MouseEvent evento) {
                actualizarApuntado(evento);
            }
        });
    }

    private void vincularMovimiento(InputMap entrada, ActionMap acciones,
            String tecla, String identificador) {
        vincularAccion(entrada, acciones, "pressed " + tecla,
                "presionar-" + identificador, () -> teclasPresionadas.put(identificador, true));
        vincularAccion(entrada, acciones, "released " + tecla,
                "soltar-" + identificador, () -> teclasPresionadas.put(identificador, false));
    }

    private void vincularAccion(InputMap entrada, ActionMap acciones, String tecla,
            String identificador, Runnable accion) {
        entrada.put(KeyStroke.getKeyStroke(tecla), identificador);
        acciones.put(identificador, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent evento) {
                accion.run();
                vista.repaint();
            }
        });
    }

    private void actualizarApuntado(MouseEvent evento) {
        Player jugador = estado.getJugador();
        double centroX = jugador.getX() + jugador.getAncho() / 2.0;
        double centroY = jugador.getY() + jugador.getAlto() / 2.0;
        jugador.setAnguloApuntado(Math.atan2(evento.getY() - centroY,
                evento.getX() - centroX));
        vista.repaint();
    }

    private void abrirLibro() {
        if (!estado.abrirLibro()) {
            vista.repaint();
            return;
        }
        String respuesta = JOptionPane.showInputDialog(vista,
                "El acertijo se detendrá mientras lees.\n"
                + "Las pistas del libro son: lados de un triángulo, "
                + "ojo de la entidad y patas de una mesa.\n"
                + "Escribe el código de tres cifras:",
                "Libro de acertijos", JOptionPane.QUESTION_MESSAGE);
        estado.resolverPuzzle(respuesta);
        vista.repaint();
    }

    private void usarObjetoSeleccionado() {
        if (estado.getJugador().getInventario().getItemSeleccionado() != null
                && "LIBRO_PUZZLE".equals(estado.getJugador().getInventario()
                        .getItemSeleccionado().getId())) {
            abrirLibro();
        } else {
            estado.usarObjetoSeleccionado();
        }
    }
}
