package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.BorderLayout;
import java.util.HashMap;
import java.util.Map;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import modelo.EstadoJuego;
import modelo.Mapa;
import modelo.Player;
import modelo.RegistroPuntaje;
import persistencia.RepositorioPartidas;
import persistencia.RepositorioRanking;
import persistencia.ListadoPartidas;
import persistencia.ResumenPartida;
import vista.PanelJuego;

public class ControladorJuego {
    private final EstadoJuego estado;
    private final PanelJuego vista;
    private final RepositorioPartidas repositorio;
    private final RepositorioRanking repositorioRanking;
    private final Map<String, Boolean> teclasPresionadas = new HashMap<>();
    private final Timer temporizador;
    private JFrame ventana;
    private JPanel panelPrincipal;
    private CardLayout tarjetas;
    private boolean enJuego;
    private boolean pausado;
    private boolean resultadoRegistrado;
    private long ultimoFrameNs;

    public ControladorJuego(EstadoJuego estado, PanelJuego vista) {
        this(estado, vista, new RepositorioPartidas(), new RepositorioRanking());
    }

    public ControladorJuego(EstadoJuego estado, PanelJuego vista,
            RepositorioPartidas repositorio) {
        this(estado, vista, repositorio, new RepositorioRanking());
    }

    public ControladorJuego(EstadoJuego estado, PanelJuego vista,
            RepositorioPartidas repositorio, RepositorioRanking repositorioRanking) {
        this.estado = estado;
        this.vista = vista;
        this.repositorio = repositorio;
        this.repositorioRanking = repositorioRanking;
        instalarControles();
        temporizador = new Timer(16, event -> actualizarJuego());
        temporizador.setCoalesce(true);
    }

    public JMenuBar crearBarraMenu() {
        JMenuBar barra = new JMenuBar();
        JMenu menuPartida = new JMenu("Partida");
        agregarOpcion(menuPartida, "Guardar partida", KeyEvent.VK_S,
                this::guardarPartida);
        agregarOpcion(menuPartida, "Cargar partida", KeyEvent.VK_O,
                this::cargarPartida);
        agregarOpcion(menuPartida, "Eliminar partida guardada", KeyEvent.VK_DELETE,
                this::eliminarPartida);
        barra.add(menuPartida);
        return barra;
    }

    public void configurarVentana(JFrame ventana) {
        this.ventana = ventana;
        tarjetas = new CardLayout();
        panelPrincipal = new JPanel(tarjetas);
        panelPrincipal.add(crearMenuPrincipal(), "menu");
        panelPrincipal.add(vista, "juego");
        ventana.setJMenuBar(null);
        ventana.setContentPane(panelPrincipal);
        tarjetas.show(panelPrincipal, "menu");
    }

    private JPanel crearMenuPrincipal() {
        JPanel menu = new JPanel();
        menu.setBackground(new Color(13, 16, 20));
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBorder(BorderFactory.createEmptyBorder(120, 20, 100, 20));

        JLabel titulo = new JLabel("ESCAPANDO DE LA FACE");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setForeground(new Color(224, 207, 171));
        titulo.setFont(new Font(Font.SERIF, Font.BOLD, 38));
        menu.add(titulo);
        menu.add(Box.createVerticalStrut(18));

        JLabel subtitulo = new JLabel("un juego de suspenso y acertijos");
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitulo.setForeground(new Color(166, 170, 174));
        subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        menu.add(subtitulo);
        menu.add(Box.createVerticalStrut(55));

        agregarBotonMenu(menu, "Nueva partida", this::nuevaPartida);
        agregarBotonMenu(menu, "Cargar partida", this::cargarPartidaDesdeMenu);
        agregarBotonMenu(menu, "Ranking", this::mostrarRanking);
        agregarBotonMenu(menu, "Salir", this::salir);
        return menu;
    }

    private void agregarBotonMenu(JPanel menu, String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        boton.setForeground(Color.WHITE);
        boton.setBackground(new Color(48, 52, 59));
        boton.setFocusPainted(false);
        boton.setPreferredSize(new java.awt.Dimension(250, 48));
        boton.setMaximumSize(new java.awt.Dimension(250, 48));
        boton.addActionListener(evento -> accion.run());
        menu.add(boton);
        menu.add(Box.createVerticalStrut(14));
    }

    private void nuevaPartida() {
        String nombre = JOptionPane.showInputDialog(ventana,
                "Ingresa tu nombre para registrar tu tiempo:",
                "Nueva partida", JOptionPane.QUESTION_MESSAGE);
        if (nombre == null) {
            return;
        }
        nombre = nombre.trim();
        if (nombre.isEmpty() || nombre.length() > 40) {
            JOptionPane.showMessageDialog(ventana,
                    "El nombre debe tener entre 1 y 40 caracteres.",
                    "Nombre no válido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        nuevaPartida(nombre);
    }

    private void nuevaPartida(String nombre) {
        estado.reiniciarPartida(nombre);
        pausado = false;
        resultadoRegistrado = false;
        vista.setPausado(false);
        mostrarJuego();
    }

    private void mostrarRanking() {
        try {
            var registros = repositorioRanking.listar();
            if (registros.isEmpty()) {
                JOptionPane.showMessageDialog(ventana, "Todavía no hay tiempos registrados.",
                        "Ranking", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            StringBuilder texto = new StringBuilder("Mejores tiempos:\n\n");
            texto.append(String.format("%2s %-40s %-8s %s%n",
                    "#", "Jugador", "Tiempo", "Finalizada"));
            for (int i = 0; i < registros.size(); i++) {
                RegistroPuntaje registro = registros.get(i);
                texto.append(String.format("%2d. %-40s %-8s %s%n", i + 1,
                        registro.nombreJugador(), formatearTiempo(registro.tiempoMs()),
                        java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
                                .format(java.time.Instant.ofEpochMilli(registro.fechaMs())
                                        .atZone(java.time.ZoneId.systemDefault()))));
            }
            JOptionPane.showMessageDialog(ventana, texto.toString(),
                    "Ranking", JOptionPane.INFORMATION_MESSAGE);
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(ventana, ex.getMessage(),
                    "No se pudo leer el ranking", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarPartidaDesdeMenu() {
        try {
            while (true) {
                ListadoPartidas listado = repositorio.listarPartidas();
                var partidas = listado.partidas();
                if (partidas.isEmpty()) {
                    JOptionPane.showMessageDialog(ventana,
                            "No se ha encontrado ninguna partida guardada.",
                            "Cargar partida", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                DefaultTableModel modelo = new DefaultTableModel(
                        new Object[]{"Jugador", "Tiempo de partida", "Guardada"}, 0) {
                    @Override
                    public boolean isCellEditable(int fila, int columna) {
                        return false;
                    }
                };
                for (ResumenPartida partida : partidas) {
                    modelo.addRow(new Object[]{partida.nombreJugador(),
                        formatearTiempo(partida.tiempoTranscurridoMs()),
                        java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
                                .format(java.time.Instant.ofEpochMilli(partida.guardadoEnMs())
                                        .atZone(java.time.ZoneId.systemDefault()))});
                }
                JTable tabla = new JTable(modelo);
                tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                tabla.setRowSelectionInterval(0, 0);
                JScrollPane contenido = new JScrollPane(tabla);
                contenido.setPreferredSize(new java.awt.Dimension(560, 220));
                JPanel panelLista = new JPanel(new BorderLayout(0, 8));
                if (listado.guardadoAnteriorNoCompatible()) {
                    panelLista.add(new JLabel(
                            "Se omitió un guardado antiguo incompatible."), BorderLayout.NORTH);
                }
                panelLista.add(contenido, BorderLayout.CENTER);
                int respuesta = JOptionPane.showOptionDialog(ventana, panelLista,
                        "Partidas guardadas", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null,
                        new Object[]{"Cargar", "Borrar", "Cancelar"}, "Cargar");
                if (respuesta == 2 || respuesta == JOptionPane.CLOSED_OPTION) {
                    return;
                }
                int fila = tabla.getSelectedRow();
                if (fila < 0 || fila >= partidas.size()) {
                    JOptionPane.showMessageDialog(ventana,
                            "Selecciona una partida de la lista.",
                            "Partidas guardadas", JOptionPane.WARNING_MESSAGE);
                    continue;
                }
                ResumenPartida seleccionada = partidas.get(fila);
                if (respuesta == 1) {
                    int confirmar = JOptionPane.showConfirmDialog(ventana,
                            "¿Eliminar la partida de " + seleccionada.nombreJugador() + "?",
                            "Borrar partida", JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    if (confirmar == JOptionPane.YES_OPTION
                            && !repositorio.eliminar(seleccionada.id())) {
                        JOptionPane.showMessageDialog(ventana,
                                "La partida ya no existe.",
                                "Borrar partida", JOptionPane.WARNING_MESSAGE);
                    }
                    continue;
                }
                estado.restaurarPartida(repositorio.cargar(seleccionada.id()));
                mostrarJuego();
                return;
            }
        } catch (java.io.IOException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(ventana, ex.getMessage(),
                    "No se pudo procesar la partida", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarJuego() {
        enJuego = true;
        pausado = false;
        resultadoRegistrado = estado.isGano();
        vista.setPausado(false);
        limpiarEntrada();
        ultimoFrameNs = System.nanoTime();
        ventana.setJMenuBar(crearBarraMenu());
        tarjetas.show(panelPrincipal, "juego");
        ventana.revalidate();
        vista.requestFocusInWindow();
        vista.repaint();
    }

    private void mostrarMenuPrincipal() {
        enJuego = false;
        pausado = false;
        vista.setPausado(false);
        limpiarEntrada();
        ventana.setJMenuBar(null);
        tarjetas.show(panelPrincipal, "menu");
        ventana.revalidate();
    }

    private void salir() {
        if (ventana != null) {
            ventana.dispatchEvent(new java.awt.event.WindowEvent(
                    ventana, java.awt.event.WindowEvent.WINDOW_CLOSING));
        }
    }

    private void limpiarEntrada() {
        teclasPresionadas.clear();
    }

    private void agregarOpcion(JMenu menu, String texto, int tecla, Runnable accion) {
        JMenuItem opcion = new JMenuItem(texto);
        opcion.setAccelerator(KeyStroke.getKeyStroke(tecla, InputEvent.CTRL_DOWN_MASK));
        opcion.addActionListener(evento -> accion.run());
        menu.add(opcion);
    }

    private void guardarPartida() {
        try {
            ResumenPartida partida = repositorio.guardarNueva(estado.crearDatosPartida());
            JOptionPane.showMessageDialog(vista,
                    "Partida guardada correctamente.\nJugador: "
                    + partida.nombreJugador() + "\nTiempo: "
                    + formatearTiempo(partida.tiempoTranscurridoMs()),
                    "Guardar partida", JOptionPane.INFORMATION_MESSAGE);
        } catch (java.io.IOException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(),
                    "No se pudo guardar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarPartida() {
        if (!enJuego) {
            cargarPartidaDesdeMenu();
            return;
        }
        int respuesta = JOptionPane.showConfirmDialog(vista,
                "Al cargar se reemplazará el progreso actual no guardado. ¿Continuar?",
                "Cargar partida", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        cargarPartidaDesdeMenu();
    }

    private void eliminarPartida() {
        int respuesta = JOptionPane.showConfirmDialog(vista,
                "¿Quieres eliminar la partida guardada?",
                "Eliminar partida", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (repositorio.eliminar()) {
                JOptionPane.showMessageDialog(vista, "Partida guardada eliminada.",
                        "Eliminar partida", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "No hay una partida guardada.",
                        "Eliminar partida", JOptionPane.WARNING_MESSAGE);
            }
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(vista, ex.getMessage(),
                    "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void iniciar() {
        ultimoFrameNs = System.nanoTime();
        temporizador.start();
        vista.requestFocusInWindow();
    }

    private void actualizarJuego() {
        if (!enJuego || pausado) {
            return;
        }
        long ahora = System.nanoTime();
        long nanosegundosTranscurridos = Math.max(0, ahora - ultimoFrameNs);
        double deltaTiempo = Math.min(nanosegundosTranscurridos / 1_000_000_000.0, 0.05);
        ultimoFrameNs = ahora;
        if (estado.isJugadorVivo() && !estado.isGano()) {
            estado.sumarTiempoPartida(nanosegundosTranscurridos / 1_000_000);
        }

        double x = (estaPresionada("D") || estaPresionada("RIGHT") ? 1 : 0)
                - (estaPresionada("A") || estaPresionada("LEFT") ? 1 : 0);
        double y = (estaPresionada("S") || estaPresionada("DOWN") ? 1 : 0)
                - (estaPresionada("W") || estaPresionada("UP") ? 1 : 0);
        boolean correr = estaPresionada("SHIFT");

        boolean habiaGanado = estado.isGano();
        estado.actualizar(deltaTiempo, x, y, correr);
        if (!habiaGanado && estado.isGano()) {
            registrarVictoria();
        }
        vista.repaint();
    }

    private boolean estaPresionada(String tecla) {
        return Boolean.TRUE.equals(teclasPresionadas.get(tecla));
    }

    private void instalarControles() {
        InputMap entrada = vista.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap acciones = vista.getActionMap();

        vincularMovimiento(entrada, acciones, "W", "W");
        vincularMovimiento(entrada, acciones, "A", "A");
        vincularMovimiento(entrada, acciones, "S", "S");
        vincularMovimiento(entrada, acciones, "D", "D");
        vincularMovimiento(entrada, acciones, "UP", "UP");
        vincularMovimiento(entrada, acciones, "LEFT", "LEFT");
        vincularMovimiento(entrada, acciones, "DOWN", "DOWN");
        vincularMovimiento(entrada, acciones, "RIGHT", "RIGHT");
        vincularMovimiento(entrada, acciones, "SHIFT", "SHIFT");

        vincularAccion(entrada, acciones, "pressed ESCAPE", "pausa",
                this::alternarPausa);
        vincularAccion(entrada, acciones, "pressed E", "interactuar", estado::interactuar);
        vincularAccion(entrada, acciones, "pressed SPACE", "usar",
                this::usarObjetoSeleccionado);
        vincularAccion(entrada, acciones, "pressed B", "libro", this::abrirLibro);
        vincularAccion(entrada, acciones, "pressed F", "linterna", estado::alternarLinterna);
        vincularAccion(entrada, acciones, "pressed Q", "botar",
                estado::soltarObjetoSeleccionado);
        for (int numero = 1; numero <= 9; numero++) {
            final int slot = numero - 1;
            vincularAccion(entrada, acciones, "pressed " + numero, "slot" + numero,
                    () -> estado.seleccionarSlot(slot));
        }

        vista.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent evento) {
                if (!enJuego) {
                    return;
                }
                vista.requestFocusInWindow();
                if (estado.isGano()) {
                    switch (vista.obtenerAccionFinal(evento.getX(), evento.getY())) {
                        case VOLVER_A_JUGAR -> nuevaPartida(estado.getNombreJugador());
                        case MENU_PRINCIPAL -> mostrarMenuPrincipal();
                        case NINGUNA -> { }
                    }
                    return;
                }
                if (pausado) {
                    switch (vista.obtenerAccionPausa(evento.getX(), evento.getY())) {
                        case REANUDAR -> reanudar();
                        case GUARDAR_PARTIDA -> guardarPartida();
                        case MENU_PRINCIPAL -> volverAlMenuDesdePausa();
                        case NINGUNA -> { }
                    }
                    return;
                }
                if (!estado.isJugadorVivo()) {
                    switch (vista.obtenerAccionMuerte(evento.getX(), evento.getY())) {
                        case REINTENTAR -> nuevaPartida(estado.getNombreJugador());
                        case MENU_PRINCIPAL -> mostrarMenuPrincipal();
                        case NINGUNA -> { }
                    }
                    return;
                }
                if (SwingUtilities.isLeftMouseButton(evento)) {
                    actualizarApuntado(evento);
                    estado.dispararTaser();
                }
            }
        });
        vista.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent evento) {
                if (!enJuego || pausado || !estado.isJugadorVivo()) {
                    return;
                }
                actualizarApuntado(evento);
            }

            @Override
            public void mouseDragged(MouseEvent evento) {
                if (!enJuego || pausado || !estado.isJugadorVivo()) {
                    return;
                }
                actualizarApuntado(evento);
            }
        });
    }

    private void vincularMovimiento(InputMap entrada, ActionMap acciones,
            String tecla, String identificador) {
        String accionPresionar = "presionar-" + identificador;
        String accionSoltar = "soltar-" + identificador;
        vincularAccion(entrada, acciones, "pressed " + tecla,
                accionPresionar, () -> teclasPresionadas.put(identificador, true));
        vincularAccion(entrada, acciones, "released " + tecla,
                accionSoltar, () -> teclasPresionadas.put(identificador, false));
        entrada.put(KeyStroke.getKeyStroke("shift pressed " + tecla), accionPresionar);
        entrada.put(KeyStroke.getKeyStroke("shift released " + tecla), accionSoltar);
    }

    private void vincularAccion(InputMap entrada, ActionMap acciones, String tecla,
            String identificador, Runnable accion) {
        entrada.put(KeyStroke.getKeyStroke(tecla), identificador);
        acciones.put(identificador, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent evento) {
                if (!enJuego || !estado.isJugadorVivo()
                        || pausado && !"pausa".equals(identificador)) {
                    return;
                }
                boolean habiaGanado = estado.isGano();
                accion.run();
                if (!habiaGanado && estado.isGano()) {
                    registrarVictoria();
                }
                vista.repaint();
            }
        });
    }

    private void alternarPausa() {
        if (pausado) {
            reanudar();
        } else if (estado.isJugadorVivo() && !estado.isGano()) {
            pausado = true;
            limpiarEntrada();
            vista.setPausado(true);
        }
    }

    private void reanudar() {
        pausado = false;
        limpiarEntrada();
        ultimoFrameNs = System.nanoTime();
        vista.setPausado(false);
        vista.requestFocusInWindow();
    }

    private void volverAlMenuDesdePausa() {
        int respuesta = JOptionPane.showConfirmDialog(vista,
                "El progreso no guardado se perderá. ¿Volver al menú principal?",
                "Menú principal", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            mostrarMenuPrincipal();
        }
    }

    private void registrarVictoria() {
        if (resultadoRegistrado) {
            return;
        }
        resultadoRegistrado = true;
        RegistroPuntaje registro = new RegistroPuntaje(
                estado.getNombreJugador(), estado.getTiempoTranscurridoMs(),
                System.currentTimeMillis());
        try {
            repositorioRanking.registrar(registro);
            JOptionPane.showMessageDialog(vista,
                    "¡Escapaste!\nTiempo: " + formatearTiempo(registro.tiempoMs())
                    + "\nTu resultado se guardó en el ranking.",
                    "Partida completada", JOptionPane.INFORMATION_MESSAGE);
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(vista,
                    "Escapaste en " + formatearTiempo(registro.tiempoMs())
                    + ", pero no se pudo guardar el ranking:\n" + ex.getMessage(),
                    "No se pudo guardar el ranking", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String formatearTiempo(long tiempoMs) {
        long segundos = tiempoMs / 1000;
        long horas = segundos / 3600;
        long minutos = (segundos % 3600) / 60;
        long restoSegundos = segundos % 60;
        return horas > 0
                ? String.format("%02d:%02d:%02d", horas, minutos, restoSegundos)
                : String.format("%02d:%02d", minutos, restoSegundos);
    }

    private void actualizarApuntado(MouseEvent evento) {
        Player jugador = estado.getJugador();
        double centroX = jugador.getX() + jugador.getAncho() / 2.0;
        double centroY = jugador.getY() + jugador.getAlto() / 2.0;
        jugador.setAnguloApuntado(Math.atan2(evento.getY() - centroY,
                evento.getX() - centroX));
        vista.repaint();
    }

    private void abrirLibro() {
        if (!estado.abrirLibro()) {
            vista.repaint();
            return;
        }
        String respuesta = JOptionPane.showInputDialog(vista,
                "El acertijo se detendrá mientras lees.\n"
                + estado.getPistaAcertijo() + "\n"
                + "Escribe el código de tres cifras:",
                "Libro de acertijos", JOptionPane.QUESTION_MESSAGE);
        boolean correcto = estado.resolverPuzzle(respuesta);
        if (respuesta != null) {
            JOptionPane.showMessageDialog(vista, estado.getMensaje(),
                    "Resultado del acertijo", correcto
                    ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
        }
        ultimoFrameNs = System.nanoTime();
        vista.repaint();
    }

    private void usarObjetoSeleccionado() {
        if (estado.getJugador().getInventario().getItemSeleccionado() != null
                && "LIBRO_PUZZLE".equals(estado.getJugador().getInventario()
                        .getItemSeleccionado().getId())) {
            abrirLibro();
        } else {
            estado.usarObjetoSeleccionado();
        }
    }
}
