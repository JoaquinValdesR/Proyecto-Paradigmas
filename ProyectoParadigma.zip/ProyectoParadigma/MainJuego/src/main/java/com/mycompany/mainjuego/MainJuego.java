/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainjuego;

import controlador.ControladorJuego;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import modelo.EstadoJuego;
import vista.PanelJuego;

public class MainJuego {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstadoJuego estado = new EstadoJuego();
            PanelJuego panel = new PanelJuego(estado);
            panel.setFocusable(true);
            panel.setBackground(Color.BLACK);
            ControladorJuego controlador = new ControladorJuego(estado, panel);

            JFrame ventana = new JFrame("La casa sin salida");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setResizable(false);
            ventana.setJMenuBar(controlador.crearBarraMenu());
            ventana.setContentPane(panel);
            ventana.pack();
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
            controlador.iniciar();
        });
    }
}
