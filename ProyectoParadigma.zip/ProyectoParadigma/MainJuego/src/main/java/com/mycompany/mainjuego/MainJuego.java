/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainjuego;

import controlador.ControladorJuego;
import java.awt.Color;
import javax.swing.SwingUtilities;
import modelo.EstadoJuego;
import vista.PanelJuego;
import vista.VentanaJuego;

public class MainJuego {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstadoJuego estado = new EstadoJuego();
            PanelJuego panel = new PanelJuego(estado);
            panel.setFocusable(true);
            panel.setBackground(Color.BLACK);
            ControladorJuego controlador = new ControladorJuego(estado, panel);

            VentanaJuego ventana = new VentanaJuego();
            ventana.configurar(controlador);
            controlador.iniciar();
        });
    }
}
