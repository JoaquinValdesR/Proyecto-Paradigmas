package modelo;

public class ObjetoSuelo {
    private final ObjetoInventario item;
    private final double x;
    private final double y;

    public ObjetoSuelo(ObjetoInventario item, double x, double y) {
        if (item == null || !Double.isFinite(x) || !Double.isFinite(y)) {
            throw new IllegalArgumentException("El objeto del suelo no es válido.");
        }
        this.item = item;
        this.x = x;
        this.y = y;
    }

    public ObjetoInventario getItem() { return item; }
    public double getX() { return x; }
    public double getY() { return y; }
}
