package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Mapa {
    public static final int TILE_SIZE = 32;
    public static final int COLUMNAS = 30;
    public static final int FILAS = 20;
    public static final int ANCHO = COLUMNAS * TILE_SIZE;
    public static final int ALTO = FILAS * TILE_SIZE;
    public static final String PASILLO = "PASILLO";

    private final String id;
    private final boolean[][] paredes = new boolean[FILAS][COLUMNAS];
    private final boolean[][] muebles = new boolean[FILAS][COLUMNAS];
    private final String[][] zonas = new String[FILAS][COLUMNAS];
    private final List<ObjetoMapa> objetos = new ArrayList<>();
    private final List<ObjetoMapa> objetosIniciales = new ArrayList<>();
    private final List<ObjetoSuelo> objetosSuelo = new ArrayList<>();
    private final List<Puerta> puertas = new ArrayList<>();

    public Mapa() {
        this(PASILLO);
    }

    public Mapa(String id) {
        if (!PASILLO.equals(id)) {
            throw new IllegalArgumentException("La casa se representa en un único mapa.");
        }
        this.id = id;
        crearPlano();
        crearPuertas();
        crearObjetos();
    }

    public static List<String> getIdsHabitaciones() {
        return List.of(PASILLO);
    }

    private void crearPlano() {
        for (int fila = 0; fila < FILAS; fila++) {
            for (int columna = 0; columna < COLUMNAS; columna++) {
                paredes[fila][columna] = true;
            }
        }

        pintarSuelo(1, 1, 9, 6, "CUARTO CERRADO");
        pintarSuelo(10, 2, 15, 6, "LAB 1");
        pintarSuelo(16, 2, 21, 6, "LAB 2");
        pintarSuelo(23, 3, 27, 6, "CUARTO CERRADO");
        pintarSuelo(7, 7, 28, 9, "PASILLO");
        pintarSuelo(1, 9, 7, 13, "BAÑOS");
        pintarSuelo(7, 9, 10, 17, "PASILLO");
        pintarSuelo(1, 14, 4, 17, "TIENDA");
        pintarSuelo(5, 14, 6, 17, "PASILLO");
        pintarSuelo(11, 10, 18, 18, "LAB 3");
        pintarSuelo(19, 10, 28, 17, "PATIO");

        dibujarParedHorizontal(1, 9, 1);
        dibujarParedHorizontal(1, 9, 6);
        dibujarParedVertical(1, 1, 6);
        dibujarParedVertical(9, 1, 6);

        dibujarParedHorizontal(10, 15, 2);
        dibujarParedHorizontal(10, 15, 6);
        dibujarParedVertical(10, 2, 6);
        dibujarParedVertical(15, 2, 6);

        dibujarParedHorizontal(16, 21, 2);
        dibujarParedHorizontal(16, 21, 6);
        dibujarParedVertical(16, 2, 6);
        dibujarParedVertical(21, 2, 6);

        dibujarParedHorizontal(23, 27, 3);
        dibujarParedHorizontal(23, 27, 6);
        dibujarParedVertical(23, 3, 6);
        dibujarParedVertical(27, 3, 6);

        dibujarParedHorizontal(7, 28, 6);
        dibujarParedHorizontal(1, 7, 9);
        dibujarParedHorizontal(1, 7, 13);
        dibujarParedVertical(1, 9, 13);
        dibujarParedVertical(7, 9, 13);
        dibujarParedHorizontal(1, 4, 14);
        dibujarParedHorizontal(1, 4, 17);
        dibujarParedVertical(1, 14, 17);
        dibujarParedVertical(4, 14, 17);

        dibujarParedHorizontal(11, 18, 10);
        dibujarParedHorizontal(11, 18, 18);
        dibujarParedVertical(11, 10, 18);
        dibujarParedVertical(18, 10, 18);
        dibujarParedHorizontal(19, 28, 10);
        dibujarParedHorizontal(19, 28, 17);
        dibujarParedVertical(19, 10, 17);
        dibujarParedVertical(28, 10, 17);

        abrirPaso(8, 6);
        abrirPaso(13, 6);
        abrirPaso(19, 6);
        abrirPaso(7, 10);
        abrirPaso(4, 15);
        abrirPaso(14, 10);
        abrirPaso(11, 14);
        abrirPaso(19, 14);
        abrirPaso(24, 10);

        for (int columna = 1; columna <= 6; columna++) {
            paredes[11][columna] = true;
        }
        abrirPaso(5, 11);
    }

    private void pintarSuelo(int desdeX, int desdeY, int hastaX, int hastaY, String zona) {
        for (int fila = desdeY; fila <= hastaY; fila++) {
            for (int columna = desdeX; columna <= hastaX; columna++) {
                paredes[fila][columna] = false;
                zonas[fila][columna] = zona;
            }
        }
    }

    private void dibujarParedHorizontal(int desdeX, int hastaX, int fila) {
        for (int columna = desdeX; columna <= hastaX; columna++) {
            paredes[fila][columna] = true;
        }
    }

    private void dibujarParedVertical(int columna, int desdeY, int hastaY) {
        for (int fila = desdeY; fila <= hastaY; fila++) {
            paredes[fila][columna] = true;
        }
    }

    private void abrirPaso(int columna, int fila) {
        paredes[fila][columna] = false;
    }

    private void crearPuertas() {
        registrarPuerta(new Puerta("CUARTO_BLOQUEADO_1", 4, 1, 0, 0, true));
        registrarPuerta(new Puerta("BAÑOS", 8, 6, 8 * TILE_SIZE, 7 * TILE_SIZE, false));
        registrarPuerta(new Puerta("LAB1", 13, 6, 13 * TILE_SIZE, 7 * TILE_SIZE, false));
        registrarPuerta(new Puerta("LAB2", 19, 6, 19 * TILE_SIZE, 7 * TILE_SIZE, false));
        registrarPuerta(new Puerta("BAÑOS", 7, 10, 8 * TILE_SIZE, 10 * TILE_SIZE, false));
        registrarPuerta(new Puerta("TIENDA", 4, 15, 5 * TILE_SIZE, 15 * TILE_SIZE, false));
        registrarPuerta(new Puerta("LAB3", 14, 10, 14 * TILE_SIZE, 9 * TILE_SIZE, false));
        registrarPuerta(new Puerta("LAB3", 11, 14, 10 * TILE_SIZE, 14 * TILE_SIZE, false));
        registrarPuerta(new Puerta("PATIO", 19, 14, 18 * TILE_SIZE, 14 * TILE_SIZE, false));
        registrarPuerta(new Puerta("PATIO", 24, 10, 24 * TILE_SIZE, 9 * TILE_SIZE, false));
        registrarPuerta(new Puerta("CUARTO_BLOQUEADO_2", 29, 8, 0, 0, true));
    }

    private void crearObjetos() {
        agregar(ObjetoMapa.Tipo.BATERIA, 5, 8, "Batería");
        agregar(ObjetoMapa.Tipo.ESCOBA, 2, 15, "Escoba");
        agregar(ObjetoMapa.Tipo.ESCOBA, 25, 13, "Escoba");
        agregar(ObjetoMapa.Tipo.BOTIQUIN, 3, 10, "Botiquín");
        agregar(ObjetoMapa.Tipo.SALIDA, 26, 15, "Salida");
        agregar(ObjetoMapa.Tipo.PIEZA, 3, 12, "Pieza antigua I");
        agregar(ObjetoMapa.Tipo.LIBRO, 13, 4, "Libro de acertijos");
        agregar(ObjetoMapa.Tipo.PIEZA, 19, 4, "Pieza antigua II");
        agregar(ObjetoMapa.Tipo.PIEZA, 15, 15, "Pieza antigua III");
        agregar(ObjetoMapa.Tipo.PIEZA, 24, 13, "Pieza antigua IV");
        agregar(ObjetoMapa.Tipo.CAJA_FUERTE, 17, 12, "Caja fuerte");
        agregar(ObjetoMapa.Tipo.BATERIA, 26, 12, "Batería");
    }

    private void agregar(ObjetoMapa.Tipo tipo, int columna, int fila, String nombre) {
        ObjetoMapa objeto = new ObjetoMapa(tipo, columna, fila, nombre);
        objetos.add(objeto);
        objetosIniciales.add(objeto);
    }

    private void registrarPuerta(Puerta puerta) {
        puertas.add(puerta);
    }

    public boolean esColision(double x, double y, int ancho, int alto) {
        return hayPared(x, y) || hayPared(x + ancho - 1, y)
                || hayPared(x, y + alto - 1) || hayPared(x + ancho - 1, y + alto - 1);
    }

    private boolean hayPared(double x, double y) {
        int columna = (int) Math.floor(x / TILE_SIZE);
        int fila = (int) Math.floor(y / TILE_SIZE);
        return columna < 0 || columna >= COLUMNAS || fila < 0 || fila >= FILAS
                || paredes[fila][columna];
    }

    public boolean esPared(int columna, int fila) {
        return columna < 0 || columna >= COLUMNAS || fila < 0 || fila >= FILAS
                || paredes[fila][columna];
    }

    public boolean esMueble(int columna, int fila) {
        return columna >= 0 && columna < COLUMNAS
                && fila >= 0 && fila < FILAS && muebles[fila][columna];
    }

    public String getNombreZona(int columna, int fila) {
        if (columna < 0 || columna >= COLUMNAS || fila < 0 || fila >= FILAS
                || zonas[fila][columna] == null) {
            return "Pasillo principal";
        }
        return switch (zonas[fila][columna]) {
            case "CUARTO CERRADO" -> "Cuarto cerrado";
            case "LAB 1" -> "Laboratorio 1";
            case "LAB 2" -> "Laboratorio 2";
            case "BAÑOS" -> "Baños";
            case "TIENDA" -> "Tienda";
            case "LAB 3" -> "Laboratorio 3";
            case "PATIO" -> "Patio";
            default -> "Pasillo principal";
        };
    }

    public List<ObjetoMapa> getObjetos() { return Collections.unmodifiableList(objetos); }
    public List<Puerta> getPuertas() { return Collections.unmodifiableList(puertas); }
    public String getId() { return id; }
    public String getNombre() { return "Casa sin salida"; }

    public List<ObjetoSuelo> getObjetosSuelo() {
        return Collections.unmodifiableList(objetosSuelo);
    }

    public void quitarObjeto(ObjetoMapa objeto) {
        objetos.remove(objeto);
    }

    public boolean agregarObjetoSuelo(Item item, double x, double y) {
        int tamano = 16;
        if (esColision(x - tamano / 2.0, y - tamano / 2.0, tamano, tamano)) {
            return false;
        }
        objetosSuelo.add(new ObjetoSuelo(item, x, y));
        return true;
    }

    public void quitarObjetoSuelo(ObjetoSuelo objeto) { objetosSuelo.remove(objeto); }

    public List<DatosObjetoSuelo> getDatosObjetosSuelo() {
        return objetosSuelo.stream()
                .map(objeto -> new DatosObjetoSuelo(
                        objeto.getItem().getId(), objeto.getX(), objeto.getY()))
                .toList();
    }

    public void validarEstado(DatosMapa datos) {
        if (datos == null || !id.equals(datos.id())) {
            throw new IllegalArgumentException("La partida contiene un mapa desconocido.");
        }
        Set<String> idsIniciales = getIdsObjetosIniciales();
        if (!idsIniciales.containsAll(datos.objetosPresentes())
                || new java.util.HashSet<>(datos.objetosPresentes()).size()
                        != datos.objetosPresentes().size()) {
            throw new IllegalArgumentException("La partida contiene objetos de mapa inválidos.");
        }
        validarObjetosSuelo(datos.objetosSuelo());
    }

    public void restaurarEstado(DatosMapa datos) {
        validarEstado(datos);
        objetos.clear();
        for (ObjetoMapa objeto : objetosIniciales) {
            if (datos.objetosPresentes().contains(objeto.getId())) {
                objetos.add(objeto);
            }
        }
        objetosSuelo.clear();
        for (DatosObjetoSuelo dato : datos.objetosSuelo()) {
            objetosSuelo.add(new ObjetoSuelo(crearItemSuelo(dato.id()), dato.x(), dato.y()));
        }
    }

    private void validarObjetosSuelo(List<DatosObjetoSuelo> datos) {
        if (datos == null || datos.size() > 1000) {
            throw new IllegalArgumentException("La lista de objetos del suelo no es válida.");
        }
        Set<String> piezas = new java.util.HashSet<>();
        for (DatosObjetoSuelo dato : datos) {
            if (dato == null || dato.id() == null
                    || !Double.isFinite(dato.x()) || !Double.isFinite(dato.y())
                    || dato.x() < 0 || dato.y() < 0 || dato.x() >= ANCHO || dato.y() >= ALTO
                    || esColision(dato.x() - 8, dato.y() - 8, 16, 16)) {
                throw new IllegalArgumentException("La partida contiene un objeto del suelo inválido.");
            }
            crearItemSuelo(dato.id());
            if (dato.id().startsWith("PIEZA_") && !piezas.add(dato.id())) {
                throw new IllegalArgumentException("La partida contiene piezas duplicadas.");
            }
        }
    }

    private Item crearItemSuelo(String itemId) {
        return switch (itemId) {
            case "BATERIA" -> new Bateria();
            case "ESCOBA" -> new Escoba();
            case "LIBRO_PUZZLE" -> new LibroPuzzle();
            case "PIEZA_1" -> new PiezaPuzzle(1);
            case "PIEZA_2" -> new PiezaPuzzle(2);
            case "PIEZA_3" -> new PiezaPuzzle(3);
            case "PIEZA_4" -> new PiezaPuzzle(4);
            case "LLAVE_ESCAPE" -> new LlaveEscape();
            default -> throw new IllegalArgumentException("La partida contiene un objeto desconocido.");
        };
    }

    public List<String> getIdsObjetosPresentes() {
        return objetos.stream().map(ObjetoMapa::getId).toList();
    }

    public Set<String> getIdsObjetosIniciales(ObjetoMapa.Tipo tipo) {
        return objetosIniciales.stream()
                .filter(objeto -> objeto.getTipo() == tipo)
                .map(ObjetoMapa::getId)
                .collect(Collectors.toUnmodifiableSet());
    }

    private Set<String> getIdsObjetosIniciales() {
        return objetosIniciales.stream().map(ObjetoMapa::getId)
                .collect(Collectors.toUnmodifiableSet());
    }
}
