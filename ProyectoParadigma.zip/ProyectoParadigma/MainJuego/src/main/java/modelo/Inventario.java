/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Inventario implements Serializable{
    private static final long serialVersionUID = 1L;

    public static final int CAPACIDAD_MAXIMA = 9; // Limitado a 9 slots según requerimientos
    private ObjetoInventario[] slots;
    private int slotSeleccionado;

    public Inventario() {
        this.slots = new ObjetoInventario[CAPACIDAD_MAXIMA];
        this.slotSeleccionado = 0; // Inicia seleccionando el primer slot (índice 0)
    }

    /**
     * Agrega un ítem en el primer slot disponible.
     * @return true si se agregó con éxito, false si el inventario está lleno.
     */
    public boolean agregarItem(ObjetoInventario item) {
        if (item == null) return false;

        for (int i = 0; i < CAPACIDAD_MAXIMA; i++) {
            if (slots[i] == null) {
                slots[i] = item;
                return true;
            }
        }
        return false; // Inventario lleno
    }

    /**
     * Elimina el ítem de una casilla específica.
     */
    public boolean eliminarItem(int slotIndex) {
        if (esSlotValido(slotIndex) && slots[slotIndex] != null) {
            slots[slotIndex] = null;
            return true;
        }
        return false;
    }

    /**
     * Usa el ítem equipado actualmente. Si es consumible y se aplica con éxito, se remueve del slot.
     */
    public boolean usarItemSeleccionado(Jugador jugador) {
        ObjetoInventario itemActivo = getItemSeleccionado();
        if (itemActivo != null) {
            boolean exito = itemActivo.usar(jugador);
            if (exito && itemActivo.isEsConsumible()) {
                eliminarItem(slotSeleccionado);
            }
            return exito;
        }
        return false;
    }

    public int getCapacidadMaxima() {
        return CAPACIDAD_MAXIMA;
    }

    public void restaurarItems(ObjetoInventario[] items, int slotSeleccionado) {
        if (items == null || items.length != CAPACIDAD_MAXIMA
                || !esSlotValido(slotSeleccionado)) {
            throw new IllegalArgumentException("Los datos del inventario no son válidos.");
        }
        this.slots = items.clone();
        this.slotSeleccionado = slotSeleccionado;
    }

    /**
     * Cambia la casilla activa mediante las teclas numéricas (1 a 9) o la rueda del mouse.
     */
    public void setSlotSeleccionado(int nuevoIndex) {
        if (esSlotValido(nuevoIndex)) {
            this.slotSeleccionado = nuevoIndex;
        }
    }

    /**
     * Verifica si el jugador posee un ítem específico por su ID (ej: "LLAVE_ESCAPE", "LIBRO_PUZZLE").
     */
    public boolean tieneItem(String idItem) {
        for (ObjetoInventario item : slots) {
            if (item != null && item.getId().equalsIgnoreCase(idItem)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Evalúa si los 9 slots están ocupados.
     */
    public boolean estaLleno() {
        for (ObjetoInventario item : slots) {
            if (item == null) return false;
        }
        return true;
    }

    private boolean esSlotValido(int index) {
        return index >= 0 && index < CAPACIDAD_MAXIMA;
    }

    // --- GETTERS ---

    public ObjetoInventario[] getSlots() { return slots; }

    public ObjetoInventario getItemEnSlot(int index) {
        if (esSlotValido(index)) {
            return slots[index];
        }
        return null;
    }

    public ObjetoInventario getItemSeleccionado() {
        return slots[slotSeleccionado];
    }

    public int getSlotSeleccionado() {
        return slotSeleccionado;
    }
}
