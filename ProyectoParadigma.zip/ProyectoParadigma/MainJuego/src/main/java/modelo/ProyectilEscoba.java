package modelo;

public class ProyectilEscoba {
    private static final double VELOCIDAD = 430.0;
    private static final double ALCANCE_MAXIMO = 260.0;
    private static final double TAMANO = 12.0;

    private double x;
    private double y;
    private final double direccionX;
    private final double direccionY;
    private double distanciaRecorrida;
    private boolean activo = true;

    public ProyectilEscoba(double x, double y, double angulo) {
        this.x = x;
        this.y = y;
        this.direccionX = Math.cos(angulo);
        this.direccionY = Math.sin(angulo);
    }

    public void actualizar(double deltaTiempo, Mapa mapa) {
        if (!activo) {
            return;
        }
        double distancia = Math.min(VELOCIDAD * deltaTiempo,
                ALCANCE_MAXIMO - distanciaRecorrida);
        int pasos = Math.max(1, (int) Math.ceil(distancia / 4.0));
        double pasoX = direccionX * distancia / pasos;
        double pasoY = direccionY * distancia / pasos;
        for (int i = 0; i < pasos; i++) {
            if (mapa.esColision(x + pasoX - TAMANO / 2,
                    y + pasoY - TAMANO / 2, (int) TAMANO, (int) TAMANO)) {
                activo = false;
                return;
            }
            x += pasoX;
            y += pasoY;
            distanciaRecorrida += Math.hypot(pasoX, pasoY);
        }
        if (distanciaRecorrida >= ALCANCE_MAXIMO) {
            activo = false;
        }
    }

    public boolean impacta(Entity entidad) {
        double cercanoX = Math.max(entidad.getX(), Math.min(x, entidad.getX() + entidad.getAncho()));
        double cercanoY = Math.max(entidad.getY(), Math.min(y, entidad.getY() + entidad.getAlto()));
        return Math.hypot(x - cercanoX, y - cercanoY) <= TAMANO / 2;
    }

    public void consumir() {
        activo = false;
    }

    public boolean isActivo() { return activo; }
    public double getX() { return x; }
    public double getY() { return y; }
}
