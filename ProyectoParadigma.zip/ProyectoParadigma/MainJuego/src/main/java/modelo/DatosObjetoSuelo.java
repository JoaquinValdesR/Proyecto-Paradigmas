package modelo;

public record DatosObjetoSuelo(String id, double x, double y) {
}
