package modelo;

public class Botiquin extends Item {
    private static final long serialVersionUID = 1L;

    public Botiquin() {
        super("BOTIQUIN", "Botiquín", "Restaura toda la salud.", true);
    }

    @Override
    public boolean usar(Player jugador) {
        int saludAnterior = jugador.getSaludActual();
        jugador.curar(jugador.getSaludMax());
        return jugador.getSaludActual() > saludAnterior;
    }
}
