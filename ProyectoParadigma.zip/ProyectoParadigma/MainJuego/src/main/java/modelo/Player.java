package modelo;

import java.io.Serializable;

public class Player implements Serializable {
    private static final long serialVersionUID = 1L;

    private double x;
    private double y;
    private final int ancho = 24;
    private final int alto = 24;
    private final double velocidadBase = 155.0;
    private final double velocidadSprint = 250.0;

    private final int saludMax = 100;
    private int saludActual = saludMax;
    private boolean estaVivo = true;
    private double puntoReaparicionX;
    private double puntoReaparicionY;

    private final float staminaMax = 100.0f;
    private float staminaActual = staminaMax;
    private final float tasaConsumoStamina = 20.0f;
    private final float tasaRecuperacionStamina = 10.0f;
    private boolean estaCorriendo;
    private boolean staminaAgotada;

    private double anguloApuntado;
    private final double rangoInteraccion = 52.0;

    private final Inventory inventario = new Inventory();
    private final Linterna linterna = new Linterna();
    private final Taser taser = new Taser();

    public Player(double xInicial, double yInicial) {
        this.x = xInicial;
        this.y = yInicial;
        this.puntoReaparicionX = xInicial;
        this.puntoReaparicionY = yInicial;
    }

    public void mover(double dirX, double dirY, Mapa mapa, double deltaTiempo) {
        if (!estaVivo || mapa == null) {
            return;
        }

        double magnitud = Math.hypot(dirX, dirY);
        if (magnitud == 0) {
            return;
        }
        double velocidad = estaCorriendo && !staminaAgotada
                ? velocidadSprint : velocidadBase;
        double desplazamientoX = dirX / magnitud * velocidad * deltaTiempo;
        double desplazamientoY = dirY / magnitud * velocidad * deltaTiempo;

        double nuevaX = x + desplazamientoX;
        if (!mapa.esColision(nuevaX, y, ancho, alto)) {
            x = nuevaX;
        }
        double nuevaY = y + desplazamientoY;
        if (!mapa.esColision(x, nuevaY, ancho, alto)) {
            y = nuevaY;
        }
    }

    public void actualizarStamina(boolean intentandoCorrer, boolean seEstaMoviendo,
            double deltaTiempo) {
        if (intentandoCorrer && seEstaMoviendo && !staminaAgotada) {
            estaCorriendo = true;
            staminaActual -= tasaConsumoStamina * (float) deltaTiempo;
            if (staminaActual <= 0) {
                staminaActual = 0;
                estaCorriendo = false;
                staminaAgotada = true;
            }
            return;
        }

        estaCorriendo = false;
        if (staminaActual < staminaMax) {
            staminaActual = Math.min(staminaMax,
                    staminaActual + tasaRecuperacionStamina * (float) deltaTiempo);
            if (staminaActual >= staminaMax) {
                staminaAgotada = false;
            }
        }
    }

    public void recibirDano(int cantidad) {
        if (!estaVivo || cantidad <= 0) {
            return;
        }
        saludActual -= cantidad;
        if (saludActual <= 0) {
            reaparecer();
        }
    }

    public void reaparecer() {
        x = puntoReaparicionX;
        y = puntoReaparicionY;
        saludActual = saludMax;
        staminaActual = staminaMax;
        staminaAgotada = false;
        estaCorriendo = false;
        linterna.restaurarEstado(linterna.getBateriaMax(), true);
        estaVivo = true;
    }

    public void actualizarPuntoReaparicion(double nuevaX, double nuevaY) {
        puntoReaparicionX = nuevaX;
        puntoReaparicionY = nuevaY;
    }

    public void restaurarEstado(double nuevaX, double nuevaY, double reaparicionX,
            double reaparicionY, int salud, float stamina) {
        x = nuevaX;
        y = nuevaY;
        puntoReaparicionX = reaparicionX;
        puntoReaparicionY = reaparicionY;
        saludActual = salud;
        staminaActual = stamina;
        estaVivo = true;
        estaCorriendo = false;
        staminaAgotada = stamina <= 0;
    }

    public void curar(int cantidad) {
        if (cantidad > 0) {
            saludActual = Math.min(saludActual + cantidad, saludMax);
        }
    }

    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public double getX() { return x; }
    public double getY() { return y; }
    public int getAncho() { return ancho; }
    public int getAlto() { return alto; }
    public int getSaludActual() { return saludActual; }
    public int getSaludMax() { return saludMax; }
    public float getStaminaActual() { return staminaActual; }
    public float getStaminaMax() { return staminaMax; }
    public boolean isEstaVivo() { return estaVivo; }
    public boolean isEstaCorriendo() { return estaCorriendo; }
    public double getAnguloApuntado() { return anguloApuntado; }
    public void setAnguloApuntado(double angulo) { anguloApuntado = angulo; }
    public Inventory getInventario() { return inventario; }
    public Linterna getLinterna() { return linterna; }
    public Taser getTaser() { return taser; }
    public double getRangoInteraccion() { return rangoInteraccion; }
    public double getVelocidadBase() { return velocidadBase; }
    public double getPuntoReaparicionX() { return puntoReaparicionX; }
    public double getPuntoReaparicionY() { return puntoReaparicionY; }
}
