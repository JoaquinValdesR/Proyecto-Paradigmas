package modelo;

import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.Queue;

public class Entity implements Serializable {
    private static final long serialVersionUID = 1L;
    private record Casilla(int columna, int fila) {}

    private double x;
    private double y;
    private final int ancho = 27;
    private final int alto = 27;
    private double velocidadNormal = 112.0;
    private double velocidadFuria = 112.0;
    private boolean esModoFuria;
    private boolean estaParalizado;
    private long tiempoFinParalisis;
    private long proximaBusquedaRuta;
    private transient Casilla siguienteRuta;

    public Entity(double xInicial, double yInicial) {
        x = xInicial;
        y = yInicial;
    }

    public void actualizar(Player jugador, Mapa mapa, double deltaTiempo) {
        if (jugador == null || mapa == null || !jugador.isEstaVivo()) {
            return;
        }
        if (estaParalizado) {
            if (System.currentTimeMillis() < tiempoFinParalisis) {
                return;
            }
            estaParalizado = false;
        }

        Casilla siguiente = buscarSiguienteCasilla(jugador, mapa);
        if (siguiente != null) {
            moverHacia(siguiente.columna() * Mapa.TILE_SIZE + (Mapa.TILE_SIZE - ancho) / 2.0,
                    siguiente.fila() * Mapa.TILE_SIZE + (Mapa.TILE_SIZE - alto) / 2.0,
                    mapa, deltaTiempo);
        } else {
            perseguirDirectamente(jugador, mapa, deltaTiempo);
        }
    }

    private Casilla buscarSiguienteCasilla(Player jugador, Mapa mapa) {
        long ahora = System.currentTimeMillis();
        if (ahora < proximaBusquedaRuta) {
            return siguienteRuta;
        }
        proximaBusquedaRuta = ahora + 120;

        int inicioX = (int) ((x + ancho / 2.0) / Mapa.TILE_SIZE);
        int inicioY = (int) ((y + alto / 2.0) / Mapa.TILE_SIZE);
        int destinoX = (int) ((jugador.getX() + jugador.getAncho() / 2.0) / Mapa.TILE_SIZE);
        int destinoY = (int) ((jugador.getY() + jugador.getAlto() / 2.0) / Mapa.TILE_SIZE);
        if (inicioX == destinoX && inicioY == destinoY) {
            siguienteRuta = null;
            return null;
        }

        Casilla[][] anterior = new Casilla[Mapa.FILAS][Mapa.COLUMNAS];
        boolean[][] visitada = new boolean[Mapa.FILAS][Mapa.COLUMNAS];
        Queue<Casilla> pendientes = new ArrayDeque<>();
        Casilla inicio = new Casilla(inicioX, inicioY);
        pendientes.add(inicio);
        visitada[inicioY][inicioX] = true;
        int[][] direcciones = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

        while (!pendientes.isEmpty()) {
            Casilla actual = pendientes.remove();
            if (actual.columna() == destinoX && actual.fila() == destinoY) {
                Casilla paso = actual;
                while (anterior[paso.fila()][paso.columna()] != null
                        && !anterior[paso.fila()][paso.columna()].equals(inicio)) {
                    paso = anterior[paso.fila()][paso.columna()];
                }
                siguienteRuta = paso.equals(inicio) ? actual : paso;
                return siguienteRuta;
            }
            for (int[] direccion : direcciones) {
                int nx = actual.columna() + direccion[0];
                int ny = actual.fila() + direccion[1];
                if (!visitada[ny][nx] && !mapa.esPared(nx, ny)) {
                    visitada[ny][nx] = true;
                    anterior[ny][nx] = actual;
                    pendientes.add(new Casilla(nx, ny));
                }
            }
        }
        siguienteRuta = null;
        return null;
    }

    private void moverHacia(double destinoX, double destinoY, Mapa mapa, double deltaTiempo) {
        double diferenciaX = destinoX - x;
        double diferenciaY = destinoY - y;
        double distancia = Math.hypot(diferenciaX, diferenciaY);
        if (distancia < 1.0) {
            return;
        }
        double paso = Math.min(distancia, (esModoFuria ? velocidadFuria : velocidadNormal)
                * deltaTiempo);
        moverEjes(diferenciaX / distancia * paso, diferenciaY / distancia * paso, mapa);
    }

    private void perseguirDirectamente(Player jugador, Mapa mapa, double deltaTiempo) {
        double diferenciaX = jugador.getX() - x;
        double diferenciaY = jugador.getY() - y;
        double distancia = Math.hypot(diferenciaX, diferenciaY);
        if (distancia > 0) {
            double paso = (esModoFuria ? velocidadFuria : velocidadNormal) * deltaTiempo;
            moverEjes(diferenciaX / distancia * paso, diferenciaY / distancia * paso, mapa);
        }
    }

    private void moverEjes(double desplazamientoX, double desplazamientoY, Mapa mapa) {
        double nuevaX = x + desplazamientoX;
        if (!mapa.esColision(nuevaX, y, ancho, alto)) {
            x = nuevaX;
        }
        double nuevaY = y + desplazamientoY;
        if (!mapa.esColision(x, nuevaY, ancho, alto)) {
            y = nuevaY;
        }
    }

    public void paralizar(long duracionMs) {
        estaParalizado = true;
        tiempoFinParalisis = System.currentTimeMillis() + Math.max(0, duracionMs);
    }

    public long getParalisisRestanteMs() {
        return estaParalizado
                ? Math.max(0, tiempoFinParalisis - System.currentTimeMillis()) : 0;
    }

    public void restaurarEstado(double x, double y, boolean furia,
            boolean puzzleResuelto, double velocidadJugador, long paralisisRestanteMs) {
        this.x = x;
        this.y = y;
        this.velocidadNormal = 112.0;
        this.velocidadFuria = 112.0;
        this.esModoFuria = furia;
        if (puzzleResuelto) {
            setVelocidad(velocidadJugador);
        }
        this.estaParalizado = false;
        this.tiempoFinParalisis = 0;
        this.siguienteRuta = null;
        this.proximaBusquedaRuta = 0;
        if (paralisisRestanteMs > 0) {
            paralizar(paralisisRestanteMs);
        }
    }

    public void activarModoFuria() { esModoFuria = true; }
    public void setVelocidad(double velocidad) {
        velocidadNormal = velocidad;
        velocidadFuria = velocidad;
    }
    public boolean jugadorEnContacto(Player jugador) {
        return x < jugador.getX() + jugador.getAncho()
                && x + ancho > jugador.getX()
                && y < jugador.getY() + jugador.getAlto()
                && y + alto > jugador.getY();
    }

    public void comprobarColisionJugador(Player jugador) {
        if (jugadorEnContacto(jugador)) {
            jugador.recibirDano(esModoFuria ? jugador.getSaludMax() : 25);
        }
    }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
    public int getAncho() { return ancho; }
    public int getAlto() { return alto; }
    public boolean isEstaParalizado() { return estaParalizado; }
    public boolean isEsModoFuria() { return esModoFuria; }
}
