package modelo;

public class LlaveEscape extends ObjetoInventario {
    private static final long serialVersionUID = 1L;

    public LlaveEscape() {
        super("LLAVE_ESCAPE", "Llave de escape", "Abre la salida.", false);
    }

    @Override
    public boolean usar(Jugador jugador) {
        return false;
    }
}
