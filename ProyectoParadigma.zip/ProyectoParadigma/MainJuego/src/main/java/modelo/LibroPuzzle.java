package modelo;

public class LibroPuzzle extends ObjetoInventario {
    private static final long serialVersionUID = 1L;

    public LibroPuzzle() {
        super("LIBRO_PUZZLE", "Libro de acertijos",
                "Contiene pistas para resolver la caja fuerte.", false);
    }

    @Override
    public boolean usar(Jugador jugador) {
        return true;
    }
}
