package modelo;

public class ObjetoMapa {
    public enum Tipo {
        BATERIA, ESCOBA, PIEZA, LIBRO, CAJA_FUERTE, SALIDA, BOTIQUIN
    }

    private final Tipo tipo;
    private final int columna;
    private final int fila;
    private final String nombre;

    public ObjetoMapa(Tipo tipo, int columna, int fila, String nombre) {
        this.tipo = tipo;
        this.columna = columna;
        this.fila = fila;
        this.nombre = nombre;
    }

    public Tipo getTipo() { return tipo; }
    public String getNombre() { return nombre; }
    public int getColumna() { return columna; }
    public int getFila() { return fila; }
    public String getId() { return columna + "_" + fila; }
    public double getCentroX() { return columna * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0; }
    public double getCentroY() { return fila * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0; }
}
