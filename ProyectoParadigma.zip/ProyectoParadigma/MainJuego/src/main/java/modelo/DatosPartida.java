package modelo;

import java.util.List;
import java.util.Objects;

public record DatosPartida(
        double jugadorX,
        double jugadorY,
        double puntoReaparicionX,
        double puntoReaparicionY,
        int salud,
        float stamina,
        float bateria,
        boolean linternaEncendida,
        double entidadX,
        double entidadY,
        long paralisisRestanteMs,
        long taserCooldownRestanteMs,
        int piezas,
        boolean puzzleResuelto,
        boolean gano,
        int slotSeleccionado,
        List<String> inventario,
        String mapaActualId,
        List<DatosMapa> mapas) {

    public DatosPartida {
        inventario = List.copyOf(Objects.requireNonNull(inventario, "inventario"));
        Objects.requireNonNull(mapaActualId, "mapaActualId");
        mapas = List.copyOf(Objects.requireNonNull(mapas, "mapas"));
    }
}
