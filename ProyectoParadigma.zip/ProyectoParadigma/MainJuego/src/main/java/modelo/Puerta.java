/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Puerta implements Serializable{
    private static final long serialVersionUID = 1L;

    private final String mapaDestino;
    private final int tileX;
    private final int tileY;
    private final double destinoX;
    private final double destinoY;
    private final boolean bloqueada;

    public Puerta(String mapaDestino, int tileX, int tileY,
            double destinoX, double destinoY, boolean bloqueada) {
        this.mapaDestino = mapaDestino;
        this.tileX = tileX;
        this.tileY = tileY;
        this.destinoX = destinoX;
        this.destinoY = destinoY;
        this.bloqueada = bloqueada;
    }

    public Puerta(int tileX, int tileY, String mapaDestino, double destinoX, double destinoY) {
        this(mapaDestino, tileX, tileY, destinoX, destinoY, false);
    }

    /**
     * Evalúa si el jugador tocó la casilla de la puerta
     */
    public boolean jugadorEstaEncima(Player jugador) {
        double centroX = tileX * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0;
        double centroY = tileY * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0;
        double jugadorX = jugador.getX() + jugador.getAncho() / 2.0;
        double jugadorY = jugador.getY() + jugador.getAlto() / 2.0;
        return Math.hypot(jugadorX - centroX, jugadorY - centroY)
                <= jugador.getRangoInteraccion();
    }

    public boolean isBloqueada() { return bloqueada; }
    public String getMapaDestino() { return mapaDestino; }
    public double getDestinoX() { return destinoX; }
    public double getDestinoY() { return destinoY; }
    public int getTileX() { return tileX; }
    public int getTileY() { return tileY; }
}
