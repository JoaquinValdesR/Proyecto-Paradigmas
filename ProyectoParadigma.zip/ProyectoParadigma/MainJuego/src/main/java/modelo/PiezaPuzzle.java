/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class PiezaPuzzle extends Item {
    private static final long serialVersionUID = 1L;

    public PiezaPuzzle(int numero) {
        super("PIEZA_" + numero, "Pieza antigua " + numero,
                "Una pieza necesaria para completar el acertijo final.", false);
    }

    @Override
    public boolean usar(Player jugador) {
        return false;
    }
}
