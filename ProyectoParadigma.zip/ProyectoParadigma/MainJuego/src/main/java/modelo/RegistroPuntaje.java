package modelo;

import java.util.Objects;

public record RegistroPuntaje(String nombreJugador, long tiempoMs) {
    public RegistroPuntaje {
        nombreJugador = Objects.requireNonNull(nombreJugador, "nombreJugador").trim();
        if (nombreJugador.isEmpty() || nombreJugador.length() > 40 || tiempoMs < 0) {
            throw new IllegalArgumentException("El registro del ranking no es válido.");
        }
    }
}
