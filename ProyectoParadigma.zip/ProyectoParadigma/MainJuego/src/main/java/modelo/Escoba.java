package modelo;

public class Escoba extends Item {
    private static final long serialVersionUID = 1L;

    public Escoba() {
        super("ESCOBA", "Escoba", "Lánzala para aturdir a la entidad si impacta.", true);
    }

    @Override
    public boolean usar(Player jugador) {
        return true;
    }
}
