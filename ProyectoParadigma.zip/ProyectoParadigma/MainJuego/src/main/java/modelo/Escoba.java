package modelo;

public class Escoba extends ObjetoInventario {
    private static final long serialVersionUID = 1L;

    public Escoba() {
        super("ESCOBA", "Escoba", "Golpe cuerpo a cuerpo de un solo uso.", true);
    }

    @Override
    public boolean usar(Jugador jugador) {
        return true;
    }
}
