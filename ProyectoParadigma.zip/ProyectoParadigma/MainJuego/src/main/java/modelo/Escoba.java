package modelo;

public class Escoba extends Item {
    private static final long serialVersionUID = 1L;

    public Escoba() {
        super("ESCOBA", "Escoba", "Golpe cuerpo a cuerpo de un solo uso.", true);
    }

    @Override
    public boolean usar(Player jugador) {
        return true;
    }
}
