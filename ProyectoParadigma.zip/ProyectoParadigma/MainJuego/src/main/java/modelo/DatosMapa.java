package modelo;

import java.util.List;
import java.util.Objects;

public record DatosMapa(
        String id,
        List<String> objetosPresentes,
        List<DatosObjetoSuelo> objetosSuelo) {

    public DatosMapa {
        Objects.requireNonNull(id, "id");
        objetosPresentes = List.copyOf(
                Objects.requireNonNull(objetosPresentes, "objetosPresentes"));
        objetosSuelo = List.copyOf(Objects.requireNonNull(objetosSuelo, "objetosSuelo"));
    }
}
