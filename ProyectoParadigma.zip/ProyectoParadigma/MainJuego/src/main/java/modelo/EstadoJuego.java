package modelo;

import java.util.HashSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class EstadoJuego {
    private static final int CANTIDAD_PIEZAS = 4;
    private record Acertijo(String pista, String respuesta) {}
    private static final List<Acertijo> ACERTIJOS = List.of(
            new Acertijo("En orden: lados de un triángulo, lunas naturales "
                    + "de la Tierra y patas de una mesa.", "314"),
            new Acertijo("En orden: letras de «SOL», lados de un cuadrado "
                    + "y ruedas de una bicicleta.", "342"),
            new Acertijo("En orden: patas de una araña, lados de un triángulo "
                    + "y ruedas de un triciclo.", "833"),
            new Acertijo("En orden: días del fin de semana, vocales de "
                    + "«murciélago» y lados de un pentágono.", "255"),
            new Acertijo("En orden: dedos de una mano, ojos de una persona "
                    + "y lados de un hexágono.", "526"));

    private final Map<String, Mapa> mapas = new LinkedHashMap<>();
    private Mapa mapaActual;
    private final Jugador jugador;
    private final Entidad entidad;
    private String mensaje = "Encuentra el libro y las cuatro piezas. No hay minimapa.";
    private long mensajeHastaMs;
    private long invulnerableHastaMs;
    private int numeroPiezas;
    private boolean puzzleResuelto;
    private boolean libroAbierto;
    private boolean gano;
    private int acertijoId;
    private String nombreJugador = "Jugador";
    private long tiempoTranscurridoMs;
    private static final double ALCANCE_ESCOBA = 48.0;

    public EstadoJuego() {
        this(ThreadLocalRandom.current().nextInt(ACERTIJOS.size()));
    }

    public EstadoJuego(int acertijoId) {
        if (acertijoId < 0 || acertijoId >= ACERTIJOS.size()) {
            throw new IllegalArgumentException("El acertijo seleccionado no es válido.");
        }
        this.acertijoId = acertijoId;
        for (String id : Mapa.getIdsHabitaciones()) {
            mapas.put(id, new Mapa(id));
        }
        mapaActual = mapas.get(Mapa.PASILLO);
        jugador = new Jugador(10 * Mapa.TILE_SIZE + 4, 8 * Mapa.TILE_SIZE + 4);
        entidad = new Entidad(27 * Mapa.TILE_SIZE + 2, 8 * Mapa.TILE_SIZE + 2);
        mensajeHastaMs = System.currentTimeMillis() + 7000;
    }

    public void actualizar(double deltaTiempo, double direccionX, double direccionY,
            boolean intentandoCorrer) {
        if (libroAbierto || gano || !jugador.isEstaVivo()) {
            return;
        }

        boolean seEstaMoviendo = direccionX != 0 || direccionY != 0;
        jugador.actualizarStamina(intentandoCorrer, seEstaMoviendo, deltaTiempo);
        jugador.mover(direccionX, direccionY, mapaActual, deltaTiempo);
        jugador.getLinterna().actualizar(deltaTiempo);
        if (numeroPiezas >= CANTIDAD_PIEZAS / 2) {
            entidad.activarModoFuria();
        }
        if (puzzleResuelto) {
            entidad.setVelocidad(jugador.getVelocidadBase());
        }
        entidad.actualizar(jugador, mapaActual, deltaTiempo);

        long ahora = System.currentTimeMillis();
        if (entidad.jugadorEnContacto(jugador) && ahora >= invulnerableHastaMs) {
            int saludAntes = jugador.getSaludActual();
            entidad.comprobarColisionJugador(jugador);
            invulnerableHastaMs = ahora + 1100;
            mostrarMensaje(!jugador.isEstaVivo() ? "¡Has muerto!"
                    : jugador.getSaludActual() < saludAntes
                    ? "La entidad te alcanzó. Has perdido salud."
                    : "La entidad te alcanzó.");
        }
    }

    public void reiniciarPartida() {
        reiniciarPartida("Jugador");
    }

    public void reiniciarPartida(String nombreJugador) {
        if (nombreJugador == null || nombreJugador.isBlank()
                || nombreJugador.trim().length() > 40) {
            throw new IllegalArgumentException("El nombre debe tener entre 1 y 40 caracteres.");
        }
        nombreJugador = nombreJugador.trim();
        restaurarPartida(new EstadoJuego().crearDatosPartida());
        this.nombreJugador = nombreJugador;
        mostrarMensaje("Encuentra el libro y las cuatro piezas. No hay minimapa.");
    }

    public void sumarTiempoPartida(long milisegundos) {
        if (milisegundos > 0 && jugador.isEstaVivo() && !gano) {
            tiempoTranscurridoMs = Math.addExact(tiempoTranscurridoMs, milisegundos);
        }
    }

    public void interactuar() {
        Puerta puerta = buscarPuertaCercana();
        if (puerta != null && puerta.isBloqueada()) {
            mostrarMensaje("La puerta está cerrada con llave.");
            return;
        }

        ObjetoMapa cercano = null;
        ObjetoSuelo recogidoDelSuelo = null;
        double menorDistancia = jugador.getRangoInteraccion();
        for (ObjetoMapa objeto : mapaActual.getObjetos()) {
            double distancia = Math.hypot(objeto.getCentroX()
                    - (jugador.getX() + jugador.getAncho() / 2.0),
                    objeto.getCentroY() - (jugador.getY() + jugador.getAlto() / 2.0));
            if (distancia <= menorDistancia) {
                cercano = objeto;
                menorDistancia = distancia;
            }
        }

        for (ObjetoSuelo objeto : mapaActual.getObjetosSuelo()) {
            double distancia = Math.hypot(objeto.getX()
                    - (jugador.getX() + jugador.getAncho() / 2.0),
                    objeto.getY() - (jugador.getY() + jugador.getAlto() / 2.0));
            if (distancia <= menorDistancia) {
                recogidoDelSuelo = objeto;
                cercano = null;
                menorDistancia = distancia;
            }
        }

        if (recogidoDelSuelo != null) {
            if (jugador.getInventario().agregarItem(recogidoDelSuelo.getItem())) {
                mapaActual.quitarObjetoSuelo(recogidoDelSuelo);
                mostrarMensaje("Recogiste: " + recogidoDelSuelo.getItem().getNombre() + ".");
            } else {
                mostrarMensaje("Inventario lleno. Libera un espacio antes de recogerlo.");
            }
            return;
        }

        if (cercano == null) {
            mostrarMensaje("No hay nada que puedas recoger o usar cerca.");
            return;
        }

        switch (cercano.getTipo()) {
            case BATERIA -> recoger(cercano, new Bateria());
            case ESCOBA -> recoger(cercano, new Escoba());
            case BOTIQUIN -> recoger(cercano, new Botiquin());
            case LIBRO -> recoger(cercano, new LibroPuzzle());
            case PIEZA -> {
                int numero = numeroPiezas + 1;
                if (recoger(cercano, new PiezaPuzzle(numero))) {
                    numeroPiezas++;
                    jugador.actualizarPuntoReaparicion(jugador.getX(), jugador.getY());
                    if (numeroPiezas == CANTIDAD_PIEZAS / 2) {
                        entidad.activarModoFuria();
                        mostrarMensaje("La entidad se enfurece: ahora puede matarte de un golpe.");
                    }
                }
            }
            case CAJA_FUERTE -> abrirCajaFuerte(cercano);
            case SALIDA -> escapar();
        }
    }

    private Puerta buscarPuertaCercana() {
        return mapaActual.getPuertas().stream()
                .filter(puerta -> puerta.jugadorEstaEncima(jugador))
                .min((primera, segunda) -> Double.compare(
                        distanciaPuerta(primera), distanciaPuerta(segunda)))
                .orElse(null);
    }

    private double distanciaPuerta(Puerta puerta) {
        double x = puerta.getTileX() * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0;
        double y = puerta.getTileY() * Mapa.TILE_SIZE + Mapa.TILE_SIZE / 2.0;
        return Math.hypot(jugador.getX() + jugador.getAncho() / 2.0 - x,
                jugador.getY() + jugador.getAlto() / 2.0 - y);
    }

    private boolean recoger(ObjetoMapa objeto, ObjetoInventario item) {
        if (!jugador.getInventario().agregarItem(item)) {
            mostrarMensaje("Inventario lleno. Usa un objeto para liberar un espacio.");
            return false;
        }
        mapaActual.quitarObjeto(objeto);
        mostrarMensaje("Recogiste: " + item.getNombre() + ".");
        return true;
    }

    private void abrirCajaFuerte(ObjetoMapa caja) {
        if (!puzzleResuelto) {
            mostrarMensaje("La caja está cerrada. Resuelve el acertijo del libro primero.");
            return;
        }
        if (jugador.getInventario().tieneItem("LLAVE_ESCAPE")) {
            mostrarMensaje("La caja fuerte está vacía.");
            return;
        }
        if (jugador.getInventario().agregarItem(new LlaveEscape())) {
            mapaActual.quitarObjeto(caja);
            mostrarMensaje("La caja se abrió. Encontraste la llave de escape.");
        } else {
            mostrarMensaje("Inventario lleno. Libera un espacio para guardar la llave.");
        }
    }

    private void escapar() {
        if (jugador.getInventario().tieneItem("LLAVE_ESCAPE")) {
            gano = true;
            mostrarMensaje("¡Escapaste! Completaste el rompecabezas y encontraste la salida.");
        } else {
            mostrarMensaje("La salida está cerrada. Busca la llave en la caja fuerte.");
        }
    }

    public boolean usarObjetoSeleccionado() {
        if (gano || libroAbierto || !jugador.isEstaVivo()) {
            return false;
        }
        ObjetoInventario item = jugador.getInventario().getItemSeleccionado();
        if (item == null) {
            mostrarMensaje("Selecciona un objeto del inventario.");
            return false;
        }
        if ("LIBRO_PUZZLE".equals(item.getId())) {
            return abrirLibro();
        }
        if ("BATERIA".equals(item.getId())) {
            boolean usada = jugador.getInventario().usarItemSeleccionado(jugador);
            mostrarMensaje(usada ? "La linterna se recargó."
                    : "La linterna ya está completamente cargada.");
            return usada;
        }
        if ("BOTIQUIN".equals(item.getId())) {
            boolean usado = jugador.getInventario().usarItemSeleccionado(jugador);
            mostrarMensaje(usado ? "Tu salud se restauró por completo."
                    : "Tu salud ya está al máximo.");
            return usado;
        }
        if ("ESCOBA".equals(item.getId())) {
            boolean impacto = estaEntidadAlAlcanceDeEscoba();
            boolean usado = jugador.getInventario().usarItemSeleccionado(jugador);
            if (usado) {
                if (impacto) {
                    entidad.paralizar(2500);
                    mostrarMensaje("Golpeaste a la entidad y la dejaste aturdida.");
                } else {
                    mostrarMensaje("El golpe de escoba no alcanzó a la entidad.");
                }
            }
            return usado;
        }
        boolean usado = jugador.getInventario().usarItemSeleccionado(jugador);
        mostrarMensaje(usado ? "Objeto usado." : "No puedes usar ese objeto ahora.");
        return usado;
    }

    private boolean estaEntidadAlAlcanceDeEscoba() {
        double jugadorX = jugador.getX() + jugador.getAncho() / 2.0;
        double jugadorY = jugador.getY() + jugador.getAlto() / 2.0;
        double entidadX = entidad.getX() + entidad.getAncho() / 2.0;
        double entidadY = entidad.getY() + entidad.getAlto() / 2.0;
        double diferenciaX = entidadX - jugadorX;
        double diferenciaY = entidadY - jugadorY;
        double distancia = Math.hypot(diferenciaX, diferenciaY);
        if (distancia == 0 || distancia > ALCANCE_ESCOBA) {
            return false;
        }
        double frente = diferenciaX * Math.cos(jugador.getAnguloApuntado())
                + diferenciaY * Math.sin(jugador.getAnguloApuntado());
        double lateral = Math.abs(diferenciaX * Math.sin(jugador.getAnguloApuntado())
                - diferenciaY * Math.cos(jugador.getAnguloApuntado()));
        if (frente <= 0 || lateral > frente * Math.tan(Math.PI / 3)) {
            return false;
        }

        int pasos = (int) Math.ceil(distancia / 4.0);
        for (int paso = 1; paso < pasos; paso++) {
            double fraccion = (double) paso / pasos;
            double x = jugadorX + diferenciaX * fraccion;
            double y = jugadorY + diferenciaY * fraccion;
            if (mapaActual.esColision(x - 2, y - 2, 4, 4)) {
                return false;
            }
        }
        return true;
    }

    public boolean abrirLibro() {
        if (!jugador.isEstaVivo() || gano) {
            return false;
        }
        if (!jugador.getInventario().tieneItem("LIBRO_PUZZLE")) {
            mostrarMensaje("Primero debes encontrar el libro de acertijos.");
            return false;
        }
        if (puzzleResuelto) {
            mostrarMensaje("El libro ya está resuelto. La caja fuerte guarda la llave.");
            return false;
        }
        if (numeroPiezas < CANTIDAD_PIEZAS) {
            mostrarMensaje("Te faltan piezas para completar el acertijo: "
                    + numeroPiezas + "/" + CANTIDAD_PIEZAS + ".");
            return false;
        }
        libroAbierto = true;
        return true;
    }

    public boolean resolverPuzzle(String codigo) {
        libroAbierto = false;
        if (codigo != null && ACERTIJOS.get(acertijoId).respuesta()
                .equals(codigo.trim())) {
            puzzleResuelto = true;
            entidad.setVelocidad(jugador.getVelocidadBase());
            mostrarMensaje("¡Acertijo correcto! Usa la llave de la caja fuerte para escapar.");
            return true;
        }
        mostrarMensaje("Acertijo incorrecto. La entidad vuelve a moverse.");
        return false;
    }

    public boolean dispararTaser() {
        boolean impacto = jugador.getTaser().disparar(jugador, entidad);
        mostrarMensaje(impacto
                ? "¡Impacto! La entidad quedó paralizada."
                : "El taser falló o aún se está recargando.");
        return impacto;
    }

    public void seleccionarSlot(int indice) {
        jugador.getInventario().setSlotSeleccionado(indice);
    }

    public DatosPartida crearDatosPartida() {
        List<String> items = new java.util.ArrayList<>(Inventario.CAPACIDAD_MAXIMA);
        for (int i = 0; i < Inventario.CAPACIDAD_MAXIMA; i++) {
            ObjetoInventario item = jugador.getInventario().getItemEnSlot(i);
            items.add(item == null ? "" : item.getId());
        }
        List<DatosMapa> datosMapas = mapas.values().stream()
                .map(mapa -> new DatosMapa(mapa.getId(),
                        mapa.getIdsObjetosPresentes(), mapa.getDatosObjetosSuelo()))
                .toList();
        return new DatosPartida(
                jugador.getX(), jugador.getY(),
                jugador.getPuntoReaparicionX(), jugador.getPuntoReaparicionY(),
                jugador.getSaludActual(), jugador.getStaminaActual(),
                jugador.getLinterna().getNivelBateria(),
                jugador.getLinterna().isEstaEncendida(),
                entidad.getX(), entidad.getY(), entidad.getParalisisRestanteMs(),
                jugador.getTaser().getCooldownRestanteMs(),
                numeroPiezas, puzzleResuelto, gano,
                jugador.getInventario().getSlotSeleccionado(), items,
                mapaActual.getId(), datosMapas, nombreJugador, tiempoTranscurridoMs,
                acertijoId);
    }

    public void restaurarPartida(DatosPartida datos) {
        if (datos == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }
        Mapa mapaGuardado = mapas.get(datos.mapaActualId());
        if (mapaGuardado == null || datos.mapas().size() != mapas.size()) {
            throw new IllegalArgumentException("La partida contiene habitaciones inválidas.");
        }
        Map<String, DatosMapa> mapasGuardados = new LinkedHashMap<>();
        for (DatosMapa mapa : datos.mapas()) {
            if (mapasGuardados.putIfAbsent(mapa.id(), mapa) != null) {
                throw new IllegalArgumentException("La partida contiene habitaciones duplicadas.");
            }
            Mapa destinoMapa = mapas.get(mapa.id());
            if (destinoMapa == null) {
                throw new IllegalArgumentException("La partida contiene una habitación desconocida.");
            }
            destinoMapa.validarEstado(mapa);
        }
        if (!mapasGuardados.keySet().equals(mapas.keySet())) {
            throw new IllegalArgumentException("Faltan datos de una o más habitaciones.");
        }
        validarCoordenadas(mapaGuardado, datos.jugadorX(), datos.jugadorY(),
                jugador.getAncho(), jugador.getAlto(), "jugador");
        validarCoordenadas(mapaGuardado, datos.puntoReaparicionX(), datos.puntoReaparicionY(),
                jugador.getAncho(), jugador.getAlto(), "punto de reaparición");
        validarCoordenadas(mapaGuardado, datos.entidadX(), datos.entidadY(),
                entidad.getAncho(), entidad.getAlto(), "entidad");
        if (datos.salud() < 1 || datos.salud() > jugador.getSaludMax()
                || !Float.isFinite(datos.stamina()) || datos.stamina() < 0
                || datos.stamina() > jugador.getStaminaMax()
                || !Float.isFinite(datos.bateria()) || datos.bateria() < 0
                || datos.bateria() > jugador.getLinterna().getBateriaMax()
                || datos.piezas() < 0 || datos.piezas() > CANTIDAD_PIEZAS
                || datos.paralisisRestanteMs() < 0 || datos.paralisisRestanteMs() > 4000
                || datos.taserCooldownRestanteMs() < 0
                || datos.taserCooldownRestanteMs() > jugador.getTaser().getCooldownMs()
                || datos.slotSeleccionado() < 0
                || datos.slotSeleccionado() >= Inventario.CAPACIDAD_MAXIMA
                || datos.inventario().size() != Inventario.CAPACIDAD_MAXIMA
                || datos.nombreJugador().isBlank() || datos.nombreJugador().length() > 40
                || datos.tiempoTranscurridoMs() < 0
                || datos.acertijoId() < 0 || datos.acertijoId() >= ACERTIJOS.size()) {
            throw new IllegalArgumentException("La partida contiene valores fuera de rango.");
        }

        ObjetoInventario[] items = new ObjetoInventario[Inventario.CAPACIDAD_MAXIMA];
        Set<String> idsItems = new HashSet<>();
        int piezasEnInventario = 0;
        for (int i = 0; i < items.length; i++) {
            String id = datos.inventario().get(i);
            if (id == null || id.isEmpty()) {
                continue;
            }
            if (!idsItems.add(id) && !id.equals("BATERIA")
                    && !id.equals("ESCOBA") && !id.equals("BOTIQUIN")) {
                throw new IllegalArgumentException("La partida contiene objetos duplicados.");
            }
            items[i] = crearItem(id);
            if (id.startsWith("PIEZA_")) {
                piezasEnInventario++;
            }
        }
        int piezasEnSuelo = 0;
        Set<String> idsPiezasSuelo = new HashSet<>();
        Set<String> todosLosItems = new HashSet<>(idsItems);
        int piezasRestantesEnMapas = 0;
        for (Mapa mapa : mapas.values()) {
            DatosMapa mapaDatos = mapasGuardados.get(mapa.getId());
            Set<String> piezasIniciales = mapa.getIdsObjetosIniciales(ObjetoMapa.Tipo.PIEZA);
            piezasRestantesEnMapas += (int) mapaDatos.objetosPresentes().stream()
                    .filter(piezasIniciales::contains).count();
            for (DatosObjetoSuelo objeto : mapaDatos.objetosSuelo()) {
                todosLosItems.add(objeto.id());
                if (objeto.id().startsWith("PIEZA_")) {
                    piezasEnSuelo++;
                    if (!idsPiezasSuelo.add(objeto.id())) {
                        throw new IllegalArgumentException("La partida contiene piezas duplicadas.");
                    }
                }
            }
        }
        if (piezasEnInventario + piezasEnSuelo != datos.piezas()
                || piezasRestantesEnMapas + datos.piezas() != CANTIDAD_PIEZAS) {
            throw new IllegalArgumentException("El inventario y el progreso del puzzle no coinciden.");
        }
        for (int numero = 1; numero <= datos.piezas(); numero++) {
            if (!idsItems.contains("PIEZA_" + numero)
                    && !idsPiezasSuelo.contains("PIEZA_" + numero)) {
                throw new IllegalArgumentException("El inventario de piezas guardado no es válido.");
            }
        }
        boolean libroEnMapa = false;
        boolean cajaEnMapa = false;
        for (Mapa mapa : mapas.values()) {
            DatosMapa mapaDatos = mapasGuardados.get(mapa.getId());
            libroEnMapa |= mapa.getIdsObjetosIniciales(ObjetoMapa.Tipo.LIBRO).stream()
                    .anyMatch(mapaDatos.objetosPresentes()::contains);
            cajaEnMapa |= mapa.getIdsObjetosIniciales(ObjetoMapa.Tipo.CAJA_FUERTE).stream()
                    .anyMatch(mapaDatos.objetosPresentes()::contains);
        }
        if (libroEnMapa == todosLosItems.contains("LIBRO_PUZZLE")
                || cajaEnMapa == todosLosItems.contains("LLAVE_ESCAPE")) {
            throw new IllegalArgumentException("El inventario y el mapa guardados no coinciden.");
        }
        if (datos.puzzleResuelto()
                && (datos.piezas() != CANTIDAD_PIEZAS
                || !todosLosItems.contains("LIBRO_PUZZLE"))) {
            throw new IllegalArgumentException("El estado del puzzle guardado no es válido.");
        }
        if (datos.gano()
                && (!datos.puzzleResuelto() || !idsItems.contains("LLAVE_ESCAPE"))) {
            throw new IllegalArgumentException("El resultado guardado no es válido.");
        }
        if (idsItems.contains("LLAVE_ESCAPE") && !datos.puzzleResuelto()) {
            throw new IllegalArgumentException("La llave se obtuvo antes de resolver el puzzle.");
        }
        for (Mapa mapa : mapas.values()) {
            mapa.restaurarEstado(mapasGuardados.get(mapa.getId()));
        }

        mapaActual = mapaGuardado;
        jugador.restaurarEstado(datos.jugadorX(), datos.jugadorY(),
                datos.puntoReaparicionX(), datos.puntoReaparicionY(),
                datos.salud(), datos.stamina());
        jugador.getInventario().restaurarItems(items, datos.slotSeleccionado());
        jugador.getLinterna().restaurarEstado(
                datos.bateria(), datos.linternaEncendida());
        jugador.getTaser().restaurarCooldownRestanteMs(datos.taserCooldownRestanteMs());
        numeroPiezas = datos.piezas();
        puzzleResuelto = datos.puzzleResuelto();
        gano = datos.gano();
        nombreJugador = datos.nombreJugador();
        tiempoTranscurridoMs = datos.tiempoTranscurridoMs();
        acertijoId = datos.acertijoId();
        invulnerableHastaMs = 0;
        libroAbierto = false;
        entidad.restaurarEstado(datos.entidadX(), datos.entidadY(),
                numeroPiezas >= CANTIDAD_PIEZAS / 2,
                puzzleResuelto, jugador.getVelocidadBase(),
                datos.paralisisRestanteMs());
        mostrarMensaje(gano ? "Partida completada." : "Partida cargada.");
    }

    private void validarCoordenadas(Mapa mapa, double x, double y,
            int ancho, int alto, String elemento) {
        if (!Double.isFinite(x) || !Double.isFinite(y)
                || x < 0 || y < 0 || x + ancho > Mapa.ANCHO || y + alto > Mapa.ALTO
                || mapa.esColision(x, y, ancho, alto)) {
            throw new IllegalArgumentException(
                    "La posición guardada del " + elemento + " no es válida.");
        }
    }

    private ObjetoInventario crearItem(String id) {
        return switch (id) {
            case "BATERIA" -> new Bateria();
            case "BOTIQUIN" -> new Botiquin();
            case "ESCOBA" -> new Escoba();
            case "LIBRO_PUZZLE" -> new LibroPuzzle();
            case "PIEZA_1" -> new PiezaPuzzle(1);
            case "PIEZA_2" -> new PiezaPuzzle(2);
            case "PIEZA_3" -> new PiezaPuzzle(3);
            case "PIEZA_4" -> new PiezaPuzzle(4);
            case "LLAVE_ESCAPE" -> new LlaveEscape();
            default -> throw new IllegalArgumentException(
                    "La partida contiene un objeto desconocido.");
        };
    }

    public void mostrarMensaje(String texto) {
        mensaje = texto;
        mensajeHastaMs = System.currentTimeMillis() + 4500;
    }

    public String getMensaje() {
        return System.currentTimeMillis() <= mensajeHastaMs ? mensaje : "";
    }

    public int getNumeroPiezas() { return numeroPiezas; }
    public int getCantidadPiezas() { return CANTIDAD_PIEZAS; }
    public boolean isPuzzleResuelto() { return puzzleResuelto; }
    public boolean isLibroAbierto() { return libroAbierto; }
    public boolean isGano() { return gano; }
    public boolean isJugadorVivo() { return jugador.isEstaVivo(); }
    public String getNombreJugador() { return nombreJugador; }
    public long getTiempoTranscurridoMs() { return tiempoTranscurridoMs; }
    public int getAcertijoId() { return acertijoId; }
    public String getPistaAcertijo() { return ACERTIJOS.get(acertijoId).pista(); }
    public String getCodigoAcertijo() { return ACERTIJOS.get(acertijoId).respuesta(); }
    public Mapa getMapaActual() { return mapaActual; }
    public Jugador getJugador() { return jugador; }
    public Entidad getEntidad() { return entidad; }
}
