package modelo;

public class Bateria extends Item {
    private static final long serialVersionUID = 1L;
    private static final float CARGA = 40.0f;

    public Bateria() {
        super("BATERIA", "Batería", "Recarga 40% de la linterna.", true);
    }

    @Override
    public boolean usar(Player jugador) {
        float anterior = jugador.getLinterna().getNivelBateria();
        jugador.getLinterna().recargar(CARGA);
        return jugador.getLinterna().getNivelBateria() > anterior;
    }
}
