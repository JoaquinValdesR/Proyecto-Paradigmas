package modelo;

public class Bateria extends ObjetoInventario {
    private static final long serialVersionUID = 1L;
    public Bateria() {
        super("BATERIA", "Batería", "Recarga completamente la linterna.", true);
    }

    @Override
    public boolean usar(Jugador jugador) {
        float anterior = jugador.getLinterna().getNivelBateria();
        jugador.getLinterna().recargar(jugador.getLinterna().getBateriaMax());
        return jugador.getLinterna().getNivelBateria() > anterior;
    }
}
