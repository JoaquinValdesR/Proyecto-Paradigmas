package pruebas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import java.awt.image.BufferedImage;
import java.awt.event.KeyEvent;
import javax.swing.JComponent;
import javax.swing.InputMap;
import javax.swing.KeyStroke;
import controlador.ControladorJuego;
import modelo.Bateria;
import modelo.Botiquin;
import modelo.DatosPartida;
import modelo.Entidad;
import modelo.Escoba;
import modelo.EstadoJuego;
import modelo.Inventario;
import modelo.Mapa;
import modelo.ObjetoMapa;
import modelo.Jugador;
import modelo.Puerta;
import modelo.RegistroPuntaje;
import persistencia.RepositorioPartidas;
import persistencia.RepositorioRanking;
import persistencia.ListadoPartidas;
import persistencia.ResumenPartida;
import vista.PanelJuego;

public class PruebasProyecto {
    public static void main(String[] args) throws IOException {
        probarCicloDeJuego();
        probarInventarioLleno();
        probarPuertasYHabitaciones();
        probarPersistenciaMapa();
        probarUsoDeEscoba();
        probarDuracionYLinternasEnReaparicion();
        probarRecargaLinternaConBateria();
        probarBotiquin();
        probarSprint();
        probarMuerteYReinicio();
        probarTemporizadorYRanking();
        probarAcertijosAleatoriosYPersistencia();
        probarPersistenciaCrud();
        probarInterfazSwing();
        System.out.println("OK: juego, temporizador, ranking, pausa, persistencia e interfaz Swing.");
    }

    private static void probarAcertijosAleatoriosYPersistencia() {
        String[] codigos = {"314", "342", "833", "255", "526"};
        for (int id = 0; id < codigos.length; id++) {
            EstadoJuego juego = new EstadoJuego(id);
            comprobar(juego.getAcertijoId() == id && !juego.getPistaAcertijo().isBlank(),
                    "No se configuró el acertijo " + id + ".");
            comprobar(!juego.resolverPuzzle("000"),
                    "Se aceptó un código incorrecto para el acertijo " + id + ".");
            comprobar(juego.getMensaje().contains("incorrecto"),
                    "No se informó que el acertijo estaba mal resuelto.");
            comprobar(juego.resolverPuzzle(codigos[id]),
                    "No se aceptó la solución del acertijo " + id + ".");
            comprobar(juego.getMensaje().contains("correcto"),
                    "No se informó que el acertijo estaba bien resuelto.");
        }

        EstadoJuego juego = new EstadoJuego(3);
        DatosPartida guardado = juego.crearDatosPartida();
        EstadoJuego restaurado = new EstadoJuego(0);
        restaurado.restaurarPartida(guardado);
        comprobar(restaurado.getAcertijoId() == 3,
                "La partida cargada cambió el acertijo asignado.");
    }

    private static void probarCicloDeJuego() throws IOException {
        EstadoJuego juego = new EstadoJuego();
        irAHabitacion(juego, "BIBLIOTECA");
        ObjetoMapa libro = buscar(juego, ObjetoMapa.Tipo.LIBRO);
        interactuarCon(juego, libro);
        comprobar(juego.getJugador().getInventario().tieneItem("LIBRO_PUZZLE"),
                "No se recogió el libro.");
        volverAlPasillo(juego);

        irAHabitacion(juego, "COCINA");
        ObjetoMapa primeraPieza = buscar(juego, ObjetoMapa.Tipo.PIEZA);
        interactuarCon(juego, primeraPieza);
        comprobar(juego.getNumeroPiezas() == 1, "No se actualizó el progreso de piezas.");
        comprobar(!juego.getMapaActual().getObjetos().contains(primeraPieza),
                "La pieza recogida sigue en el mapa.");
        volverAlPasillo(juego);

        Path directorio = Files.createTempDirectory("mainjuego-prueba");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            DatosPartida guardado = juego.crearDatosPartida();
            repositorio.guardar(guardado);
            juego.getJugador().setX(500);
            juego.restaurarPartida(repositorio.cargar());
            comprobar(juego.getNumeroPiezas() == 1, "No se recuperó el progreso.");
            comprobar(juego.getJugador().getInventario().tieneItem("PIEZA_1"),
                    "No se recuperó la pieza en el inventario.");
            comprobar(juego.getJugador().getX() == guardado.jugadorX(),
                    "No se recuperó la posición del jugador.");
            irAHabitacion(juego, "COCINA");
            comprobar(!juego.getMapaActual().getObjetos().contains(primeraPieza),
                    "Se restauró una pieza que ya se había recogido.");
            volverAlPasillo(juego);

            for (String idHabitacion : List.of("LAB2", "LAB3", "PATIO")) {
                irAHabitacion(juego, idHabitacion);
                interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.PIEZA));
                volverAlPasillo(juego);
            }
            comprobar(juego.getNumeroPiezas() == juego.getCantidadPiezas(),
                    "No se pudieron recoger todas las piezas.");
            comprobar(juego.abrirLibro(), "El libro no se abrió con todas las piezas.");
            comprobar(!juego.resolverPuzzle("000"), "Se aceptó un código incorrecto.");
            comprobar(juego.abrirLibro(), "El libro no volvió a abrirse tras el error.");
            comprobar(juego.resolverPuzzle(juego.getCodigoAcertijo()),
                    "No se aceptó el código correcto.");

            irAHabitacion(juego, "LAB3");
            interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.CAJA_FUERTE));
            comprobar(juego.getJugador().getInventario().tieneItem("LLAVE_ESCAPE"),
                    "La caja fuerte no entregó la llave.");
            volverAlPasillo(juego);
            interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.SALIDA));
            comprobar(juego.isGano(), "No se completó el escape.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarInventarioLleno() {
        EstadoJuego juego = new EstadoJuego();
        Inventario inventario = juego.getJugador().getInventario();
        for (int i = 0; i < Inventario.CAPACIDAD_MAXIMA; i++) {
            comprobar(inventario.agregarItem(new Bateria()),
                    "No se pudo llenar el inventario durante la prueba.");
        }
        irAHabitacion(juego, "COCINA");
        ObjetoMapa pieza = buscar(juego, ObjetoMapa.Tipo.PIEZA);
        interactuarCon(juego, pieza);
        comprobar(juego.getNumeroPiezas() == 0,
                "Se recogió una pieza con el inventario lleno.");
        comprobar(juego.getMapaActual().getObjetos().contains(pieza),
                "Se eliminó del mapa una pieza que no se pudo recoger.");
    }

    private static void probarPuertasYHabitaciones() {
        EstadoJuego juego = new EstadoJuego();
        comprobar("Escapando de la FACE".equals(juego.getMapaActual().getNombre()),
                "El mapa no tiene el nombre nuevo del juego.");
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "El juego no comienza en el pasillo principal.");
        long puertasAbiertas = juego.getMapaActual().getPuertas().stream()
                .filter(puerta -> !puerta.isBloqueada()).count();
        long puertasBloqueadas = juego.getMapaActual().getPuertas().stream()
                .filter(Puerta::isBloqueada).count();
        comprobar(puertasAbiertas == 8 && puertasBloqueadas == 2,
                "El plano no tiene ocho puertas abiertas y dos bloqueadas.");
        comprobar(juego.getMapaActual().esPared(19, 14),
                "El paso entre el patio y el laboratorio 3 sigue abierto.");
        comprobar("Patio".equals(juego.getMapaActual().getNombreZona(12, 14))
                        && "Laboratorio 3".equals(
                                juego.getMapaActual().getNombreZona(23, 15)),
                "El patio y el laboratorio 3 no intercambiaron su ubicación.");
        comprobar(!juego.getMapaActual().esPared(13, 6)
                        && juego.getMapaActual().esPared(4, 1)
                        && juego.getMapaActual().esPared(29, 8),
                "Las puertas no coinciden con sus marcas verdes y negras.");
        for (int[] destino : new int[][]{
            {12, 4}, {18, 4}, {3, 10}, {2, 15}, {23, 15}, {12, 14}, {8, 3}
        }) {
            comprobar(hayRuta(juego.getMapaActual(), 10, 8, destino[0], destino[1]),
                    "La zona en " + destino[0] + "," + destino[1]
                            + " no está conectada al pasillo.");
        }
        for (ObjetoMapa objeto : juego.getMapaActual().getObjetos()) {
            comprobar(!juego.getMapaActual().esPared(
                            objeto.getColumna(), objeto.getFila()),
                    "El objeto " + objeto.getNombre() + " apareció dentro de una pared.");
            comprobar(hayRuta(juego.getMapaActual(), 10, 8,
                            objeto.getColumna(), objeto.getFila()),
                    "El objeto " + objeto.getNombre() + " no es accesible desde el inicio.");
        }
        for (ObjetoMapa objeto : List.copyOf(juego.getMapaActual().getObjetos())) {
            juego.getJugador().setX(objeto.getCentroX()
                    - juego.getJugador().getAncho() / 2.0);
            juego.getJugador().setY(objeto.getCentroY()
                    - juego.getJugador().getAlto() / 2.0);
            juego.interactuar();
            comprobar(!"No hay nada que puedas recoger o usar cerca."
                            .equals(juego.getMensaje()),
                    "No se pudo interactuar con " + objeto.getNombre() + " en su ubicación.");
        }

        Puerta bloqueada = juego.getMapaActual().getPuertas().stream()
                .filter(Puerta::isBloqueada).findFirst().orElseThrow();
        juego.getJugador().setX(bloqueada.getTileX() * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(bloqueada.getTileY() * Mapa.TILE_SIZE + 4);
        juego.interactuar();
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "Se pudo entrar en una habitación bloqueada.");
        comprobar(juego.getMensaje().contains("cerrada"),
                "No se informó que la puerta está bloqueada.");

        irAHabitacion(juego, "COCINA");
        comprobar("Baños".equals(juego.getMapaActual().getNombreZona(
                        (int) (juego.getJugador().getX() / Mapa.TILE_SIZE),
                        (int) (juego.getJugador().getY() / Mapa.TILE_SIZE))),
                "No se pudo llegar a los baños.");
        volverAlPasillo(juego);
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "No se pudo recorrer el pasillo principal.");
    }

    private static void probarPersistenciaMapa() throws IOException {
        EstadoJuego juego = new EstadoJuego();
        irAHabitacion(juego, "TIENDA");
        double xSuelo = juego.getJugador().getX() + juego.getJugador().getAncho() / 2.0;
        double ySuelo = juego.getJugador().getY() + juego.getJugador().getAlto() / 2.0;
        comprobar(juego.getMapaActual().agregarObjetoSuelo(new Escoba(), xSuelo, ySuelo),
                "No se pudo crear el objeto de prueba en el suelo.");

        Path directorio = Files.createTempDirectory("mainjuego-mapa");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            repositorio.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(repositorio.cargar());
            comprobar(Mapa.PASILLO.equals(cargada.getMapaActual().getId()),
                    "No se restauró el plano principal.");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "No se restauró el objeto del suelo en el plano.");
            volverAlPasillo(cargada);
            irAHabitacion(cargada, "TIENDA");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "Se perdió el estado del objeto del suelo al recorrer el mapa.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarDuracionYLinternasEnReaparicion() {
        EstadoJuego juego = new EstadoJuego();
        var jugador = juego.getJugador();
        var linterna = jugador.getLinterna();

        linterna.actualizar(20);
        comprobar(Math.abs(linterna.getNivelBateria() - 50) < 0.01,
                "La linterna no dura aproximadamente 40 segundos.");
        jugador.recibirDano(jugador.getSaludMax());
        comprobar(!jugador.isEstaVivo() && jugador.getSaludActual() == 0,
                "La muerte no dejó al jugador en estado muerto.");
        jugador.reaparecer();
        comprobar(linterna.getNivelBateria() == linterna.getBateriaMax(),
                "La linterna no se recargó al reaparecer.");
        comprobar(linterna.isEstaEncendida(),
                "La linterna no se encendió al reaparecer.");

        linterna.actualizar(39.9);
        comprobar(linterna.getNivelBateria() > 0 && linterna.isEstaEncendida(),
                "La linterna se agotó antes de los 40 segundos.");
        linterna.actualizar(0.1);
        comprobar(linterna.getNivelBateria() == 0 && !linterna.isEstaEncendida(),
                "La linterna no se agotó después de 40 segundos.");
    }

    private static void probarRecargaLinternaConBateria() {
        EstadoJuego juego = new EstadoJuego();
        var linterna = juego.getJugador().getLinterna();
        var inventario = juego.getJugador().getInventario();
        linterna.actualizar(20);
        comprobar(inventario.agregarItem(new Bateria()),
                "No se pudo agregar la batería para la prueba.");
        comprobar(juego.usarObjetoSeleccionado(),
                "No se pudo usar la batería recogida.");
        comprobar(linterna.getNivelBateria() == linterna.getBateriaMax(),
                "La batería no recargó completamente la linterna.");
        comprobar(inventario.getItemSeleccionado() == null,
                "La batería usada no se consumió.");
        comprobar("La linterna se recargó.".equals(juego.getMensaje()),
                "No se informó que la linterna se recargó.");

        comprobar(inventario.agregarItem(new Bateria()),
                "No se pudo agregar una segunda batería para la prueba.");
        comprobar(!juego.usarObjetoSeleccionado(),
                "Se usó una batería cuando la linterna ya estaba completamente cargada.");
        comprobar(inventario.getItemSeleccionado() instanceof Bateria,
                "Se consumió una batería que no produjo una recarga.");
    }

    private static void probarBotiquin() {
        EstadoJuego juego = new EstadoJuego();
        var jugador = juego.getJugador();
        var inventario = jugador.getInventario();
        jugador.recibirDano(65);
        ObjetoMapa botiquinMapa = buscar(juego, ObjetoMapa.Tipo.BOTIQUIN);
        jugador.setX(botiquinMapa.getCentroX() - jugador.getAncho() / 2.0);
        jugador.setY(botiquinMapa.getCentroY() - jugador.getAlto() / 2.0);
        juego.interactuar();

        comprobar(jugador.getSaludActual() == 35,
                "El botiquín curó al recogerlo en lugar de guardarse.");
        comprobar(inventario.getItemSeleccionado() instanceof Botiquin,
                "El botiquín no se agregó al inventario.");
        comprobar(!juego.getMapaActual().getObjetos().contains(botiquinMapa),
                "El botiquín recogido no desapareció del mapa.");
        comprobar(juego.usarObjetoSeleccionado(),
                "No se pudo consumir el botiquín.");
        comprobar(jugador.getSaludActual() == jugador.getSaludMax(),
                "El botiquín no restauró toda la salud.");
        comprobar(inventario.getItemSeleccionado() == null,
                "El botiquín consumido no desapareció del inventario.");
    }

    private static void probarSprint() {
        Mapa mapa = new Mapa();
        Jugador caminando = new Jugador(14 * Mapa.TILE_SIZE + 4,
                8 * Mapa.TILE_SIZE + 4);
        double xInicial = caminando.getX();
        caminando.mover(1, 0, mapa, 0.5);
        double distanciaCaminando = caminando.getX() - xInicial;

        Jugador corriendo = new Jugador(14 * Mapa.TILE_SIZE + 4,
                8 * Mapa.TILE_SIZE + 4);
        xInicial = corriendo.getX();
        corriendo.actualizarStamina(true, true, 0.5);
        corriendo.mover(1, 0, mapa, 0.5);
        comprobar(corriendo.getX() - xInicial > distanciaCaminando,
                "El sprint no aumenta la velocidad respecto a caminar.");
        comprobar(Math.abs(corriendo.getStaminaActual() - 90) < 0.01,
                "El sprint no consume stamina.");

        for (int[] direccion : new int[][]{
            {0, -1}, {0, 1}, {-1, 0}, {1, 0},
            {-1, -1}, {1, -1}, {-1, 1}, {1, 1}
        }) {
            Jugador movimiento = new Jugador(14 * Mapa.TILE_SIZE + 4,
                    8 * Mapa.TILE_SIZE + 4);
            xInicial = movimiento.getX();
            double yInicial = movimiento.getY();
            movimiento.actualizarStamina(true, true, 0.1);
            movimiento.mover(direccion[0], direccion[1], mapa, 0.1);
            comprobar((direccion[0] == 0 || Math.signum(movimiento.getX() - xInicial)
                            == direccion[0])
                            && (direccion[1] == 0 || Math.signum(movimiento.getY() - yInicial)
                            == direccion[1]),
                    "El sprint no funciona en todas las direcciones.");
        }

        Entidad entidad = new Entidad(0, 0);
        comprobar(entidad.getVelocidadActual() == 112,
                "La velocidad de la primera fase de la entidad no es 112.");
        entidad.activarModoFuria();
        comprobar(corriendo.getVelocidadSprint() == 180
                        && entidad.getVelocidadActual() == 150,
                "Se modificaron las velocidades configuradas.");
    }

    private static void probarMuerteYReinicio() {
        EstadoJuego juego = new EstadoJuego();
        juego.getJugador().getInventario().agregarItem(new Bateria());
        juego.getJugador().setX(500);
        juego.getJugador().recibirDano(juego.getJugador().getSaludMax());

        PanelJuego panel = new PanelJuego(juego);
        panel.setSize(Mapa.ANCHO, Mapa.ALTO);
        comprobar(panel.obtenerAccionMuerte(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 40)
                        == PanelJuego.AccionMuerte.REINTENTAR,
                "No se detectó el botón de reintento.");
        comprobar(panel.obtenerAccionMuerte(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 100)
                        == PanelJuego.AccionMuerte.MENU_PRINCIPAL,
                "No se detectó el botón del menú principal.");
        comprobar(panel.obtenerAccionFinal(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 95)
                        == PanelJuego.AccionFinal.VOLVER_A_JUGAR,
                "No se detectó el botón para volver a jugar.");
        comprobar(panel.obtenerAccionFinal(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 155)
                        == PanelJuego.AccionFinal.MENU_PRINCIPAL,
                "No se detectó el botón del menú principal al ganar.");

        juego.reiniciarPartida();
        comprobar(juego.isJugadorVivo(), "El reinicio dejó al jugador muerto.");
        comprobar(juego.getJugador().getX() == 10 * Mapa.TILE_SIZE + 4,
                "El reinicio no devolvió al jugador al punto inicial.");
        comprobar(juego.getJugador().getInventario().getItemEnSlot(0) == null,
                "El reinicio conservó objetos del inventario.");
        comprobar(juego.getNumeroPiezas() == 0 && !juego.isPuzzleResuelto(),
                "El reinicio conservó el progreso de la partida anterior.");
        comprobar(juego.getMapaActual().getObjetos().size() == 12,
                "El reinicio no restauró los objetos iniciales del mapa.");
    }

    private static void probarTemporizadorYRanking() throws IOException {
        Path directorio = Files.createTempDirectory("mainjuego-ranking");
        RepositorioPartidas partidas = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        Path archivoRanking = directorio.resolve("ranking.properties");
        RepositorioRanking ranking = new RepositorioRanking(archivoRanking);
        try {
            EstadoJuego juego = new EstadoJuego();
            juego.reiniciarPartida("Ada");
            juego.sumarTiempoPartida(65_432);
            partidas.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(partidas.cargar());
            comprobar("Ada".equals(cargada.getNombreJugador()),
                    "No se conservó el nombre en el guardado.");
            comprobar(cargada.getTiempoTranscurridoMs() == 65_432,
                    "No se conservó el tiempo en el guardado.");
            comprobar(cargada.getAcertijoId() == juego.getAcertijoId(),
                    "No se conservó el acertijo de la partida guardada.");

            juego.reiniciarPartida("Guardado anterior");
            partidas.guardar(juego.crearDatosPartida());
            juego.reiniciarPartida("Ada");
            juego.sumarTiempoPartida(65_432);
            ResumenPartida ada = partidas.guardarNueva(juego.crearDatosPartida());
            juego.reiniciarPartida("ada");
            juego.sumarTiempoPartida(66_432);
            ResumenPartida adaActualizada = partidas.guardarNueva(juego.crearDatosPartida());
            comprobar(!ada.id().equals(adaActualizada.id()),
                    "Un guardado con el mismo nombre sobrescribió una partida anterior.");
            juego.reiniciarPartida("Bea");
            juego.sumarTiempoPartida(123_000);
            ResumenPartida bea = partidas.guardarNueva(juego.crearDatosPartida());
            var guardadas = partidas.listarPartidas().partidas();
            comprobar(guardadas.size() == 4,
                    "No se listaron todos los archivos de partidas guardadas.");
            comprobar(guardadas.stream().anyMatch(partida ->
                            partida.id().equals(ada.id())
                            && partida.nombreJugador().equals("Ada")
                            && partida.tiempoTranscurridoMs() == 65_432)
                    && guardadas.stream().anyMatch(partida ->
                            partida.id().equals(adaActualizada.id())
                            && partida.nombreJugador().equals("ada")
                            && partida.tiempoTranscurridoMs() == 66_432)
                    && guardadas.stream().anyMatch(partida ->
                            partida.id().equals(bea.id())
                            && partida.nombreJugador().equals("Bea")
                            && partida.tiempoTranscurridoMs() == 123_000),
                    "La lista no contiene el nombre y el tiempo de cada partida.");
            DatosPartida adaCargada = partidas.cargar(ada.id());
            comprobar("Ada".equals(adaCargada.nombreJugador())
                            && adaCargada.tiempoTranscurridoMs() == 65_432,
                    "No se pudo cargar el primer guardado con ese nombre.");
            DatosPartida adaActualizadaCargada = partidas.cargar(adaActualizada.id());
            comprobar("ada".equals(adaActualizadaCargada.nombreJugador())
                            && adaActualizadaCargada.tiempoTranscurridoMs() == 66_432,
                    "No se pudo cargar el segundo guardado con ese nombre.");
            comprobar(partidas.eliminar(ada.id()),
                    "No se pudo borrar la partida seleccionada.");
            var guardadasTrasBorrar = partidas.listarPartidas().partidas();
            comprobar(guardadasTrasBorrar.stream()
                            .noneMatch(partida -> partida.id().equals(ada.id()))
                            && guardadasTrasBorrar.stream()
                                    .anyMatch(partida -> partida.id()
                                            .equals(adaActualizada.id())),
                    "Borrar una partida afectó a otra partida guardada.");

            java.util.Properties propiedades = new java.util.Properties();
            try (var lector = Files.newBufferedReader(partidas.getArchivo())) {
                propiedades.load(lector);
            }
            propiedades.setProperty("version", "1");
            try (var escritor = Files.newBufferedWriter(partidas.getArchivo())) {
                propiedades.store(escritor, "guardado antiguo incompatible");
            }
            ListadoPartidas listadoCompatible = partidas.listarPartidas();
            comprobar(listadoCompatible.partidas().size() == 2
                            && listadoCompatible.guardadoAnteriorNoCompatible(),
                    "Un guardado antiguo incompatible impidió listar las partidas vigentes.");

            propiedades.setProperty("version", "3");
            propiedades.remove("jugador.nombre");
            propiedades.remove("partida.tiempo.ms");
            try (var escritor = Files.newBufferedWriter(partidas.getArchivo())) {
                propiedades.store(escritor, "guardado versión anterior");
            }
            EstadoJuego anterior = new EstadoJuego();
            anterior.restaurarPartida(partidas.cargar());
            comprobar("Jugador".equals(anterior.getNombreJugador())
                            && anterior.getTiempoTranscurridoMs() == 0,
                    "No se pudo cargar un guardado de versión anterior.");

            ranking.registrar(new RegistroPuntaje("Lento", 90_000, 1_700_000_000_000L));
            ranking.registrar(new RegistroPuntaje("Rápido", 45_000, 1_710_000_000_000L));
            List<RegistroPuntaje> registros = ranking.listar();
            comprobar(registros.size() == 2
                            && "Rápido".equals(registros.get(0).nombreJugador())
                            && "Lento".equals(registros.get(1).nombreJugador())
                            && registros.get(0).fechaMs() == 1_710_000_000_000L
                            && registros.get(1).fechaMs() == 1_700_000_000_000L,
                    "El ranking no ordenó los tiempos o no conservó la fecha.");

            java.util.Properties rankingAnterior = new java.util.Properties();
            try (var lector = Files.newBufferedReader(archivoRanking)) {
                rankingAnterior.load(lector);
            }
            rankingAnterior.setProperty("version", "1");
            rankingAnterior.remove("registro.0.fecha.ms");
            rankingAnterior.remove("registro.1.fecha.ms");
            try (var escritor = Files.newBufferedWriter(archivoRanking)) {
                rankingAnterior.store(escritor, "ranking previo sin fechas");
            }
            long fechaAnterior = Files.getLastModifiedTime(archivoRanking).toMillis();
            comprobar(ranking.listar().stream()
                            .allMatch(registro -> registro.fechaMs() == fechaAnterior),
                    "No se compatibilizó el ranking antiguo sin fechas.");
        } finally {
            Path carpetaPartidas = directorio.resolve("partidas");
            if (Files.isDirectory(carpetaPartidas)) {
                try (var archivos = Files.newDirectoryStream(carpetaPartidas)) {
                    for (Path archivo : archivos) {
                        Files.deleteIfExists(archivo);
                    }
                }
                Files.deleteIfExists(carpetaPartidas);
            }
            Files.deleteIfExists(directorio.resolve("partida.properties"));
            Files.deleteIfExists(directorio.resolve("ranking.properties"));
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarUsoDeEscoba() {
        EstadoJuego juego = new EstadoJuego();
        Inventario inventario = juego.getJugador().getInventario();
        comprobar(inventario.agregarItem(new Escoba()), "No se agregó la escoba de prueba.");
        juego.getJugador().setAnguloApuntado(0);
        juego.getEntidad().setX(juego.getJugador().getX() + 34);
        juego.getEntidad().setY(juego.getJugador().getY());

        comprobar(juego.usarObjetoSeleccionado(), "No se usó la escoba equipada.");
        comprobar(inventario.getItemSeleccionado() == null,
                "La escoba usada permaneció en el inventario.");
        comprobar(juego.getEntidad().isEstaParalizado(),
                "El golpe cuerpo a cuerpo no aturdió a la entidad.");
        int saludAntesDeColision = juego.getJugador().getSaludActual();
        juego.getEntidad().setX(juego.getJugador().getX());
        juego.getEntidad().setY(juego.getJugador().getY());
        juego.getEntidad().comprobarColisionJugador(juego.getJugador());
        comprobar(juego.getJugador().getSaludActual() == saludAntesDeColision,
                "La entidad hizo daño mientras estaba aturdida.");

        EstadoJuego juegoFueraAlcance = new EstadoJuego();
        Inventario inventarioFueraAlcance = juegoFueraAlcance.getJugador().getInventario();
        comprobar(inventarioFueraAlcance.agregarItem(new Escoba()),
                "No se agregó la escoba para probar el alcance.");
        juegoFueraAlcance.getJugador().setAnguloApuntado(0);
        juegoFueraAlcance.getEntidad().setX(
                juegoFueraAlcance.getJugador().getX() + 100);
        juegoFueraAlcance.getEntidad().setY(juegoFueraAlcance.getJugador().getY());
        juegoFueraAlcance.usarObjetoSeleccionado();
        comprobar(inventarioFueraAlcance.getItemSeleccionado() == null
                        && !juegoFueraAlcance.getEntidad().isEstaParalizado(),
                "La escoba fuera de alcance no se consumió como uso único.");

    }

    private static void probarPersistenciaCrud() throws IOException {
        Path directorio = Files.createTempDirectory("mainjuego-crud");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            EstadoJuego juego = new EstadoJuego();
            comprobar(!repositorio.existe(), "La partida ya existía antes de guardarla.");
            double xSuelo = juego.getJugador().getX() + juego.getJugador().getAncho() / 2.0;
            double ySuelo = juego.getJugador().getY() + juego.getJugador().getAlto() / 2.0;
            comprobar(juego.getMapaActual().agregarObjetoSuelo(new Escoba(), xSuelo, ySuelo),
                    "No se pudo crear el objeto de prueba para guardar.");
            repositorio.guardar(juego.crearDatosPartida());
            comprobar(repositorio.existe(), "No se creó el archivo de partida.");

            juego.getJugador().setX(400);
            repositorio.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(repositorio.cargar());
            comprobar(cargada.getJugador().getX() == 400,
                    "No se actualizó la partida existente.");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "La partida actualizada no conservó el objeto del suelo.");
            comprobar(repositorio.eliminar(), "No se eliminó la partida.");
            comprobar(!repositorio.existe(), "El archivo no se eliminó.");

            boolean rechazoPartidaAusente = false;
            try {
                repositorio.cargar();
            } catch (IOException ex) {
                rechazoPartidaAusente = true;
            }
            comprobar(rechazoPartidaAusente, "Se aceptó cargar una partida inexistente.");

            Files.writeString(repositorio.getArchivo(), "version=desconocida\n");
            boolean rechazoVersionInvalida = false;
            try {
                repositorio.cargar();
            } catch (IOException ex) {
                rechazoVersionInvalida = true;
            }
            comprobar(rechazoVersionInvalida, "Se aceptó un archivo de partida inválido.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarInterfazSwing() {
        EstadoJuego juego = new EstadoJuego();
        PanelJuego panel = new PanelJuego(juego);
        panel.setSize(Mapa.ANCHO, Mapa.ALTO);
        BufferedImage imagen = new BufferedImage(
                Mapa.ANCHO, Mapa.ALTO, BufferedImage.TYPE_INT_ARGB);
        var graficos = imagen.createGraphics();
        panel.paint(graficos);
        graficos.dispose();

        ControladorJuego controlador = new ControladorJuego(juego, panel);
        comprobar(controlador.crearBarraMenu().getMenuCount() == 1,
                "No se creó el menú Swing de partida.");
        Object accionEscape = panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .get(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0));
        comprobar("pausa".equals(accionEscape),
                "La tecla ESC no quedó vinculada al menú de pausa.");
        InputMap entrada = panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        comprobar(entrada.get(KeyStroke.getKeyStroke(KeyEvent.VK_Q, 0)) == null,
                "La tecla Q todavía permite botar objetos.");
        for (int codigo : new int[]{
            KeyEvent.VK_W, KeyEvent.VK_A, KeyEvent.VK_S, KeyEvent.VK_D,
            KeyEvent.VK_UP, KeyEvent.VK_LEFT, KeyEvent.VK_DOWN, KeyEvent.VK_RIGHT
        }) {
            Object accionNormal = entrada.get(KeyStroke.getKeyStroke(codigo, 0, false));
            Object accionShift = entrada.get(KeyStroke.getKeyStroke(
                    codigo, java.awt.event.InputEvent.SHIFT_DOWN_MASK, false));
            comprobar(accionNormal != null && accionNormal.equals(accionShift),
                    "Shift bloquea el movimiento con una de las teclas direccionales.");
        }
        panel.setPausado(true);
        comprobar(panel.obtenerAccionPausa(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 40)
                        == PanelJuego.AccionPausa.REANUDAR,
                "No se detectó la opción para reanudar.");
        comprobar(panel.obtenerAccionPausa(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 100)
                        == PanelJuego.AccionPausa.GUARDAR_PARTIDA,
                "No se detectó la opción para guardar la partida.");
        comprobar(panel.obtenerAccionPausa(Mapa.ANCHO / 2, Mapa.ALTO / 2 + 160)
                        == PanelJuego.AccionPausa.MENU_PRINCIPAL,
                "No se detectó la opción para volver al menú.");
        var graficosPausa = imagen.createGraphics();
        panel.paint(graficosPausa);
        graficosPausa.dispose();
    }

    private static ObjetoMapa buscar(EstadoJuego juego, ObjetoMapa.Tipo tipo) {
        return juego.getMapaActual().getObjetos().stream()
                .filter(objeto -> objeto.getTipo() == tipo)
                .findFirst()
                .orElseThrow(() -> new AssertionError("Falta objeto de tipo " + tipo));
    }

    private static void irAHabitacion(EstadoJuego juego, String idHabitacion) {
        int[] posicion = switch (idHabitacion) {
            case "BIBLIOTECA", "LAB1" -> new int[]{12, 4};
            case "DORMITORIO", "LAB2" -> new int[]{18, 4};
            case "COCINA", "BAÑOS" -> new int[]{3, 10};
            case "COMEDOR", "TIENDA" -> new int[]{2, 15};
            case "BODEGA", "LAB3" -> new int[]{23, 15};
            case "TALLER", "PATIO" -> new int[]{12, 14};
            default -> throw new AssertionError("Zona desconocida: " + idHabitacion);
        };
        juego.getJugador().setX(posicion[0] * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(posicion[1] * Mapa.TILE_SIZE + 4);
        String zonaEsperada = switch (idHabitacion) {
            case "BIBLIOTECA", "LAB1" -> "Laboratorio 1";
            case "DORMITORIO", "LAB2" -> "Laboratorio 2";
            case "COCINA", "BAÑOS" -> "Baños";
            case "COMEDOR", "TIENDA" -> "Tienda";
            case "BODEGA", "LAB3" -> "Laboratorio 3";
            case "TALLER", "PATIO" -> "Patio";
            default -> throw new AssertionError("Zona desconocida: " + idHabitacion);
        };
        comprobar(zonaEsperada.equals(juego.getMapaActual().getNombreZona(
                        posicion[0], posicion[1])),
                "No se pudo acceder a " + zonaEsperada + ".");
    }

    private static void volverAlPasillo(EstadoJuego juego) {
        juego.getJugador().setX(10 * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(8 * Mapa.TILE_SIZE + 4);
        comprobar("Pasillo principal".equals(juego.getMapaActual().getNombreZona(10, 8)),
                "No se pudo regresar al pasillo principal.");
    }

    private static boolean hayRuta(Mapa mapa, int inicioX, int inicioY, int destinoX, int destinoY) {
        boolean[][] visitadas = new boolean[Mapa.FILAS][Mapa.COLUMNAS];
        Queue<int[]> pendientes = new ArrayDeque<>();
        pendientes.add(new int[]{inicioX, inicioY});
        visitadas[inicioY][inicioX] = true;
        int[][] movimientos = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        while (!pendientes.isEmpty()) {
            int[] actual = pendientes.remove();
            if (actual[0] == destinoX && actual[1] == destinoY) {
                return true;
            }
            for (int[] movimiento : movimientos) {
                int x = actual[0] + movimiento[0];
                int y = actual[1] + movimiento[1];
                if (x >= 0 && x < Mapa.COLUMNAS && y >= 0 && y < Mapa.FILAS
                        && !visitadas[y][x]
                        && !mapa.esColision(x * Mapa.TILE_SIZE + 4,
                                y * Mapa.TILE_SIZE + 4, 24, 24)) {
                    visitadas[y][x] = true;
                    pendientes.add(new int[]{x, y});
                }
            }
        }
        return false;
    }

    private static void interactuarCon(EstadoJuego juego, ObjetoMapa objeto) {
        juego.getJugador().setX(objeto.getCentroX() - juego.getJugador().getAncho() / 2.0);
        juego.getJugador().setY(objeto.getCentroY() - juego.getJugador().getAlto() / 2.0);
        juego.interactuar();
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
