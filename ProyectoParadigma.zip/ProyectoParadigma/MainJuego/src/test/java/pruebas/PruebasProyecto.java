package pruebas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import java.awt.image.BufferedImage;
import controlador.ControladorJuego;
import modelo.Bateria;
import modelo.DatosPartida;
import modelo.Escoba;
import modelo.EstadoJuego;
import modelo.Inventory;
import modelo.Mapa;
import modelo.ObjetoMapa;
import modelo.Puerta;
import persistencia.RepositorioPartidas;
import vista.PanelJuego;

public class PruebasProyecto {
    public static void main(String[] args) throws IOException {
        probarCicloDeJuego();
        probarInventarioLleno();
        probarPuertasYHabitaciones();
        probarPersistenciaMapa();
        probarLanzarYBotarObjetos();
        probarDuracionYLinternasEnReaparicion();
        probarPersistenciaCrud();
        probarInterfazSwing();
        System.out.println("OK: plano, puertas, ciclo de juego, objetos, linterna, persistencia CRUD e interfaz Swing.");
    }

    private static void probarCicloDeJuego() throws IOException {
        EstadoJuego juego = new EstadoJuego();
        irAHabitacion(juego, "BIBLIOTECA");
        ObjetoMapa libro = buscar(juego, ObjetoMapa.Tipo.LIBRO);
        interactuarCon(juego, libro);
        comprobar(juego.getJugador().getInventario().tieneItem("LIBRO_PUZZLE"),
                "No se recogió el libro.");
        volverAlPasillo(juego);

        irAHabitacion(juego, "COCINA");
        ObjetoMapa primeraPieza = buscar(juego, ObjetoMapa.Tipo.PIEZA);
        interactuarCon(juego, primeraPieza);
        comprobar(juego.getNumeroPiezas() == 1, "No se actualizó el progreso de piezas.");
        comprobar(!juego.getMapaActual().getObjetos().contains(primeraPieza),
                "La pieza recogida sigue en el mapa.");
        volverAlPasillo(juego);

        Path directorio = Files.createTempDirectory("mainjuego-prueba");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            DatosPartida guardado = juego.crearDatosPartida();
            repositorio.guardar(guardado);
            juego.getJugador().setX(500);
            juego.restaurarPartida(repositorio.cargar());
            comprobar(juego.getNumeroPiezas() == 1, "No se recuperó el progreso.");
            comprobar(juego.getJugador().getInventario().tieneItem("PIEZA_1"),
                    "No se recuperó la pieza en el inventario.");
            comprobar(juego.getJugador().getX() == guardado.jugadorX(),
                    "No se recuperó la posición del jugador.");
            irAHabitacion(juego, "COCINA");
            comprobar(!juego.getMapaActual().getObjetos().contains(primeraPieza),
                    "Se restauró una pieza que ya se había recogido.");
            volverAlPasillo(juego);

            for (String idHabitacion : List.of("LAB2", "LAB3", "PATIO")) {
                irAHabitacion(juego, idHabitacion);
                interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.PIEZA));
                volverAlPasillo(juego);
            }
            comprobar(juego.getNumeroPiezas() == juego.getCantidadPiezas(),
                    "No se pudieron recoger todas las piezas.");
            comprobar(juego.abrirLibro(), "El libro no se abrió con todas las piezas.");
            comprobar(!juego.resolverPuzzle("000"), "Se aceptó un código incorrecto.");
            comprobar(juego.abrirLibro(), "El libro no volvió a abrirse tras el error.");
            comprobar(juego.resolverPuzzle("314"), "No se aceptó el código correcto.");

            irAHabitacion(juego, "LAB3");
            interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.CAJA_FUERTE));
            comprobar(juego.getJugador().getInventario().tieneItem("LLAVE_ESCAPE"),
                    "La caja fuerte no entregó la llave.");
            volverAlPasillo(juego);
            interactuarCon(juego, buscar(juego, ObjetoMapa.Tipo.SALIDA));
            comprobar(juego.isGano(), "No se completó el escape.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarInventarioLleno() {
        EstadoJuego juego = new EstadoJuego();
        Inventory inventario = juego.getJugador().getInventario();
        for (int i = 0; i < Inventory.CAPACIDAD_MAXIMA; i++) {
            comprobar(inventario.agregarItem(new Bateria()),
                    "No se pudo llenar el inventario durante la prueba.");
        }
        irAHabitacion(juego, "COCINA");
        ObjetoMapa pieza = buscar(juego, ObjetoMapa.Tipo.PIEZA);
        interactuarCon(juego, pieza);
        comprobar(juego.getNumeroPiezas() == 0,
                "Se recogió una pieza con el inventario lleno.");
        comprobar(juego.getMapaActual().getObjetos().contains(pieza),
                "Se eliminó del mapa una pieza que no se pudo recoger.");
    }

    private static void probarPuertasYHabitaciones() {
        EstadoJuego juego = new EstadoJuego();
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "El juego no comienza en el pasillo principal.");
        long puertasAbiertas = juego.getMapaActual().getPuertas().stream()
                .filter(puerta -> !puerta.isBloqueada()).count();
        long puertasBloqueadas = juego.getMapaActual().getPuertas().stream()
                .filter(Puerta::isBloqueada).count();
        comprobar(puertasAbiertas == 9 && puertasBloqueadas == 2,
                "El plano no tiene nueve puertas abiertas y dos bloqueadas.");
        comprobar(!juego.getMapaActual().esPared(13, 6)
                        && juego.getMapaActual().esPared(4, 1)
                        && juego.getMapaActual().esPared(29, 8),
                "Las puertas no coinciden con sus marcas verdes y negras.");
        for (int[] destino : new int[][]{
            {12, 4}, {18, 4}, {3, 10}, {2, 15}, {12, 14}, {23, 15}, {8, 3}
        }) {
            comprobar(hayRuta(juego.getMapaActual(), 10, 8, destino[0], destino[1]),
                    "La zona en " + destino[0] + "," + destino[1]
                            + " no está conectada al pasillo.");
        }

        Puerta bloqueada = juego.getMapaActual().getPuertas().stream()
                .filter(Puerta::isBloqueada).findFirst().orElseThrow();
        juego.getJugador().setX(bloqueada.getTileX() * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(bloqueada.getTileY() * Mapa.TILE_SIZE + 4);
        juego.interactuar();
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "Se pudo entrar en una habitación bloqueada.");
        comprobar(juego.getMensaje().contains("cerrada"),
                "No se informó que la puerta está bloqueada.");

        irAHabitacion(juego, "COCINA");
        comprobar("Baños".equals(juego.getMapaActual().getNombreZona(
                        (int) (juego.getJugador().getX() / Mapa.TILE_SIZE),
                        (int) (juego.getJugador().getY() / Mapa.TILE_SIZE))),
                "No se pudo llegar a los baños.");
        volverAlPasillo(juego);
        comprobar(Mapa.PASILLO.equals(juego.getMapaActual().getId()),
                "No se pudo recorrer el pasillo principal.");
    }

    private static void probarPersistenciaMapa() throws IOException {
        EstadoJuego juego = new EstadoJuego();
        irAHabitacion(juego, "TIENDA");
        comprobar(juego.getJugador().getInventario().agregarItem(new Escoba()),
                "No se agregó el objeto para la prueba de persistencia del plano.");
        comprobar(juego.soltarObjetoSeleccionado(),
                "No se pudo botar un objeto en el plano.");

        Path directorio = Files.createTempDirectory("mainjuego-mapa");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            repositorio.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(repositorio.cargar());
            comprobar(Mapa.PASILLO.equals(cargada.getMapaActual().getId()),
                    "No se restauró el plano principal.");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "No se restauró el objeto botado en el plano.");
            volverAlPasillo(cargada);
            irAHabitacion(cargada, "TIENDA");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "Se perdió el estado del objeto botado al recorrer el mapa.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarDuracionYLinternasEnReaparicion() {
        EstadoJuego juego = new EstadoJuego();
        var jugador = juego.getJugador();
        var linterna = jugador.getLinterna();

        linterna.actualizar(45);
        comprobar(Math.abs(linterna.getNivelBateria() - 50) < 0.01,
                "La batería no dura aproximadamente 90 segundos.");
        jugador.recibirDano(jugador.getSaludMax());
        comprobar(linterna.getNivelBateria() == linterna.getBateriaMax(),
                "La linterna no se recargó al reaparecer.");
        comprobar(linterna.isEstaEncendida(),
                "La linterna no se encendió al reaparecer.");

        linterna.actualizar(89);
        comprobar(linterna.getNivelBateria() > 0 && linterna.isEstaEncendida(),
                "La linterna se agotó antes de los 90 segundos.");
        linterna.actualizar(1);
        comprobar(linterna.getNivelBateria() == 0 && !linterna.isEstaEncendida(),
                "La linterna no se agotó después de 90 segundos.");
    }

    private static void probarLanzarYBotarObjetos() throws IOException {
        EstadoJuego juego = new EstadoJuego();
        Inventory inventario = juego.getJugador().getInventario();
        comprobar(inventario.agregarItem(new Escoba()), "No se agregó la escoba de prueba.");
        juego.getJugador().setAnguloApuntado(0);
        juego.getEntidad().setX(juego.getJugador().getX() + 77);
        juego.getEntidad().setY(juego.getJugador().getY());

        comprobar(juego.usarObjetoSeleccionado(), "No se lanzó la escoba equipada.");
        comprobar(inventario.getItemSeleccionado() == null,
                "La escoba lanzada permaneció en el inventario.");
        comprobar(!juego.getProyectilesEscoba().isEmpty(),
                "No se creó el proyectil de la escoba.");
        for (int i = 0; i < 10 && !juego.getEntidad().isEstaParalizado(); i++) {
            juego.actualizar(0.05, 0, 0, false);
        }
        comprobar(juego.getEntidad().isEstaParalizado(),
                "La escoba lanzada no paralizó a la entidad al impactar.");

        comprobar(inventario.agregarItem(new Escoba()), "No se agregó la escoba para botar.");
        comprobar(juego.soltarObjetoSeleccionado(), "No se pudo botar la escoba equipada.");
        comprobar(inventario.getItemSeleccionado() == null,
                "La escoba botada permaneció en el inventario.");
        comprobar(juego.getMapaActual().getObjetosSuelo().size() == 1,
                "La escoba botada no quedó en el suelo.");
        juego.interactuar();
        comprobar(inventario.getItemSeleccionado() instanceof Escoba,
                "No se pudo recoger la escoba botada.");

        comprobar(juego.soltarObjetoSeleccionado(), "No se pudo botar la escoba antes de guardar.");
        Path directorio = Files.createTempDirectory("mainjuego-objetos");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            repositorio.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(repositorio.cargar());
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "No se restauró la escoba botada al cargar la partida.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarPersistenciaCrud() throws IOException {
        Path directorio = Files.createTempDirectory("mainjuego-crud");
        RepositorioPartidas repositorio = new RepositorioPartidas(
                directorio.resolve("partida.properties"));
        try {
            EstadoJuego juego = new EstadoJuego();
            comprobar(!repositorio.existe(), "La partida ya existía antes de guardarla.");
            comprobar(juego.getJugador().getInventario().agregarItem(new Escoba()),
                    "No se agregó la escoba para la prueba de guardado.");
            comprobar(juego.soltarObjetoSeleccionado(),
                    "No se botó la escoba para la prueba de guardado.");
            repositorio.guardar(juego.crearDatosPartida());
            comprobar(repositorio.existe(), "No se creó el archivo de partida.");

            juego.getJugador().setX(400);
            repositorio.guardar(juego.crearDatosPartida());
            EstadoJuego cargada = new EstadoJuego();
            cargada.restaurarPartida(repositorio.cargar());
            comprobar(cargada.getJugador().getX() == 400,
                    "No se actualizó la partida existente.");
            comprobar(cargada.getMapaActual().getObjetosSuelo().size() == 1,
                    "La partida actualizada no conservó el objeto del suelo.");
            comprobar(repositorio.eliminar(), "No se eliminó la partida.");
            comprobar(!repositorio.existe(), "El archivo no se eliminó.");

            boolean rechazoPartidaAusente = false;
            try {
                repositorio.cargar();
            } catch (IOException ex) {
                rechazoPartidaAusente = true;
            }
            comprobar(rechazoPartidaAusente, "Se aceptó cargar una partida inexistente.");

            Files.writeString(repositorio.getArchivo(), "version=desconocida\n");
            boolean rechazoVersionInvalida = false;
            try {
                repositorio.cargar();
            } catch (IOException ex) {
                rechazoVersionInvalida = true;
            }
            comprobar(rechazoVersionInvalida, "Se aceptó un archivo de partida inválido.");
        } finally {
            repositorio.eliminar();
            Files.deleteIfExists(directorio);
        }
    }

    private static void probarInterfazSwing() {
        EstadoJuego juego = new EstadoJuego();
        PanelJuego panel = new PanelJuego(juego);
        panel.setSize(Mapa.ANCHO, Mapa.ALTO);
        BufferedImage imagen = new BufferedImage(
                Mapa.ANCHO, Mapa.ALTO, BufferedImage.TYPE_INT_ARGB);
        var graficos = imagen.createGraphics();
        panel.paint(graficos);
        graficos.dispose();

        ControladorJuego controlador = new ControladorJuego(juego, panel);
        comprobar(controlador.crearBarraMenu().getMenuCount() == 1,
                "No se creó el menú Swing de partida.");
    }

    private static ObjetoMapa buscar(EstadoJuego juego, ObjetoMapa.Tipo tipo) {
        return juego.getMapaActual().getObjetos().stream()
                .filter(objeto -> objeto.getTipo() == tipo)
                .findFirst()
                .orElseThrow(() -> new AssertionError("Falta objeto de tipo " + tipo));
    }

    private static void irAHabitacion(EstadoJuego juego, String idHabitacion) {
        int[] posicion = switch (idHabitacion) {
            case "BIBLIOTECA", "LAB1" -> new int[]{12, 4};
            case "DORMITORIO", "LAB2" -> new int[]{18, 4};
            case "COCINA", "BAÑOS" -> new int[]{3, 10};
            case "COMEDOR", "TIENDA" -> new int[]{2, 15};
            case "BODEGA", "LAB3" -> new int[]{12, 14};
            case "TALLER", "PATIO" -> new int[]{23, 15};
            default -> throw new AssertionError("Zona desconocida: " + idHabitacion);
        };
        juego.getJugador().setX(posicion[0] * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(posicion[1] * Mapa.TILE_SIZE + 4);
        String zonaEsperada = switch (idHabitacion) {
            case "BIBLIOTECA", "LAB1" -> "Laboratorio 1";
            case "DORMITORIO", "LAB2" -> "Laboratorio 2";
            case "COCINA", "BAÑOS" -> "Baños";
            case "COMEDOR", "TIENDA" -> "Tienda";
            case "BODEGA", "LAB3" -> "Laboratorio 3";
            case "TALLER", "PATIO" -> "Patio";
            default -> throw new AssertionError("Zona desconocida: " + idHabitacion);
        };
        comprobar(zonaEsperada.equals(juego.getMapaActual().getNombreZona(
                        posicion[0], posicion[1])),
                "No se pudo acceder a " + zonaEsperada + ".");
    }

    private static void volverAlPasillo(EstadoJuego juego) {
        juego.getJugador().setX(10 * Mapa.TILE_SIZE + 4);
        juego.getJugador().setY(8 * Mapa.TILE_SIZE + 4);
        comprobar("Pasillo principal".equals(juego.getMapaActual().getNombreZona(10, 8)),
                "No se pudo regresar al pasillo principal.");
    }

    private static boolean hayRuta(Mapa mapa, int inicioX, int inicioY, int destinoX, int destinoY) {
        boolean[][] visitadas = new boolean[Mapa.FILAS][Mapa.COLUMNAS];
        Queue<int[]> pendientes = new ArrayDeque<>();
        pendientes.add(new int[]{inicioX, inicioY});
        visitadas[inicioY][inicioX] = true;
        int[][] movimientos = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        while (!pendientes.isEmpty()) {
            int[] actual = pendientes.remove();
            if (actual[0] == destinoX && actual[1] == destinoY) {
                return true;
            }
            for (int[] movimiento : movimientos) {
                int x = actual[0] + movimiento[0];
                int y = actual[1] + movimiento[1];
                if (x >= 0 && x < Mapa.COLUMNAS && y >= 0 && y < Mapa.FILAS
                        && !visitadas[y][x]
                        && !mapa.esColision(x * Mapa.TILE_SIZE + 4,
                                y * Mapa.TILE_SIZE + 4, 24, 24)) {
                    visitadas[y][x] = true;
                    pendientes.add(new int[]{x, y});
                }
            }
        }
        return false;
    }

    private static void interactuarCon(EstadoJuego juego, ObjetoMapa objeto) {
        juego.getJugador().setX(objeto.getCentroX() - juego.getJugador().getAncho() / 2.0);
        juego.getJugador().setY(objeto.getCentroY() - juego.getJugador().getAlto() / 2.0);
        juego.interactuar();
    }

    private static void comprobar(boolean condicion, String mensaje) {
        if (!condicion) {
            throw new AssertionError(mensaje);
        }
    }
}
