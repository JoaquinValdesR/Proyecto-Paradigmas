# La casa sin salida

Juego de suspenso y acertijos desarrollado en Java 20 y Swing. El objetivo es
explorar la casa, recoger cuatro piezas, resolver el código del libro, obtener
la llave de la caja fuerte y alcanzar la salida mientras se evita a la entidad.

## Arquitectura

- `modelo`: estado, reglas, jugador, entidad, inventario, mapa y objetos.
- `vista`: ventana de juego, HUD y representación gráfica del mapa.
- `controlador`: entradas de teclado y mouse, ciclo de actualización y acciones
  de interfaz.
- `persistencia`: lectura, escritura y eliminación segura de partidas.

El modelo no dibuja componentes ni usa Swing. La vista consulta el modelo para
representarlo y el controlador coordina las acciones del usuario. `Item` y sus
subclases comparten comportamiento mediante herencia y polimorfismo; el
inventario limita y administra sus objetos. Swing usa eventos para procesar las
entradas sin mezclar esas acciones con el renderizado.

## Controles

- `WASD` o flechas: moverse.
- `Shift`: correr mientras haya stamina.
- `E`: recoger o interactuar con el objeto cercano.
- `1` a `9`: seleccionar un espacio del inventario.
- `Espacio`: usar el objeto seleccionado; con el libro seleccionado, abrirlo.
- `Q`: botar en el suelo el objeto seleccionado.
- `B`: abrir el libro de acertijos.
- `F`: alternar la linterna.
- Clic izquierdo: disparar el taser hacia el cursor.

El libro se habilita al reunir las cuatro piezas. Sus pistas indican el código
`314`. El código abre el acceso a la llave; la llave permite escapar.
La escoba equipada se lanza en la dirección del cursor y se consume al lanzarla;
si impacta a la entidad, la paraliza. Los objetos botados quedan en el suelo,
pueden recogerse con `E` y se conservan al guardar la partida.

## Mapa y habitaciones

El mapa es un solo plano conectado, basado en el diseño de referencia: pasillo
horizontal, baños y tienda a la izquierda, laboratorios 1 y 2 arriba, laboratorio
3 abajo y patio a la derecha. Las puertas verdes son pasos transitables; las dos
puertas negras están bloqueadas y muestran un aviso al intentar cruzarlas. El
nombre de la zona aparece en el HUD mientras exploras.

## Persistencia y gestión de partidas

La partida se guarda como propiedades UTF-8 en
`%USERPROFILE%\.mainjuego\partida.properties`. Se conservan posición y punto de
reaparición, salud, stamina, batería, inventario, estado de la entidad, piezas,
objetos restantes y botados, puzzle y resultado.

El menú **Partida** permite crear o actualizar un guardado, cargarlo y eliminarlo
(CRUD). La escritura usa un archivo temporal y reemplazo atómico cuando el
sistema de archivos lo permite. Al cargar se validan versión, rangos, objetos
conocidos y consistencia entre inventario, mapa y progreso.

## Compilar y ejecutar

Se requiere JDK 20 o posterior. Desde la carpeta `MainJuego`:

```powershell
mvn package
java -cp target\classes com.mycompany.mainjuego.MainJuego
```

También se puede compilar sin Maven:

```powershell
$fuentes = Get-ChildItem src\main\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -d target\classes $fuentes.FullName
java -cp target\classes com.mycompany.mainjuego.MainJuego
```

## Pruebas

`src\test\java\pruebas\PruebasProyecto.java` contiene pruebas ejecutables sin
dependencias externas. Desde `MainJuego`, compilar y ejecutarlas con:

```powershell
$fuentes = Get-ChildItem src\main\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -d target\classes $fuentes.FullName
$pruebas = Get-ChildItem src\test\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -cp target\classes -d target\test-classes $pruebas.FullName
java -cp "target\classes;target\test-classes" pruebas.PruebasProyecto
```

Casos cubiertos: verificar las zonas del plano, atravesar puertas abiertas,
bloquear puertas cerradas, guardar y restaurar objetos botados, recoger y
restaurar el progreso, rechazar un código incorrecto, completar
puzzle-caja-salida, impedir recoger con inventario lleno,
crear/actualizar/cargar/eliminar partidas y rechazar un guardado ausente o con
versión inválida. También lanzar la escoba, consumirla al lanzarla, paralizar a
la entidad al impactar, botar y recoger objetos, y conservar los objetos botados
al guardar y cargar.

Resultados de la última ejecución local:

| Caso | Resultado |
|---|---|
| Recuperar posición, pieza, inventario y objetos restantes | Correcto |
| Rechazar código incorrecto y resolver el código válido | Correcto |
| Completar caja fuerte y escapar con la llave | Correcto |
| Rechazar una pieza cuando el inventario está lleno | Correcto |
| Crear, actualizar, cargar y eliminar una partida | Correcto |
| Rechazar una partida inexistente o con versión inválida | Correcto |
| Verificar el plano, sus zonas y puertas accesibles/bloqueadas | Correcto |
| Guardar/restaurar objetos botados en el mapa conectado | Correcto |
| Pintar el panel Swing y construir el menú de partida | Correcto |
| Lanzar escoba, impacto, botar/recoger y persistir objetos en el suelo | Correcto |
