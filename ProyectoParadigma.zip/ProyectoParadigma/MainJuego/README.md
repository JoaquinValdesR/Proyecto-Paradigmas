# Escapando de la FACE

Juego de suspenso y acertijos desarrollado en Java 20 y Swing. El objetivo es
explorar la casa, recoger cuatro piezas, resolver el código del libro, obtener
la llave de la caja fuerte y alcanzar la salida mientras se evita a la entidad.

## Arquitectura

- `modelo`: estado, reglas, jugador, entidad, inventario, mapa y objetos.
- `vista`: ventana de juego, HUD y representación gráfica del mapa.
- `controlador`: entradas de teclado y mouse, ciclo de actualización y acciones
  de interfaz.
- `persistencia`: lectura, escritura y eliminación segura de partidas.

El modelo no dibuja componentes ni usa Swing. La vista consulta el modelo para
representarlo y el controlador coordina las acciones del usuario.
`ObjetoInventario` y sus
subclases comparten comportamiento mediante herencia y polimorfismo; el
inventario limita y administra sus objetos. Swing usa eventos para procesar las
entradas sin mezclar esas acciones con el renderizado.

## Controles

- `WASD` o flechas: moverse.
- `Shift`: correr a velocidad 180 mientras haya stamina. La stamina se consume
  al correr; la entidad se mueve a 112 en su primera fase y a 150 al enfurecerse.
- `E`: recoger o interactuar con el objeto cercano.
- `1` a `9`: seleccionar un espacio del inventario.
- `Espacio`: usar el objeto seleccionado; con el libro seleccionado, abrirlo.
- `B`: abrir el libro de acertijos.
- `F`: alternar la linterna.
- `ESC`: abrir o cerrar la pausa.
- Clic izquierdo: disparar el taser hacia el cursor.

La linterna consume su batería en aproximadamente 40 segundos si permanece
encendida; puedes apagarla para conservar carga. Recoge una batería, selecciónala
en el inventario y pulsa `Espacio` para recargarla completamente; la pila se
consume al usarla.
Recoge un botiquín con `E`, selecciónalo en el inventario y pulsa `Espacio` para
restaurar toda tu salud; el botiquín se consume al usarlo.

El libro se habilita al reunir las cuatro piezas. En cada partida se elige al
azar uno de cinco acertijos numéricos; la elección se conserva al guardar y
cargar. Resolverlo abre el acceso a la llave; la llave permite escapar.
La escoba equipada se usa como golpe cuerpo a cuerpo hacia el cursor y se consume
en un único uso; si alcanza a la entidad, la aturde durante 2,5 segundos. Mientras
está aturdida no puede hacer daño. Los objetos botados quedan en el suelo,
pueden recogerse con `E` y se conservan al guardar la partida.

## Mapa y habitaciones

El mapa es un solo plano conectado, basado en el diseño de referencia: pasillo
horizontal, baños y tienda a la izquierda, laboratorios 1 y 2 arriba, patio abajo
a la izquierda y laboratorio 3 abajo a la derecha. El paso entre el patio y el
laboratorio 3 está cerrado. Las puertas verdes son pasos transitables; las dos
puertas negras están bloqueadas y muestran un aviso al intentar cruzarlas. El
nombre de la zona aparece en el HUD mientras exploras.

## Persistencia y gestión de partidas

La partida se guarda como propiedades UTF-8 en
`%USERPROFILE%\.mainjuego\partidas\`. Se conservan posición y punto de
reaparición, salud, stamina, batería, inventario, estado de la entidad, piezas,
objetos restantes y botados, puzzle, resultado, nombre del jugador y tiempo
transcurrido. Los guardados anteriores se siguen pudiendo cargar.

El menú **Partida** permite crear o actualizar un guardado, cargarlo y eliminarlo
(CRUD). La escritura usa un archivo temporal y reemplazo atómico cuando el
sistema de archivos lo permite. Al cargar se validan versión, rangos, objetos
conocidos y consistencia entre inventario, mapa y progreso.

## Menú y muerte

Al iniciar aparece el menú principal con las opciones **Nueva partida**,
**Cargar partida**, **Ranking** y **Salir**. Nueva partida solicita un nombre;
el tiempo se muestra durante el juego, se conserva en el guardado y se agrega al
ranking al escapar. Los diez mejores tiempos se guardan en
`%USERPROFILE%\.mainjuego\ranking.properties`, con la fecha y hora en que se
completó cada partida. Pulsa `ESC` para pausar y elegir
**Reanudar**, **Guardar partida** o **Menú principal**. El botón **Cargar
partida** del inicio muestra la lista de guardados con jugador, tiempo y fecha;
desde esa lista también puedes borrar la partida seleccionada.
Si el jugador muere, se muestra una pantalla
con **Reintentar** y **Menú principal**. Reintentar inicia desde el comienzo y
restablece el inventario, el mapa y el progreso; cargar partida restaura el
guardado existente.

Los objetos del mapa se colocan en casillas transitables conectadas con el
punto inicial; si una posición configurada queda fuera del área accesible, se
ajusta a la casilla accesible más cercana.

## Compilar y ejecutar

Se requiere JDK 20 o posterior. Desde la carpeta `MainJuego`:

```powershell
mvn package
java -cp target\classes com.mycompany.mainjuego.MainJuego
```

También se puede compilar sin Maven:

```powershell
$fuentes = Get-ChildItem src\main\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -d target\classes $fuentes.FullName
java -cp target\classes com.mycompany.mainjuego.MainJuego
```

## Pruebas

`src\test\java\pruebas\PruebasProyecto.java` contiene pruebas ejecutables sin
dependencias externas. Desde `MainJuego`, compilar y ejecutarlas con:

```powershell
$fuentes = Get-ChildItem src\main\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -d target\classes $fuentes.FullName
$pruebas = Get-ChildItem src\test\java -Filter *.java -Recurse
javac --release 20 -encoding UTF-8 -cp target\classes -d target\test-classes $pruebas.FullName
java -cp "target\classes;target\test-classes" pruebas.PruebasProyecto
```

Casos cubiertos: verificar las zonas del plano, atravesar puertas abiertas,
bloquear puertas cerradas, guardar y restaurar objetos en el suelo, recoger y
restaurar el progreso, rechazar un código incorrecto, completar
puzzle-caja-salida, impedir recoger con inventario lleno,
crear/actualizar/cargar/eliminar partidas y rechazar un guardado ausente o con
versión inválida. También verificar el nombre y tiempo guardados, compatibilidad
con partidas anteriores, orden del ranking, controles de pausa y lanzar la
escoba, consumirla al usarla cuerpo a cuerpo, aturdir a la entidad e impedir
que haga daño mientras esté aturdida.

