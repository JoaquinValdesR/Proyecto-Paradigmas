/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Linterna {
    private static final long serialVersionUID = 1L;

    private float nivelBateria;
    private final float bateriaMax = 100.0f;
    private float tasaConsumo = 4.0f; // Porcentaje consumido por segundo (dura ~25s)
    
    private boolean estaEncendida;
    
    // Configuración del radio de luz en píxeles
    private final double radioLuzMax = 180.0; // Visión completa con batería al 100%
    private final double radioLuzMin = 40.0;  // Visión reducida cuando le queda poca batería

    public Linterna() {
        this.nivelBateria = bateriaMax;
        this.estaEncendida = true;
    }

    /**
     * Consume batería gradualmente mientras esté encendida.
     * @param deltaTiempo Tiempo transcurrido entre frames (en segundos).
     */
    public void actualizar(double deltaTiempo) {
        if (estaEncendida) {
            nivelBateria -= tasaConsumo * deltaTiempo;

            if (nivelBateria <= 0.0f) {
                nivelBateria = 0.0f;
                estaEncendida = false; // Se apaga al agotarse por completo
            }
        }
    }

    /**
     * Alterna el estado de encendido/apagado de la linterna.
     */
    public void toggle() {
        if (nivelBateria > 0) {
            this.estaEncendida = !this.estaEncendida;
        } else {
            this.estaEncendida = false;
        }
    }

    /**
     * Recarga el nivel de batería usando un ítem consumible (ej: ItemBateria).
     */
    public void recargar(float cantidad) {
        this.nivelBateria = Math.min(this.nivelBateria + cantidad, bateriaMax);
        if (this.nivelBateria > 0) {
            this.estaEncendida = true; // Se vuelve a encender al recargar
        }
    }

    /**
     * Calcula el radio de visión dinámico del halo de luz según el % de batería actual.
     */
    public double obtenerRadioLuz() {
        if (!estaEncendida || nivelBateria <= 0) {
            return 0.0; // Oscuridad total si está apagada
        }
        double porcentajeBateria = nivelBateria / bateriaMax;
        return radioLuzMin + (radioLuzMax - radioLuzMin) * porcentajeBateria;
    }

    // --- GETTERS Y SETTERS ---

    public float getNivelBateria() { return nivelBateria; }
    public float getBateriaMax() { return bateriaMax; }
    public boolean isEstaEncendida() { return estaEncendida; }
    public void setEstaEncendida(boolean estaEncendida) { 
        if (nivelBateria > 0) {
            this.estaEncendida = estaEncendida; 
        }
    }
}
