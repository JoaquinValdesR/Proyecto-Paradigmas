/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Puerta implements Serializable{
    private static final long serialVersionUID = 1L;

    private int tileX;          // Columna de la puerta en la matriz
    private int tileY;          // Fila de la puerta en la matriz
    private String mapaDestino; // ID o nombre del mapa al que lleva (ej: "SALA_1")
    private double destinoX;    // Coordenada X donde reaparecerá el jugador en la nueva sala
    private double destinoY;    // Coordenada Y donde reaparecerá el jugador en la nueva sala

    public Puerta(int tileX, int tileY, String mapaDestino, double destinoX, double destinoY) {
        this.tileX = tileX;
        this.tileY = tileY;
        this.mapaDestino = mapaDestino;
        this.destinoX = destinoX;
        this.destinoY = destinoY;
    }

    /**
     * Evalúa si el jugador tocó la casilla de la puerta
     */
    public boolean jugadorEstaEncima(Player jugador) {
        int colJugador = (int) (jugador.getX() / Mapa.TILE_SIZE);
        int filaJugador = (int) (jugador.getY() / Mapa.TILE_SIZE);
        return colJugador == tileX && filaJugador == tileY;
    }

    // Getters
    public String getMapaDestino() { return mapaDestino; }
    public double getDestinoX() { return destinoX; }
    public double getDestinoY() { return destinoY; }
}
