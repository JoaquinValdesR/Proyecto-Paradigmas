/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Entity implements Serializable{
   private static final long serialVersionUID = 1L;

    // Posición y dimensiones
    private double x;
    private double y;
    private final int ancho = 32;
    private final int alto = 32;

    // Velocidades
    private double velocidadNormal = 1.8;
    private double velocidadFuria = 3.2;
    private boolean esModoFuria = false;

    // Estado de Parálisis (Efecto del Taser)
    private boolean estaParalizado = false;
    private long tiempoFinParalisis = 0;

    // Atributos de ataque
    private int danoBase = 25;

    public Entity(double xInicial, double yInicial) {
        this.x = xInicial;
        this.y = yInicial;
    }

    /**
     * Actualiza la lógica de la entidad en cada frame (invocado desde EstadoJuego).
     */
    public void actualizar(Player jugador, Mapa mapa) {
        // 1. Verificar si sigue paralizado por el Taser
        if (estaParalizado) {
            if (System.currentTimeMillis() >= tiempoFinParalisis) {
                estaParalizado = false;
            } else {
                return; // Mientras esté paralizado no se mueve ni ataca
            }
        }

        // 2. Perseguir al jugador si está vivo
        if (jugador != null && jugador.isEstaVivo()) {
            perseguir(jugador, mapa);
            comprobarColisionJugador(jugador);
        }
    }

    /**
     * Mueve a la entidad en dirección a las coordenadas del jugador con separación de ejes para evitar atascos.
     */
    public void perseguir(Player jugador, Mapa mapa) {
        double diffX = jugador.getX() - this.x;
        double diffY = jugador.getY() - this.y;

        double distancia = Math.hypot(diffX, diffY);
        if (distancia == 0) return;

        double velActual = esModoFuria ? velocidadFuria : velocidadNormal;

        // Normalizar vector de movimiento
        double dirX = (diffX / distancia) * velActual;
        double dirY = (diffY / distancia) * velActual;

        // Evaluar colisión y mover en Eje X
        double nuevaX = this.x + dirX;
        if (!mapa.esColision(nuevaX, this.y, ancho, alto)) {
            this.x = nuevaX;
        }

        // Evaluar colisión y mover en Eje Y
        double nuevaY = this.y + dirY;
        if (!mapa.esColision(this.x, nuevaY, ancho, alto)) {
            this.y = nuevaY;
        }
    }

    /**
     * Aplica el estado de inmovilización producido por el Taser.
     * @param duracionMs Tiempo en milisegundos que la entidad no se moverá.
     */
    public void paralizar(long duracionMs) {
        this.estaParalizado = true;
        this.tiempoFinParalisis = System.currentTimeMillis() + duracionMs;
    }

    /**
     * Activa el modo de furia (aumenta la velocidad y elimina al jugador de 1 golpe).
     */
    public void activarModoFuria() {
        this.esModoFuria = true;
    }

    /**
     * Evalúa colisión de hitboxes (AABB) entre la entidad y el jugador para aplicarle daño.
     */
    public void comprobarColisionJugador(Player jugador) {
        boolean colisionX = this.x < jugador.getX() + jugador.getAncho() && this.x + executionBoxAncho() > jugador.getX();
        boolean colisionY = this.y < jugador.getY() + jugador.getAlto() && this.y + executionBoxAlto() > jugador.getY();

        if (colisionX && colisionY) {
            if (esModoFuria) {
                jugador.recibirDano(jugador.getSaludMax()); // Muerte instantánea
            } else {
                jugador.recibirDano(danoBase); // Daño estándar
            }
        }
    }

    private int executionBoxAncho() { return this.ancho; }
    private int executionBoxAlto() { return this.alto; }

    // --- GETTERS Y SETTERS ---

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }

    public double getY() { return y; }
    public void setY(double y) { this.y = y; }

    public int getAncho() { return ancho; }
    public int getAlto() { return alto; }

    public boolean isEstaParalizado() { return estaParalizado; }
    public boolean isEsModoFuria() { return esModoFuria; } 
}
