/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Taser implements Serializable{
    private static final long serialVersionUID = 1L;

    private long ultimoDisparoMs;
    private final long cooldownMs = 8000;          // 8 segundos de recarga entre disparos
    private final long duracionParalisisMs = 4000; // 4 segundos de parálisis a la entidad
    private final double alcance = 180.0;          // Distancia máxima de impacto en píxeles

    public Taser() {
        this.ultimoDisparoMs = 0; // Inicia listo para disparar
    }

    /**
     * Evalúa si el Taser ha completado su tiempo de recarga.
     */
    public boolean estaListo() {
        return System.currentTimeMillis() - ultimoDisparoMs >= cooldownMs;
    }

    /**
     * Calcula los segundos restantes de recarga para mostrar en la interfaz/HUD.
     */
    public double getTiempoRestanteCooldown() {
        long transcurrido = System.currentTimeMillis() - ultimoDisparoMs;
        if (transcurrido >= cooldownMs) {
            return 0.0;
        }
        return (cooldownMs - transcurrido) / 1000.0;
    }

    /**
     * Ejecuta la descarga contra la entidad si está dentro del cono de visión y rango de tiro.
     * @return true si el disparo impactó y paralizó a la entidad.
     */
    public boolean disparar(Player jugador, Entity entidad) {
        if (!estaListo() || entidad == null || !jugador.isEstaVivo()) {
            return false;
        }

        // 1. Calcular distancia entre jugador y entidad
        double diffX = entidad.getX() - jugador.getX();
        double diffY = entidad.getY() - jugador.getY();
        double distancia = Math.hypot(diffX, diffY);

        // 2. Verificar si está dentro del rango
        if (distancia <= alcance) {
            // Verificar ángulo de apuntado del jugador hacia la entidad (cono de ~60 grados)
            double anguloHaciaEntidad = Math.atan2(diffY, diffX);
            double diferenciaAngulo = Math.abs(anguloHaciaEntidad - jugador.getAnguloApuntado());

            if (diferenciaAngulo > Math.PI) {
                diferenciaAngulo = 2 * Math.PI - diferenciaAngulo;
            }

            // Si está dentro del cono de apuntado, impacta
            if (diferenciaAngulo <= Math.PI / 3) {
                entidad.paralizar(duracionParalisisMs);
                this.ultimoDisparoMs = System.currentTimeMillis(); // Reinicia el tiempo de recarga
                return true;
            }
        }

        // Si falló el disparo por distancia o ángulo, igual consume la carga
        this.ultimoDisparoMs = System.currentTimeMillis();
        return false;
    }

    // --- GETTERS ---
    public long getCooldownMs() { return cooldownMs; }
    public long getDuracionParalisisMs() { return duracionParalisisMs; }
    public double getAlcance() { return alcance; }
}
