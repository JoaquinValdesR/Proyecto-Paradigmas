/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

public class Player implements Serializable{
    private static final long serialVersionUID = 1L;

    // Posición y dimensiones
    private double x;
    private double y;
    private final int ancho = 32;
    private final int alto = 32;
    private double velocidadBase = 2.5;
    private double velocidadSprint = 4.5;

    // Salud y reaparición
    private int saludMax = 100;
    private int saludActual;
    private boolean estaVivo;
    private double puntoReaparicionX;
    private double puntoReaparicionY;

    // Stamina
    private float staminaMax = 100.0f;
    private float staminaActual;
    private float tasaConsumoStamina = 20.0f;     // Se consume en 5 segundos
    private float tasaRecuperacionStamina = 10.0f; // Se recupera en 10 segundos
    private boolean estaCorriendo;
    private boolean staminaAgotada;

    // Orientación
    private double anguloApuntado; // En radianes
    private final double rangoInteraccion = 50.0;

    // Equipamiento
    private Inventory inventario;
    private Linterna linterna;
    private Taser taser;

    public Player(double xInicial, double yInicial) {
        this.x = xInicial;
        this.y = yInicial;
        this.puntoReaparicionX = xInicial;
        this.puntoReaparicionY = yInicial;
        
        this.saludActual = saludMax;
        this.staminaActual = staminaMax;
        this.estaVivo = true;
        this.estaCorriendo = false;
        this.staminaAgotada = false;

        this.inventario = new Inventory();
        this.linterna = new Linterna();
        this.taser = new Taser();
    }

    // --- LÓGICA DE MOVIMIENTO Y COLISIONES ---
    
    public void mover(double dirX, double dirY, Mapa mapa, double deltaTiempo) {
        if (!estaVivo) return;

        // Determinar velocidad actual
        double vel = (estaCorriendo && !staminaAgotada) ? velocidadSprint : velocidadBase;

        // Normalizar el vector de movimiento diagonal
        double magnitud = Math.hypot(dirX, dirY);
        if (magnitud > 0) {
            dirX = (dirX / magnitud) * vel;
            dirY = (dirY / magnitud) * vel;
        }

        // Evaluar colisión en X
        double nuevaX = this.x + dirX;
        if (!mapa.esColision(nuevaX, this.y, ancho, alto)) {
            this.x = nuevaX;
        }

        // Evaluar colisión en Y
        double nuevaY = this.y + dirY;
        if (!mapa.esColision(this.x, nuevaY, ancho, alto)) {
            this.y = nuevaY;
        }
    }

    // --- LÓGICA DE STAMINA ---

    public void actualizarStamina(boolean intentandoCorrer, boolean seEstaMoviendo, double deltaTiempo) {
        if (intentandoCorrer && seEstaMoviendo && !staminaAgotada) {
            this.estaCorriendo = true;
            this.staminaActual -= tasaConsumoStamina * deltaTiempo;

            if (this.staminaActual <= 0) {
                this.staminaActual = 0;
                this.estaCorriendo = false;
                this.staminaAgotada = true; // Penalización por agotar energía
            }
        } else {
            this.estaCorriendo = false;
            if (this.staminaActual < staminaMax) {
                this.staminaActual += tasaRecuperacionStamina * deltaTiempo;
                if (this.staminaActual >= staminaMax) {
                    this.staminaActual = staminaMax;
                    this.staminaAgotada = false; // Se quita la penalización al cargarse por completo
                }
            }
        }
    }

    // --- LÓGICA DE SALUD Y DAÑO ---

    public void recibirDano(int cantidad) {
        if (!estaVivo) return;

        this.saludActual -= cantidad;
        if (this.saludActual <= 0) {
            this.saludActual = 0;
            this.estaVivo = false;
            reaparecer(); // Se activa el respawn
        }
    }

    public void reaparecer() {
        this.x = this.puntoReaparicionX;
        this.y = this.puntoReaparicionY;
        this.saludActual = saludMax;
        this.staminaActual = staminaMax;
        this.staminaAgotada = false;
        this.estaVivo = true;
    }

    public void actualizarPuntoReaparicion(double nuevaX, double nuevaY) {
        this.puntoReaparicionX = nuevaX;
        this.puntoReaparicionY = nuevaY;
    }

    public void curar(int cantidad) {
        this.saludActual = Math.min(this.saludActual + cantidad, saludMax);
    }
    
    public void setX(double x) { this.x = x;
}

    // --- GETTERS Y SETTERS ---
    public void setY(double y) {
        this.y = y;
    }

    public double getX() {
        return x;
    }
    public double getY() { return y; }
    public int getAncho() { return ancho; }
    public int getAlto() { return alto; }
    public int getSaludActual() { return saludActual; }
    public int getSaludMax() { return saludMax; }
    public float getStaminaActual() { return staminaActual; }
    public float getStaminaMax() { return staminaMax; }
    public boolean isEstaVivo() { return estaVivo; }
    public boolean isEstaCorriendo() { return estaCorriendo; }
    public double getAnguloApuntado() { return anguloApuntado; }
    public void setAnguloApuntado(double angulo) { this.anguloApuntado = angulo; }
    public Inventory getInventario() { return inventario; }
    public Linterna getLinterna() { return linterna; }
    public Taser getTaser() { return taser; }
    public double getRangoInteraccion() { return rangoInteraccion; }
    
}
