/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
public abstract class Item implements Serializable{
    private static final long serialVersionUID = 1L;

    private String id;
    private String nombre;
    private String descripcion;
    private boolean esConsumible;

    public Item(String id, String nombre, String descripcion, boolean esConsumible) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.esConsumible = esConsumible;
    }

    /**
     * Método abstracto que ejecutará la acción del objeto al ser usado.
     * Cada subclase (Bateria, Cura, Llave) implementará su propio efecto.
     */
    public abstract boolean usar(Player jugador);

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public boolean isEsConsumible() { return esConsumible; }
}
