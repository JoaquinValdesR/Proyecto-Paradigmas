/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

public class EstadoJuego {
    private Map<String, Mapa> mapasRegistrados;
    private Mapa mapaActual;
    private Player jugador;

    // --- VARIABLES DE TRANSICIÓN (Efecto Pantalla Negra) ---
    private boolean enTransicion = false;
    private int alphaNegro = 0; // 0 = Transparente (Totalmente visible), 255 = Negro Total
    private boolean oscureciendo = true; // true = transicionando a negro, false = aclarando
    private Puerta puertaPendiente = null;

    public EstadoJuego() {
        mapasRegistrados = new HashMap<>();
        // Aquí registras tus salas
        // mapasRegistrados.put("ZONA_CENTRAL", new MapaZonaCentral());
        // mapasRegistrados.put("SALA_1", new MapaSala1());
        // mapaActual = mapasRegistrados.get("ZONA_CENTRAL");
    }

    /**
     * Se llama en cada cuadro (frame) desde el GameLoop
     */
    public void actualizar() {
        if (enTransicion) {
            actualizarEfectoTransicion();
            return; // Mientras pantalla esté cambiando, congelamos el movimiento del juego
        }

        // Movimiento normal del juego
        // ...

        // Verificar si el jugador tocó alguna puerta del mapa actual
        for (Puerta puerta : mapaActual.getPuertas()) {
            if (puerta.jugadorEstaEncima(jugador)) {
                iniciarTransicion(puerta);
                break;
            }
        }
    }

    private void iniciarTransicion(Puerta puerta) {
        this.enTransicion = true;
        this.oscureciendo = true;
        this.alphaNegro = 0;
        this.puertaPendiente = puerta;
    }

    private void actualizarEfectoTransicion() {
        int velocidadFade = 15; // Qué tan rápido se oscurece/aclara la pantalla

        if (oscureciendo) {
            alphaNegro += velocidadFade;
            if (alphaNegro >= 255) {
                alphaNegro = 255;
                
                // --- PUNTO MEDIO: La pantalla está 100% negra ---
                // 1. Cambiar al nuevo mapa
                mapaActual = mapasRegistrados.get(puertaPendiente.getMapaDestino());
                
                // 2. Mover al jugador a la entrada de la nueva sala
                jugador.setX(puertaPendiente.getDestinoX());
                jugador.setY(puertaPendiente.getDestinoY());

                // 3. Comenzar a aclarar la pantalla
                oscureciendo = false;
            }
        } else {
            alphaNegro -= velocidadFade;
            if (alphaNegro <= 0) {
                alphaNegro = 0;
                enTransicion = false; // Fin de la transición, el jugador puede moverse
                puertaPendiente = null;
            }
        }
    }

    public int getAlphaNegro() { return alphaNegro; }
    public boolean isEnTransicion() { return enTransicion; }
    public Mapa getMapaActual() { return mapaActual; }
}
