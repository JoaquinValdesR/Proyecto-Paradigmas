/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import javax.swing.JPanel;
import modelo.EstadoJuego;

public class PanelJuego extends JPanel{
    private EstadoJuego estadoJuego;

    // Constructor que recibe la referencia del estado del juego
    public PanelJuego(EstadoJuego estadoJuego) {
        this.estadoJuego = estadoJuego;
        this.setDoubleBuffered(true); // Evita el parpadeo visual
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // 1. Dibujar el mapa actual
        if (estadoJuego != null && estadoJuego.getMapaActual() != null) {
            estadoJuego.getMapaActual().dibujar(g2d);
        }

        // 2. Dibujar objetos, entidad y jugador (cuando estén implementados)

        // 3. Dibujar la pantalla negra de transición si aplica
        if (estadoJuego != null && estadoJuego.getAlphaNegro() > 0) {
            g2d.setColor(new Color(0, 0, 0, estadoJuego.getAlphaNegro()));
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }

        Toolkit.getDefaultToolkit().sync();
        g2d.dispose();
    }
}
